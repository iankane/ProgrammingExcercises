#include <cstdio>
#include "Glut/include/glut.h"
#include <math.h>

#define PI 3.14159

struct quaternion {
	float w;
	float x;
	float y;
	float z;
	float angle;
} pquat, qquat, slerpQuat;

//angles and distance for the first matrix
static float distance = -5. , gamma = 0, beta =0 , alpha = 0;
//angles and distance for the second matrix
float alphatemp, betatemp, gammatemp;
float t = 0;
//first matrix
static GLfloat m[16];
//second matrix
static GLfloat mm[16];
static GLfloat p[16];
static GLfloat q[16];
//boolean for if R was pressed
bool R = false;

#define SCREEN_WIDTH  1200.0f
#define SCREEN_HEIGHT 768.0f

void display(void);

void resizeHandler (GLint width, GLint height);

void init(void);


void keyboard (unsigned char key, int x, int y);


int main(int argc, char **argv);


GLfloat * quaternionToMatrix(quaternion g);

quaternion matrixToQuaternion( GLfloat * r);

quaternion slerp(quaternion p, quaternion q, int t);

float dot(quaternion p, quaternion q);

quaternion normalize(quaternion p);