
#include "main.h"

using namespace std;


/**
NOTES
did parts 2 and 3, didn't bug test it. do parts 0 and 1 using user input?



*/
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	glTranslatef(0., 0., distance);



	/* Adjust local coordinate system of cube position using modeling transformations */
	if(R)
	{
		glLoadMatrixf (quaternionToMatrix(slerpQuat));
	}
	else
	{
		glRotatef (alpha, 0.0, 1.0, 0.0);  //yaw
		glRotatef (beta, 1.0, 0.0, 0.0);  //pitch
		glRotatef (gamma, 0.0, 0.0, 1.0);  //roll
	}
	/*
	glColor3f (1.0f, 0.0f, 0.0f);
	glutWireCube (1.0);
	*/
	glColor3f (1.0f, 1.0f, 1.0f);
	glutWireTeapot (0.3f);

	glutSwapBuffers();
	
	glGetFloatv(GL_MODELVIEW_MATRIX, m);

	/*
	m[0]   m[4]   m[8]    m[12] 
	m[1]   m[5]   m[9]    m[13] 
	m[2]   m[6]   m[10]  m[14] 
	m[3]   m[7]   m[11]  m[15]
	*/

	printf("\n m[0] = %f  m[4] = %f m[8] = %f  m[12] %f \n m[1] = %f  m[5] = %f m[9] = %f  m[13] %f \n m[2] = %f  m[6] = %f m[10] = %f  m[14] %f \n m[3] = %f  m[7] = %f m[11] = %f  m[15] %f \n", m[0], m[4], m[8], m[12], m[1], m[5], m[9], m[13], m[2], m[6], m[10], m[14], m[3], m[7], m[11], m[15]);

	//    printf("\n m[0][0] = %f  m[1][0] = %f  m[2][0] = %f  m[3][0] %f \n m[0][1] = %f  m[1][1] = %f  m[2][1] = %f  m[3][1] %f \n m[0][2] = %f  m[1][2] = %f  m[2][2] = %f  m[3][2] %f \n m[0][3] = %f  m[1][3] = %f  m[2][3] = %f  m[3][3] %f \n", 
	//m[0][0], m[1][0], m[2][0], m[3][0], 
	//m[0][1], m[1][1], m[2][1], m[3][1], 
	//m[0][2], m[1][3], m[2][2], m[3][2], 
	//m[0][3], m[1][4], m[2][3], m[3][3]);


}

void resizeHandler (GLint width, GLint height) {
	float aspectRatio = (float)width / (float)height;

	/* Setup the view of the cube. */
	glMatrixMode(GL_PROJECTION);

	// Setup the camera's viewing frustum
	gluPerspective( /* field of view in degree */ 40.0,
		/* aspect ratio */ aspectRatio,
		/* Z near */ 1.0, /* Z far */ 1000.0);

	// Setup the camera's position and orientation
	gluLookAt (0.0f, 0.0f, 2.0f,		// The position of the eye/camera
		0.0f, 0.0f, 0.0f,		// The point we are looking at
		0.0f, 1.0f, 0.0f);		// The up vector, usually the y-axis
}

void init(void)
{
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();

	glClearColor (0.25f, 0.25f, 0.25f, 1.0f);

	glEnable (GL_DEPTH_TEST);
}

void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
	case 'd':
		distance = distance + 1;
		glutPostRedisplay();
		break;
	case 'D':
		distance = distance - 1;
		glutPostRedisplay();
		break;
	case 't':
		t = t + .1;
		if(t > 1)
			t = 1;
		//printf("Theta step: %f\n", t);
		slerpQuat = slerp(pquat,qquat,t);
		glGetFloatv(GL_MODELVIEW_MATRIX, quaternionToMatrix(slerpQuat));
		glutPostRedisplay();
		break;
	case 'T':
		t = t - .1;
		if(t < 0)
			t = 0;
		//printf("Theta step: %f\n", t);
		slerpQuat = slerp(pquat,qquat,t);
		glGetFloatv(GL_MODELVIEW_MATRIX, quaternionToMatrix(slerpQuat));
		glutPostRedisplay();
		break;
	case 'g':
		gamma = gamma + 1;
		glutPostRedisplay();
		break;
	case 'G':
		gamma = gamma - 1;
		glutPostRedisplay();
		break; 
	case 'b':
		beta = beta + 1;
		glutPostRedisplay();
		break;
	case 'B':
		beta = beta - 1;
		glutPostRedisplay();
		break;
	case 'a':
		alpha = alpha + 1;
		glutPostRedisplay();
		break;
	case 'A':
		alpha = alpha - 1;
		glutPostRedisplay();
		break;
	case 'r':
		glGetFloatv(GL_MODELVIEW_MATRIX, mm);
		alpha = 0;
		beta = 0;
		gamma = 0;
		glutPostRedisplay();
		break;
	case 'p':
		glGetFloatv(GL_MODELVIEW_MATRIX, p);
		pquat = matrixToQuaternion(p);
		printf("W : %f \nX : %f \nY : %f\nZ : %f \n", pquat.w, pquat.x, pquat.y, pquat.z );
		break;
	case 'q':
		glGetFloatv(GL_MODELVIEW_MATRIX, q);
		qquat = matrixToQuaternion(q);
		printf("W : %f \nX : %f \nY : %f \nZ : %f \n", qquat.w, qquat.x, qquat.y, qquat.z );
		break;
	case 's':
		//t = dot(pquat,qquat);
		slerpQuat = slerp(pquat,qquat,t);
		printf("W : %f \nX : %f \nY : %f \nZ : %f \n", slerpQuat.w, slerpQuat.x, slerpQuat.y, slerpQuat.z );
		glGetFloatv(GL_MODELVIEW_MATRIX, quaternionToMatrix(slerpQuat));
		glutPostRedisplay();
		break;
	case 'R':
		if(!R)
			R = true;
		else
			R = false;
		
		glutPostRedisplay();
		break;
	case 'e':
		matrixToQuaternion(m);
		glRotatef (alphatemp, 0.0, 1.0, 0.0);  //yaw
		glRotatef (betatemp, 1.0, 0.0, 0.0);  //pitch
		glRotatef (gammatemp, 0.0, 0.0, 1.0);  //roll
		glutPostRedisplay();
		break;
	case 27:
		// ESCAPE Key
		exit (0);

	default:
		break;
	}
}	

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize (SCREEN_WIDTH, SCREEN_HEIGHT);
	glutCreateWindow("the unit cube as a wireframe");

	// Register Callbacks:
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(resizeHandler);

	init();

	// Start the main rendering loop:
	glutMainLoop();

	return 0;             /* ANSI C requires main to return int. */
}

GLfloat * quaternionToMatrix(quaternion g)
{
	GLfloat* rM = new GLfloat[16];
	rM[0] = 1 - 2 * pow (( g.y),2) - 2 * pow(( g.z), 2);
	rM[1] = (2 * g.x * g.y) + (2 * g.w * g.z) ;
	rM[2] = (2 * g.x * g.z) - (2 * g.w * g.y) ;
	rM[3] =0;

	rM[4] = (2 * g.x * g.y) - (2 * g.w * g.z) ;
	rM[5] = 1 - 2 * pow (( g.x),2) - 2 * pow(( g.z), 2);
	rM[6] = (2 * g.z * g.y) + (2 * g.w * g.x) ;
	rM[7] = 0;

	rM[8] = (2 * g.x * g.z) + (2 * g.w * g.y) ;
	rM[9] = (2 * g.z * g.y) - (2 * g.w * g.x) ;
	rM[10] = 1 - 2 * pow ((2* g.y),2) - 2 * pow(( g.x), 2);
	rM[11] = 0;

	rM[12] = 0;
	rM[13] = 0;
	rM[14] = -5;
	rM[15] = 1;

	return rM;
}

quaternion matrixToQuaternion( GLfloat * r)
{
	quaternion y;
	y.angle = acos((r[0] + r[5] + r[10] - 1 )/2);
	y.x = (r[6] - r[9])/ ( 2* sin (y.angle));
	y.y = (r[8] - r[2])/ ( 2* sin (y.angle));
	y.z = (r[1] - r[4])/ ( 2* sin (y.angle));
	y.x = y.x * sin(y.angle/2);
	y.y = y.y * sin(y.angle/2);
	y.z = y.z * sin(y.angle/2);
	y.w = cos(y.angle/2);
	return y;
}

quaternion slerp(quaternion p, quaternion q, int temp)
{
	quaternion rQ;
	//float theta = 0.0;
	//DOT PRODUCT OF P AND Q
	p = normalize(p);
	q = normalize(q);
	float theta = acos(dot(p,q));
	
	printf("theta step : %f\n" , theta);
	printf("t step : %f\n" , t);

	rQ.w = (sin((1-t) * theta) * p.w);
	rQ.w = rQ.w + (sin(t * theta)) * q.w ;
	rQ.w = rQ.w / sin(theta);

	rQ.x = (sin((1-t) * theta)) * p.x ;
	rQ.x =	rQ.x + (sin(t * theta)) * q.x  ;
	rQ.x = rQ.x / sin(theta);

	rQ.y = (sin((1-t) * theta) * p.y + sin(t * theta) * q.y  / sin(theta));
	rQ.z = (sin((1-t) * theta) * p.z + sin(t * theta) * q.z  / sin(theta));
	printf("W : %f \nX : %f \nY : %f \nZ : %f \n", rQ.w, rQ.x, rQ.y, rQ.z );
	
	return rQ;
}

float dot(quaternion p, quaternion q)
{
	float r = 0;
	r+= (p.w * q.w);
	r+= (p.x * q.x);
	r+= (p.z * q.z);
	r+= (p.y * q.y);
	return r;

}

quaternion normalize(quaternion q)
{
	float t;
	t = sqrt( pow(q.w, 2) + pow(q.x, 2) + pow(q.y, 2) + pow(q.z, 2) );
	quaternion r;
	r.w = q.w / t;
	r.x = q.x / t;
	r.y = q.y / t;
	r.z = q.z / t;
	return r;
}