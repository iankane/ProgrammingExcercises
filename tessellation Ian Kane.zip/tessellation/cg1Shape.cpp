/**
 * shapes.cpp
 *
 * Routines for tessellating a number of basic shapes
 *
 * Students are to supply their implementations for the
 * functions in this file using the function "addTriangle()" to do the 
 * tessellation.
 *
 */

#ifdef __APPLE__
#include <OPENGL/gl.h>
#else
#include <GL/glew.h>
#include <GL/gl.h>
#endif

#include "simpleShape.h"
#include "cg1Shape.h"
#include <math.h>
#include <vector>

using namespace std;

// useful constant for cone circle points
#define DEGREE_RADIAN_FACTOR .0174532925

/**
 * makeCube - Create a unit cube, centered at the origin, with a given number
 * of subdivisions in each direction on each face.
 *
 * @param subdivision - number of equal subdivisons to be made in each 
 *        direction along each face
 *
 * Can only use calls to addTriangle()
 */
void makeCube (int subdivisions)
{
	
	float t = 1/(float)subdivisions;
	float y = 0.0;
	float x = 0.0;
	float z = 0.0;

	//for each side
	//for top and bottom
	for(int s = 0; s < 2; s++)
	{
		if(s == 0)
			x = -0.5;
		else
			x = 0.5;
		//for each row
		for(int i = 0; i < subdivisions; i++)
		{
			//normalize the y
			y = (t*i)-0.5;
			//for each column
			for(int j = 0; j < subdivisions; j++)
			{
				//normalize the x
				z = (t*j)-0.5;
				//create the 3 points of the triangle
				Point3 p1(x,y,z);
				Point3 p2(x,(y+t),z);
				Point3 p3(x,(y+t),(z+t));
				Point3 p4(x,y,(z+t));
				//add a square made up of 2 triangles
				if(s==0)
				{
					addTriangle(p1,p2,p3);
					addTriangle(p3,p4,p1);
				}
				else
				{
					addTriangle(p3,p2,p1);
					addTriangle(p1,p4,p3);
				}
			}
				//reset to next column
		}
			//reset for next row
	}//reset for next side

	//for left and right
	
	for(int s = 0; s < 2; s++)
	{
		if(s == 0)
			z = -0.5;
		else
			z = 0.5;

		//for each row
		for(int i = 0; i < subdivisions; i++)
		{
			//normalize the y
			y = (t*i)-0.5;
			//for each column
			for(int j = 0; j < subdivisions; j++)
			{
				//normalize the x
				x = (t*j)-0.5;

				//create the 3 points of the triangle
				Point3 p1(x,y,z);
				Point3 p2(x,(y+t),z);
				Point3 p3((x+t),(y+t),z);
				Point3 p4((x+t),y,z);
				//add a square made up of 2 triangles
				if(s==0)
				{
					addTriangle(p3,p2,p1);
					addTriangle(p1,p4,p3);
				}
				else
				{
					addTriangle(p1,p2,p3);
					addTriangle(p3,p4,p1);
				}
			}
				//reset to next column
		}
			//reset for next row
	}
		
		//reset for next side
	
	//for front and back)
	
	for(int s = 0; s < 2; s++)
	{
		if(s == 0)
			y = -0.5;
		else
			y = 0.5;
		//for each row
		for(int i = 0; i < subdivisions; i++)
		{
			//normalize the z
			z = (t*i)-0.5;
			//for each column
			for(int j = 0; j < subdivisions; j++)
			{
				//normalize the x
				x = (t*j)-0.5;
				//create the 3 points of the triangle
				Point3 p1(x,y,z);
				Point3 p2(x,y,(z+t));
				Point3 p3((x+t),y,(z+t));
				Point3 p4((x+t),y,z);
				//add a square made up of 2 triangles
				if(s==0)
				{
					addTriangle(p1,p2,p3);
					addTriangle(p3,p4,p1);
				}
				else
				{
					addTriangle(p3,p2,p1);
					addTriangle(p1,p4,p3);
				}
			}
				//reset to next column
		}
			//reset for next row
	}
		
		//reset for next side
	
}


/**
 * makeCylinder - Create polygons for a cylinder with unit height, centered at
 * the origin, with separate number of radial subdivisions and height 
 * subdivisions.
 *
 * @param radius - Radius of the base of the cylinder
 * @param radialDivision - number of subdivisions on the radial base
 * @param heightDivisions - number of subdivisions along the height
 *
 * Can only use calls to addTriangle()
 */
void makeCylinder (float radius, int radialDivisions, int heightDivisions)
{
	// minimum sides is 3
    if( radialDivisions < 3 ) {
        radialDivisions = 3;
    }
	//central points for top and bottom
	Point3 fixedTop(0,0.5,0);
	Point3 fixedBottom(0,-0.5,0);
	
	//get divison interval
	float t = 1/(float) heightDivisions;
	//angle of the point, in radians
	float r = (360 /  radialDivisions) *  DEGREE_RADIAN_FACTOR;
	
	//begin with top and bottom
	for(int i = 0; i < radialDivisions; i++)
	{
		//current a
		float a = r*i;
		//next a
		
		float a2= (r* (i+1));
		//points for the 
		float x = (radius * cos(a));
		float z = (radius * sin(a));
		float x1 = (radius * cos(a2));
		float z1 = (radius * sin(a2));
		Point3 p1(x,0.5,z);
		Point3 p2(x1,0.5,z1);
		addTriangle(fixedTop,p2,p1);
		//addTriangle(fixedTop,p2,p1);
		Point3 p3(x,-0.5,z);
		Point3 p4(x1,-0.5,z1);
		//addTriangle(fixedBottom,p3,p4);
		addTriangle(fixedBottom,p3,p4);
		
		//goes from end to end and makes the triangles
		for(int j=0; j < heightDivisions; j++)
		{
			float h = (t*j)-0.5;

			Point3 p10(x,h,z);
			Point3 p11(x,(h+t),z);
			Point3 p12(x1,(h+t),z1);
			Point3 p13(x1,h,z1);
			
			addTriangle(p10,p11,p12);
			addTriangle(p12,p13,p10);
		}
	}

}


/**
 * makeCone - Create polygons for a cone with unit height, centered at the
 * origin, with separate number of radial subdivisions and height 
 * subdivisions.
 *
 * @param radius - Radius of the base of the cone
 * @param radialDivision - number of subdivisions on the radial base
 * @param heightDivisions - number of subdivisions along the height
 *
 * Can only use calls to addTriangle()
 */
void makeCone (float radius, int radialDivisions, int heightDivisions)
{
    // cannot have fewer than three sides
    if( radialDivisions < 3 ) {
       radialDivisions = 3;
    }
	//central points for top and bottom
	Point3 fixedTop(0,0.5,0);
	Point3 fixedBottom(0,-0.5,0);
	
	//get divison interval
	float t = 1/(float) heightDivisions;
	//angle of the point, in radians
	float r = (360 /  radialDivisions) *  DEGREE_RADIAN_FACTOR;
	
	//begin with top and bottom
	for(int i = 0; i < radialDivisions; i++)
	{
		//current a
		float a = r*i;
		//next a
		
		float a2= (r* (i+1));
		
		//points for the 
		float x = (radius * cos(a));
		float z = (radius * sin(a));
		float x1 = (radius * cos(a2));
		float z1 = (radius * sin(a2));
		Point3 p1(x,-0.5,z);
		Point3 p2(x1,-0.5,z1);
		//addTriangle(fixedTop,p2,p1);
		addTriangle(fixedBottom,p2,p1);
		/*
		
		Point3 p3(x,-0.5,z);
		Point3 p4(x1,-0.5,z1);
		addTriangle(fixedBottom,p3,p4);*/
		
		//goes from end to end and makes the triangles
		for(int j=0; j < heightDivisions; j++)
		{
			float h = (t*j)-0.5 ;
			//float slope = 1/radius;
			float ratio = radius / heightDivisions;
			
			Point3 p10(x,h,z);
			Point3 p13(x1,h,z1);
			//changes the x,z,x1,z1 to be the next one up.
			x = ((radius-(ratio*(j+1))) * cos(a));
			z = ((radius-(ratio*(j+1))) * sin(a));
			x1 = ((radius-(ratio*(j+1))) * cos(a2));
			z1 = ((radius-(ratio*(j+1))) * sin(a2));
			Point3 p11(x,(h+t),z);
			Point3 p12(x1,(h+t),z1);
			//adds the triangles to the figure
			addTriangle(p12,p11,p10);
			addTriangle(p10,p13,p12);
			
		}
	}

}


/**
 * makeSphere - Create sphere of a given radius, centered at the origin, 
 * using spherical coordinates with separate number of thetha and 
 * phi subdivisions.
 *
 * @param radius - Radius of the sphere
 * @param subdivisions - number of subdivisions
 *
 * Can only use calls to addTriangle, and the vertices vector.
 */
void makeSphere (float radius, int subdivisions)
{
	// don't go above 5 subdivisions
	if (subdivisions > 5) {
		subdivisions = 5;
	}
	float five = 5.0;
	float a = (2.0 / 1.0 + (float) sqrt(five));

	//icosahedron verts
	Point3 tv0(0 , a, -1);
    Point3 tv1(-a, 1, 0);
    Point3 tv2(a, 1, 0);
    Point3 tv3(0, a, 1);
    Point3 tv4(-1, 0, a);
    Point3 tv5(0, -a, 1);
    Point3 tv6(1, 0, a);
    Point3 tv7(1, 0, -a);
    Point3 tv8(0, -a, -1);
    Point3 tv9(-1, 0, -a);
    Point3 tv10(-a, -1, 0);
    Point3 tv11(a, -1, 0);

	//creates the triangles in original mesh
	vector< vector<Point3> > triangles;

	//for each triangle in the icosahedron
		//create a triange and add it to the triangeles vector
		addTriangle(tv0,tv1,tv2);		//t0
		addTriangle(tv3,tv2,tv1);		//t1
		addTriangle(tv3,tv4,tv5);		//t2
		addTriangle(tv3,tv5,tv6);		//t3
		addTriangle(tv0,tv7,tv8);		//t4
		addTriangle(tv0,tv8,tv9);		//t5
		addTriangle(tv5,tv10,tv11);		//t6
		addTriangle(tv8,tv11,tv10);		//t7
		addTriangle(tv1,tv9,tv4);		//t8
		addTriangle(tv10,tv4,tv9);		//t9
		addTriangle(tv2,tv6,tv7);		//t10
		addTriangle(tv11,tv7,tv6);		//t11
		addTriangle(tv3,tv1,tv4);		//t12
		addTriangle(tv3,tv6,tv2);		//t13
		addTriangle(tv0,tv9,tv1);		//t14
		addTriangle(tv0,tv2,tv7);		//t15
		addTriangle(tv8,tv10,tv9);		//t16
		addTriangle(tv8,tv7,tv11);		//t17
		addTriangle(tv5,tv4,tv10);		//t18
		addTriangle(tv5,tv11,tv6);		//t19

	//subdivide each triangle into 3 new ones subdivisions number of times
	/*for(int i = 0; i < subdivisions; i++)
	{
		vector< vector<Point3> > tempTriangles;
		for( int j = 0; j < triangles.size(); j++)
		{
			//subdivide the side
		}
		triangles = tempTriangles;
	}*/
	//normalize each triangle vertex
	//create triangles in order 

}
