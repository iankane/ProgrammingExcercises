D = zoom in
d = zoom out
p = rotate up
P = rotate down
t = rotate counterclockwise
T = rotate clockwise
r = change seed value.