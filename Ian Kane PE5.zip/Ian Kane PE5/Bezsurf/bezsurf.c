/*  bezsurf.c
 *  This program renders a wireframe Bezier surface,
 *  using two-dimensional evaluators.
 */
#include <stdlib.h>
#include <glut.h>
#include <math.h>

#define PI  3.14159
#define rowSize 32
#define SCREEN_WIDTH  1200.0f
#define SCREEN_HEIGHT 768.0f

static float randnum (float min, float max)
{
    return ((rand()%1000 /1000.0f) * (max - min) + min);
} 

#define fractRand(v) randnum (-v, v)

static float distance = 10 , phi = 0, theta = 0, h = 0.7;
static int row = 0 , col = 0;
GLdouble xG, yG, zG;

GLfloat ctrlpoints[33*33];

void initCtrlPoints()
{
	int i, j;
	for(i = 0; i < 33; i++)
	{
		for(j = 0; j < 33; j++)
		{
			ctrlpoints[i*j] = 0;
		}
	}
}


static float avgDiamondVals (int i, int j, int stride,
                 int size, int subSize, GLfloat *fa)
{
 
    if (i == 0)
    return ((float) (fa[(i*size) + j-stride] +
             fa[(i*size) + j+stride] +
             fa[((subSize-stride)*size) + j] +
             fa[((i+stride)*size) + j]) * .25f);
    else if (i == size-1)
    return ((float) (fa[(i*size) + j-stride] +
             fa[(i*size) + j+stride] +
             fa[((i-stride)*size) + j] +
             fa[((0+stride)*size) + j]) * .25f);
    else if (j == 0)
    return ((float) (fa[((i-stride)*size) + j] +
             fa[((i+stride)*size) + j] +
             fa[(i*size) + j+stride] +
             fa[(i*size) + subSize-stride]) * .25f);
    else if (j == size-1)
    return ((float) (fa[((i-stride)*size) + j] +
             fa[((i+stride)*size) + j] +
             fa[(i*size) + j-stride] +
             fa[(i*size) + 0+stride]) * .25f);
    else
    return ((float) (fa[((i-stride)*size) + j] +
             fa[((i+stride)*size) + j] +
             fa[(i*size) + j-stride] +
             fa[(i*size) + j+stride]) * .25f);
}

static float avgSquareVals (int i, int j, int stride, int size, GLfloat *fa)
{
  
    return ((float) (fa[((i-stride)*size) + j-stride] +
             fa[((i-stride)*size) + j+stride] +
             fa[((i+stride)*size) + j-stride] +
             fa[((i+stride)*size) + j+stride]) * .25f);
}


void fill2DFractArray (float *fa, int size,
		       int seedValue, float heightScale, float h)
{
    int	i, j;
    int	stride;
    int	oddline;
    int subSize;
	float ratio, scale;

    /* subSize is the dimension of the array in terms of connected line
       segments, while size is the dimension in terms of number of
       vertices. */
    subSize = size;
    size++;
    
    /* initialize random number generator */
    srand (seedValue);
    

	/* Set up our roughness constants.
	   Random numbers are always generated in the range 0.0 to 1.0.
	   'scale' is multiplied by the randum number.
	   'ratio' is multiplied by 'scale' after each iteration
	   to effectively reduce the randum number range.
	   */
	ratio = (float) pow(2,-h);
	scale = heightScale * ratio;

    /* Seed the first four values. For example, in a 4x4 array, we
       would initialize the data points indicated by '*':

           *   .   .   .   *

           .   .   .   .   .

           .   .   .   .   .

           .   .   .   .   .

           *   .   .   .   *

       In terms of the "diamond-square" algorithm, this gives us
       "squares".

       We want the four corners of the array to have the same
       point. This will allow us to tile the arrays next to each other
       such that they join seemlessly. */

    stride = subSize / 2;
    fa[(0*size)+0] =
      fa[(subSize*size)+0] =
        fa[(subSize*size)+subSize] =
          fa[(0*size)+subSize] = 0.f;
    

    /* Now we add ever-increasing detail based on the "diamond" seeded
       values. We loop over stride, which gets cut in half at the
       bottom of the loop. Since it's an int, eventually division by 2
       will produce a zero result, terminating the loop. */
    while (stride) {
		/* Take the existing "square" data and produce "diamond"
		   data. On the first pass through with a 4x4 matrix, the
		   existing data is shown as "X"s, and we need to generate the
	       "*" now:

               X   .   .   .   X

               .   .   .   .   .

               .   .   *   .   .

               .   .   .   .   .

               X   .   .   .   X

	      It doesn't look like diamonds. What it actually is, for the
	      first pass, is the corners of four diamonds meeting at the
	      center of the array. */
		for (i=stride; i<subSize; i+=stride) {
			for (j=stride; j<subSize; j+=stride) {
				fa[(i * size) + j] =
					scale * fractRand (.5f) +
					avgSquareVals (i, j, stride, size, fa);
				j += stride;
			}
			i += stride;
		}

		/* Take the existing "diamond" data and make it into
	       "squares". Back to our 4X4 example: The first time we
	       encounter this code, the existing values are represented by
	       "X"s, and the values we want to generate here are "*"s:

               X   .   *   .   X

               .   .   .   .   .

               *   .   X   .   *

               .   .   .   .   .

               X   .   *   .   X

	       i and j represent our (x,y) position in the array. The
	       first value we want to generate is at (i=2,j=0), and we use
	       "oddline" and "stride" to increment j to the desired value.
	       */
		oddline = 0;
		for (i=0; i<subSize; i+=stride) {
		    oddline = (oddline == 0);
			for (j=0; j<subSize; j+=stride) {
				if ((oddline) && !j) j+=stride;

				/* i and j are setup. Call avgDiamondVals with the
				   current position. It will return the average of the
				   surrounding diamond data points. */
				fa[(i * size) + j] =
					scale * fractRand (.5f) +
					avgDiamondVals (i, j, stride, size, subSize, fa);

				/* To wrap edges seamlessly, copy edge values around
				   to other side of array */
				if (i==0)
					fa[(subSize*size) + j] =
						fa[(i * size) + j];
				if (j==0)
					fa[(i*size) + subSize] =
						fa[(i * size) + j];

				j+=stride;
			}
		}

		/* reduce random number range. */
		scale *= ratio;
		stride >>= 1;
    }

}
/*
void generateTerrain()
{
	int length = 16;
	int i, j;

	while(length > 0)
	{
		for(i = 0; i < 33; i++)
		{
			for(j = 0; j < 33; j++)
			{
				ctrlpoints[i][j] = (rand() % 12 - 6) +  avgDiamondVals(i,j,length,32,16,ctrlpoints[i]);
			}
		}
		length = length -1;
		for(i = 0; i < 33; i++)
		{
			for(j = 0; j < 33; j++)
			{
				ctrlpoints[i][j] = (rand() % 12 - 6) + avgSquareVals(i,j,length,32,ctrlpoints[i]);
			}
		}
		length = length -1;
		h = h/2;
	}
	h = .7;
}
*/
void display(void)
{
   int i, j;
   
   /* these statements moved to rehape() 
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   */
   
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   //gluPerspective(40, SCREEN_WIDTH/SCREEN_HEIGHT, -16, 16.0);

    xG = distance * cos(phi/(180 * PI)) * sin(theta/180*PI);
    yG = distance * sin(phi/180 * PI);
    zG = distance * cos(phi/180 * PI) * cos(theta/180*PI);
	gluLookAt(xG,yG,zG,0,0,0,0,1,0);
	glEnd();
	
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
  
    // Evaluate the grid using lines
    /*
   for (j = 0; j <= 33; j++) {
   	
   	  glColor3f(1.0, 0.0, 0.0);  
      glBegin(GL_LINE_STRIP);
        for (i = 0; i <= 33; i++)
           glEvalCoord2f((GLfloat)i, (GLfloat)j);
      glEnd();
      
      glColor3f(0.0, 1.0, 1.0);
      glBegin(GL_LINE_STRIP);
        for (i = 0; i <= 30; i++)
          glEvalCoord2f((GLfloat)j, (GLfloat)i);
      glEnd();
   }*/
   glPointSize(3.0);
    glColor3f(0.0, 1.0, 0.5);
    for(j =0; j < rowSize; j++)
	{
		glBegin(GL_LINE_STRIP);
		for (i = 0; i < rowSize; i++) 
		{
			glVertex3f(j-16, ctrlpoints[j*i], i-16);
		}
	glEnd();
	}

	 for(j =0; j < rowSize; j++)
	{
		glBegin(GL_LINE_STRIP);
		for (i = 0; i < rowSize; i++) 
		{
			glVertex3f(i-16, ctrlpoints[j*i], j-16);
		}
	glEnd();
	}
/*
    glBegin(GL_POINTS);
	for (i = 0; i < rowSize; i++) 
	{
		for(j = 0; j < rowSize; j++)
		{
			glVertex3f(j - 16, ctrlpoints[j*i], i-16);
		}
	}
	glEnd();
   */
   glColor3f(1.0, 1.0, 1.0);
   glutWireCube(rowSize);
   // Evaluate using mesh
   
   
  // glEvalMesh2(GL_LINE,0,16,0,16);
   
  
   glFlush();
}

void init(void)
{
	fill2DFractArray(ctrlpoints,rowSize,5050508,2,0.5);
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0*0]);
   
   glEnable(GL_MAP2_VERTEX_3);
   
   glMapGrid2f(16, 0.0, 1.0, 16, 0.0, 1.0);
   
   glEnable(GL_DEPTH_TEST);
   glShadeModel(GL_FLAT);
  
}

void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(40, SCREEN_WIDTH/SCREEN_HEIGHT, -10, 10);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
		case 'd':
			distance = distance + 1;
			glutPostRedisplay();
			break;
		case 'D':
			distance = distance - 1;
			glutPostRedisplay();
			break;
		case 'r':
			fill2DFractArray(ctrlpoints,rowSize,fractRand(1234),2,0.5);
			glLoadIdentity();
			glutPostRedisplay();
		case 't':
			theta++;
			glutPostRedisplay();
			break;
		case 'T':
			theta--;
			glutPostRedisplay();
			break;
		case 'p':
			if(phi < 90)
				phi++;
			glutPostRedisplay();
			break;
		case 'P':
			if(phi > -90)
				phi--;
			glutPostRedisplay();
			break;
		default:
			break;
	}
}	

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (500, 500);
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0;
}

