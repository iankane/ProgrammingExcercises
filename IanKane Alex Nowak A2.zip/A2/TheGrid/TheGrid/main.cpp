#include <iostream>
#include <time.h>
using namespace std;


#pragma region structs

struct pixel
{
	int c;
	char color;
} white, grey, black;

struct image
{
	pixel** picture;
	image ();
}imageOne, imageTwo, imageThree;


#pragma endregion

#pragma region constructors

image ::image () {
};

#pragma endregion



#pragma endregion


#pragma region values

enum { White, Grey, Black };	//enumeration
int rows;
int columns;


#pragma endregion

#pragma region inits

void initPixel()
{
	white.c = White;
	white.color =(char) 176;
	grey.c = Grey;
	grey.color = (char) 177;
	black.c = Black;
	black.color = (char) 178;
}

void imageInit (int rows, int columns, pixel**& picture) {
	picture = new pixel*[columns];
	for (int i = 0; i < columns; i++) {
		picture [i] = new pixel[rows];
	}
}

#pragma region functions

#pragma region Destructor

void destructor()
{
	delete(imageOne.picture);
	delete(imageTwo.picture);
	delete(imageThree.picture);
}


#pragma endregion
	
#pragma region Random Image

pixel** generateImage(const int &a,const int &b)
{
	pixel ** returnarray;
	int temp;
	returnarray = new pixel*[a];

	for(int i = 0; i < a; i++)
	{
		returnarray[i] = new pixel[b];
	}


	cout << time(NULL) << endl;

	for(int i = 0; i<a; i++)
	{
		for(int j = 0; j < b; j++)
		{

			temp = rand() % 3 + 1;

			if(temp == 1)
			{
				returnarray[i][j] = white;
			}
			else if(temp == 2)
			{
				returnarray[i][j] = grey;
			}
			else
			{
				returnarray[i][j] = black;
			}
		}
	}

	return returnarray;

	/*
	int ** returnarray;
	returnarray = new int*[a];

	for(int i = 0; i < a; i++)
	{
		returnarray[i] = new int[b];
	}

	srand ( time(NULL));

	for(int i = 0; i<a; i++)
	{
		for(int j = 0; j < b; j++)
		{
			returnarray[i][j] = rand() % 3 + 1;
		}
	}

	return returnarray;
	*/
}

#pragma endregion

#pragma region input

void input(int &a ,int &b)
{
	cout << "Input numbers between 0 and 10" << endl;
	cout << "how many rows do you want?" << endl;
	cin >> a;
	cout << "how many columns do you want?" << endl;
	cin >> b;
	if(a < 1 || a > 11 || b < 0 || b > 11)
	{
		cout << "Insert numbers between 0 and 10" << endl;
		input(a,b);
	}
	
}

#pragma endregion

#pragma region Output

void output(const int a, const int b, image g)
{
	for(int i = 0; i < a; i++)
	{
		for(int j = 0; j < b; j++)
		{
			cout << g.picture[i][j].color;
		}
		cout << endl;
	}
	cout << endl;
}

#pragma endregion

#pragma region combine
//combine two images
void combine(int a, int b, image picOne, image picTwo)
{

	for(int i = 0; i < rows; i++)
	{
		for(int j = 0; j < columns; j++)
		{
			if(picOne.picture[i][j].c == Black)
			{
				imageThree.picture[i][j] = black;
			}
			else if (picOne.picture[i][j].c == White)
			{
				imageThree.picture[i][j] = picTwo.picture[i][j];
			}
			else
			{
				if(picTwo.picture[i][j].c == Black)
				{
					imageThree.picture[i][j] = black;
				}
				else 
				{
					imageThree.picture[i][j] = grey;
				}
			}
		}
	}
}

#pragma endregion

#pragma endregion


#pragma region Main function

int main()
{
	srand ( time(NULL));
	bool looper = true; //loop variable
	char loopCheck;	//looper input
	while(looper)
	{

		input(rows,columns);
		initPixel();
		//declare the images
		imageOne = image();
		imageTwo = image();
		imageThree = image();
		//initialize the pixel arrays
		imageInit(rows, columns, imageOne.picture);
		imageInit(rows, columns, imageTwo.picture);
		imageInit(rows, columns, imageThree.picture);
		//create the random images
		imageOne.picture = generateImage(rows,columns);
		imageTwo.picture = generateImage(rows,columns);
		cout << "First Image" << endl;
		output(rows,columns,imageOne);
		cout << "Second Image" << endl;
		output(rows,columns,imageTwo);

		combine(rows,columns,imageOne,imageTwo);
		cout << "Combined Image" << endl;
		output(rows,columns,imageThree);

		cout << " Type:" << endl;
		cout << "r = retry, q = quit" << endl;
		cin >> loopCheck;
		if(loopCheck == 'q')
			looper = false;
	}

	destructor();
}


#pragma endregion

