//
//  tessMain.cpp
//  
//
//  Main program for tessellation assignment.
//
//  Students should not be modifying this file.
//

#include <stdlib.h>
#include <iostream>

#ifdef __APPLE__ 
#include <GLUT/GLUT.h>
#include <OpenGL/gl.h>
#else
#include <GL/glew.h>
#include <GL/glut.h>
#include <GL/gl.h>
#endif

#include "shaderProgram.h"
#include "simpleShape.h"

using namespace std;

#define BUFFER_OFFSET(i) ((char *)NULL + (i))
#define DEGREE_RADIAN_FACTOR .0174532925

// vertex and element array IDs
// one for each object to be drawn
bool bufferInit = false;
GLuint buffer[2], ebuffer[2];
int NumElements;

// program IDs...for program and parmeters
GLuint program, theta, trans;

// values for uniform shader variables,
GLfloat angles[3] = {0.0, 0.0, 0.0};
GLfloat transData[3] = { 1.0, 0.0, 1.0 };
GLfloat scaleData[3] = {1.0, 1.0, 1.0 };



void 
createShapes()
{
    // define the triangles for your shapes here and send the vertex data
	// to OpenGL
	
	clearShape();

	//Creates a cylinder
	int radialDivisions = 3;
	int radius = 0.5;
	int heightDivisions = 1;


	if( radialDivisions < 3 ) {
        radialDivisions = 3;
    }
	//central points for top and bottom
	
	//get divison interval
	float t = 1/(float) heightDivisions;
	//angle of the point, in radians
	float r = (360 /  radialDivisions) *  DEGREE_RADIAN_FACTOR;
	
	//begin with top and bottom
	for(int i = 0; i < radialDivisions; i++)
	{
		//current a
		float a = r*i;
		//next a
		
		float a2= (r* (i+1));

		//points for the 
		float x = (radius * cos(a));
		float z = (radius * sin(a));
		float x1 = (radius * cos(a2));
		float z1 = (radius * sin(a2));
		addTriangle(0,0.5,0,x1,0.5,z1,x,0.5,z);
		addTriangle(0,-0.5,0,x,-0.5,z,x1,-0.5,z1);
		
		//goes from end to end and makes the triangles
		for(int j=0; j < heightDivisions; j++)
		{
			float h = (t*j)-0.5;

			addTriangle(x,h,z,x,(h+t),z,x1,(h+t),z1);
			addTriangle(x1,(h+t),z1,x1,h,z1,x,h,z);
		}
	}
	//end creation of the cylinder
		 
	// get the points for your shape
	int NumElements;
    NumElements = nVerticies() / 3;
    float *points = getVerticies();
    int dataSize = nVerticies() * 4 * sizeof (float);
    GLushort *elements = getElements();
    int edataSize = nVerticies() * sizeof (GLushort);
    
    // setup the vertex buffer
    if (bufferInit) glDeleteBuffers (2, &*buffer);
    glGenBuffers( 2, &*buffer );
    glBindBuffer( GL_ARRAY_BUFFER, *buffer );
    glBufferData( GL_ARRAY_BUFFER, dataSize, points, GL_STATIC_DRAW );
    bufferInit = true;
    
    // setup the element buffer
    if (bufferInit) glDeleteBuffers (2, &*ebuffer);
    glGenBuffers( 2, &*ebuffer );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, *ebuffer );
    glBufferData( GL_ELEMENT_ARRAY_BUFFER, edataSize, elements, GL_STATIC_DRAW );
    
    glUseProgram( program );
    
    // set up vertex arrays
    GLuint vPosition = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( vPosition );
    glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0,
                          BUFFER_OFFSET(0) );
    
    // uniform variables
    theta = glGetUniformLocation(program, "theta");


}


// OpenGL initialization 
void init() {
    
    // Load shaders and use the resulting shader program
    program = setUpAShader( "vshader.glsl", "fshader.glsl" );
    if (!program) {
        cerr << "Error setting up shaders" << endl;
        exit(1);
    }
    
	// Some openGL initialization...probably best to keep
    glEnable( GL_DEPTH_TEST ); 
    glEnable(GL_CULL_FACE);
    glClearColor( 1.0, 1.0, 1.0, 1.0 );
    
    // create the geometry for your shapes.
    createShapes();

	
}


void
display( void )
{
    // clear and draw params..keep these
	// for this assignment, we will continue to use wireframe
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glCullFace(GL_BACK);
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
    
	// draw your shapes here

	glMatrixMode(GL_MODELVIEW);
	//rotation
	//glUniform3fv(theta,1,angles);
	glLoadIdentity();
	//translation
	glTranslatef(1.0, 2.0, -3.0);

	//draws the shapes
	glDrawElements (GL_TRIANGLES, nVerticies(),  GL_UNSIGNED_SHORT, (void *)0);
    
    // swap the buffers
    glutSwapBuffers();
}


void
keyboard( unsigned char key, int x, int y )
{
    switch( key ) {
		case 033:  // Escape key
        case 'q': case 'Q':
            exit( 0 );
        break;
    } 
    
    glutPostRedisplay();
}

int main (int argc, char **argv)
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
    glutInitWindowSize( 512, 512 );
    glutCreateWindow( "CG1 - Tessellation Assignment" );
    
#ifndef __APPLE__
    glewInit();
#endif
    
    init();
    
    glutDisplayFunc( display );
    glutKeyboardFunc( keyboard );
    
    glutMainLoop();
    return 0;
}

