﻿// @Summary:	Tic Tac Toe
// @Course:		4080-417-02 (Visual C++)
// @Term:		2121 (Fall 2012 - 2013)
// @Professor:	David Schwartz
// @Author:		Ian Kane and Alex Nowak


#include <iostream>
#include <malloc.h>
using namespace std;

void print(char[][3], int);			//forward declaration of print
void print2(int a[][3], int );		//forward declaration of print2
bool gameWon(char[][3]);			//forward declaration of gameWon

#pragma region graphics
	//box drawing characters, for printing the board
	/*
	char HLINE = '─';
	char VLINE = '│';
	char NW = '┌';
	char NE = '┐';
	char SW = '└';
	char SE = '┘';
	char T_W = '├';
	char T_E = '┤';
	char T_N = '┬';
	char T_S = '┴';
	char CROSS = '┼';
*/

#pragma endregion

int main() {

#pragma region Variables

	//char board[3][3] = { '-','-','-','-','-','-','-','-','-'};		//Game Board Array, stores characters, Couldn't use because of incorrect declaration
	char (*gameBoard)[3] = new char[3][3];							// Game Board using New
	for (int r = 0; r < 3; r++)
		for (int c = 0; c < 3; c++)
			gameBoard[r][c] = '-';
	int display[3][3] = {1,2,3,4,5,6,7,8,9};						//Display array for the player imput
	int i=0;														//Loop variable
	int p=0;														//player variable
	int userInput;													//player imput
	int boxes=0;													//how many boxes used
	bool running = true;											//game loop boolean
	
#pragma endregion

#pragma region Game Loop
	
	while(running)//outside game loop, checks if the running boolean is true
	{
		//INPUT
		if(p==0)//o's turn
		{
			cout << "O's turn, where do you want to place your o?" << endl;				//Tells the player turn
			print2(display,3);															//Displays the input board
			cout << "Type in the number of the space you would like to go to" << endl;	//Tells the player how to imput
			cin >> userInput;															//user input
			--userInput;
			//processes input
			//board[userInput] = 'o';			
			


			if(userInput < 3) {					//if user's input on first row
				if(gameBoard[0][userInput] == '-')
					gameBoard[0][userInput] = 'o';
			}
			else if(userInput > 6) {			//if user's input is on third row
				if (gameBoard[2][userInput-6] == '-')
						gameBoard[2][userInput-6] = 'o';
			}
			else {								//if user's input is on the second row
				if(gameBoard[1][userInput-3] == '-')
					gameBoard[1][userInput-3] = 'o';
			}
				

		}

		else//x's turn
		{
			cout << "X's turn, where do you want to place your X?" << endl;				//Tells the player turn
			print2(display,3);															//Displays the input board
			cout << "Type in the number of the space you would like to go to" << endl;	//Tells the player how to imput
			cin >> userInput;															//user input
			--userInput;
			//processes input
			//board[userInput] = 'x';			
			
			if(userInput < 3) {				//if user's input on first row
				if(gameBoard[0][userInput] == '-')
					gameBoard[0][userInput] = 'x';
			}
			else if(userInput > 6) {		//if user's input is on third row
				if(gameBoard[2][userInput-6] == '-')
					gameBoard[2][userInput-6] = 'x';
			}
			else { 								//if user's input is on the second row
				if(gameBoard[1][userInput-3] == '-')
					gameBoard[1][userInput-3] = 'x';
			}
				
		}

		boxes ++;				//increments boxes
		print(gameBoard,3);			//displays the current board

		
		//end condition
		if (gameWon(gameBoard))
		{
			if (p == 0)
			{ cout << "Congratulations Player 1, you have won!"; }

			else
			{ cout << "Congratulations Player 2, you have won!"; }

			running = false;
		}

		//Tie game
		else if(boxes == 9)
		{
			running = false;
			cout << "Tie Game!" ;
		}
		
		//Swaps the player counter
		if(p != 0)
			p = 0;
		else
			p = 1;
	}

#pragma endregion

#pragma region Finishing

print(gameBoard,3);				// calls the print method
delete [] gameBoard;			//deletes the board
cout << "Board Deleted";		//tells us the board got deleted
system("pause");				// because my Visual Studio is evil

#pragma endregion
}

#pragma region General Functions

#pragma region Game Won

bool gameWon(char a[][3])
{
	//wins for x
	//horizontal wins
	if (a[0][0] == 'x' && a[0][1] == 'x' && a[0][2] == 'x')
		return true;

	else if (a[1][0] == 'x' && a[1][1] == 'x' && a[1][2] == 'x')
		return true;

	else if (a[2][0] == 'x' && a[2][1] == 'x' && a[2][2] == 'x')
		return true;

	//vertical wins
	else if (a[0][0] == 'x' && a[1][0] == 'x' && a[2][0] == 'x')
		return true;

	else if (a[0][1] == 'x' && a[1][1] == 'x' && a[2][1] == 'x')
		return true;

	else if (a[0][2] == 'x' && a[1][2] == 'x' && a[2][2] == 'x')
		return true;

	//diagonal wins
	else if (a[0][0] == 'x' && a[1][1] == 'x' && a[2][2] == 'x')
		return true;

	else if (a[0][2] == 'x' && a[1][1] == 'x' && a[2][0] == 'x')
		return true;

	//wins for o
	//horizontal wins
	else if (a[0][0] == 'o' && a[0][1] == 'o' && a[0][2] == 'o')
		return true;

	else if (a[1][0] == 'o' && a[1][1] == 'o' && a[1][2] == 'o')
		return true;

	else if (a[2][0] == 'o' && a[2][1] == 'o' && a[2][2] == 'o')
		return true;

	//vertical wins
	else if (a[0][0] == 'o' && a[1][0] == 'o' && a[2][0] == 'o')
		return true;

	else if (a[0][1] == 'o' && a[1][1] == 'o' && a[2][1] == 'o')
		return true;

	else if (a[0][2] == 'o' && a[1][2] == 'o' && a[2][2] == 'o')
		return true;

	//diagonal wins
	else if (a[0][0] == 'o' && a[1][1] == 'o' && a[2][2] == 'o')
		return true;

	else if (a[0][2] == 'o' && a[1][1] == 'o' && a[2][0] == 'o')
		return true;

	else return false;
}

#pragma endregion

#pragma region print function
//canabalized from E3, just changed to char from int.
void print(char a[][3], int ROWS) {
	cout << endl;
	for (int row=0 ; row < ROWS ; row++) {
		for (int col=0 ; col < 3 ; col++)
			cout << a[row][col];
		cout << endl;
	}
}
//straight up canabalized from E3
void print2(int a[][3], int ROWS) {
	cout << endl;
	for (int row=0 ; row < ROWS ; row++) {
		for (int col=0 ; col < 3 ; col++)
			cout << a[row][col];
		cout << endl;
	}
}
/*
void print() {
	cout << 

}*/
#pragma endregion

#pragma endregion


