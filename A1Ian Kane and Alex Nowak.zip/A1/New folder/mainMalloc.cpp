﻿// @Summary:	Tic Tac Toe
// @Course:		4080-417-02 (Visual C++)
// @Term:		2121 (Fall 2012 - 2013)
// @Professor:	David Schwartz
// @Author:		Ian Kane and Alex Nowak


#include <iostream>
#include <malloc.h>
using namespace std;

void print(char*, int);			//forward declaration of print
void print2(int a[][3], int );		//forward declaration of print2
bool gameWon(char*);			//forward declaration of gameWon

#pragma region graphics
	//box drawing characters, for printing the board
/*
	char HLINE = '─';
	char VLINE = '│';
	char NW = '┌';
	char NE = '┐';
	char SW = '└';
	char SE = '┘';
	char T_W = '├';
	char T_E = '┤';
	char T_N = '┬';
	char T_S = '┴';
	char CROSS = '┼';
	*/

#pragma endregion

int main() {

#pragma region Variables
	//Used Malloc to allocate GameBoard with value type char to a char pointer
	int display[3][3] = {1,2,3,4,5,6,7,8,9};						//Display array for the player imput
	char *gameBoard;												//game board, stored as an char line
	gameBoard = (char*) malloc(sizeof(char)*9);						//allocates 9 blocks of memory for the 9 characters on the board.

	//cout << gameBoard;												//outputs the allocated memory

	int i=0;														//Loop variable
	int p=0;														//player variable
	int userInput;													//player imput
	int boxes=0;													//how many boxes used
	bool running = true;											//game loop boolean
	
#pragma endregion

#pragma region Game Loop
	
	while(running)//outside game loop, checks if the running boolean is true
	{
		//INPUT
		if(p==0)//o's turn
		{
			cout << "O's turn, where do you want to place your o?" << endl;				//Tells the player turn
			print2(display,3);															//Displays the input board
			cout << "Type in the number of the space you would like to go to" << endl;	//Tells the player how to imput
			cin >> userInput;															//user input
			--userInput;
			//processes input
					
			*(gameBoard + (sizeof(char) * userInput)) = 'o';
			cout << *gameBoard;
			

		}

		else//x's turn
		{
			cout << "X's turn, where do you want to place your X?" << endl;				//Tells the player turn
			print2(display,3);															//Displays the input board
			cout << "Type in the number of the space you would like to go to" << endl;	//Tells the player how to imput
			cin >> userInput;															//user input
			--userInput;
			//processes input		
			
			*(gameBoard + (sizeof(char) * userInput)) = 'x';

			/*
			if(userInput < 3)					//if user's input on first row
				//if(board[0][userInput] == '-')
					gameBoard[0][userInput] = 'x';
			else if(userInput > 6)				//if user's input is on third row
				//if(board[2][userInput-6] == '-')
					gameBoard[2][userInput-6] = 'x';
			else								//if user's input is on the second row
				//if(board[1][userInput-3] == '-')
					gameBoard[1][userInput-3] = 'x';	
				*/
		}

		boxes ++;				//increments boxes
		print(gameBoard,3);			//displays the current board

		
		//end condition
		
		if (gameWon(gameBoard))
		{
			if (p == 0)
			{ cout << "Congratulations Player 1, you have won!"; }

			else
			{ cout << "Congratulations Player 2, you have won!"; }

			running = false;
		}

		//Tie game
		 if(boxes == 9)
		{
			running = false;
			cout << "Tie Game!" ;
		}
		
		//Swaps the player counter
		if(p != 0)
			p = 0;
		else
			p = 1;
	}

#pragma endregion

#pragma region Finishing

print(gameBoard,3);				// calls the print method
free( gameBoard);					//deletes the board
gameBoard = 0;
cout << "Board Deleted";		//tells us the board got deleted
system("pause");				// because my Visual Studio is evil

#pragma endregion
}

#pragma region General Functions

#pragma region Game Won

bool gameWon(char* a)
{
	//wins for x
	//horizontal wins
	if (*a == 'x' && *(a+(sizeof(char))) == 'x' && *(a +(sizeof(char)) * 2) == 'x')
		return true;
			// + (sizeof(char) * userInput))

	else if (*(a+ (sizeof(char) * 3)) == 'x' && *(a+ (sizeof(char) * 4)) == 'x' && *(a+ (sizeof(char) * 5)) == 'x')
		return true;

	else if (*(a+ (sizeof(char) * 6)) == 'x' && *(a+ (sizeof(char) * 7)) == 'x' && *(a+ (sizeof(char) * 8)) == 'x')
		return true;

	//vertical wins
	else if (*a == 'x' && *(a+ (sizeof(char) * 3)) == 'x' && *(a+ (sizeof(char) * 6)) == 'x')
		return true;

	else if (*(a + (sizeof(char))) == 'x' && *(a+ (sizeof(char) * 4)) == 'x' && *(a+ (sizeof(char) * 7)) == 'x')
		return true;

	else if (*(a+ (sizeof(char) * 2)) == 'x' && *(a + (sizeof(char) * 5)) == 'x' && *(a+ (sizeof(char) * 8)) == 'x')
		return true;

	//diagonal wins
	else if (*a == 'x' && *(a+ (sizeof(char) * 4)) == 'x' && *(a+ (sizeof(char) * 8)) == 'x')
		return true;

	else if (*(a + (sizeof(char) * 2)) == 'x' && *(a+ (sizeof(char) * 4)) == 'x' && *(a+ (sizeof(char) * 6)) == 'x')
		return true;

	//wins for o
	//horizontal wins
	else if (*a == 'o' && *(a+(sizeof(char))) == 'o' && *(a + (sizeof(char) * 2)) == 'o')
		return true;
			// + (sizeof(char) * userInput))

	else if (*(a+ (sizeof(char) * 3)) == 'o' && *(a+ (sizeof(char) * 4)) == 'o' && *(a+ (sizeof(char) * 5)) == 'o')
		return true;

	else if (*(a+ (sizeof(char) * 6)) == 'o' && *(a+ (sizeof(char) * 7)) == 'o' && *(a+ (sizeof(char) * 8)) == 'o')
		return true;

	//vertical wins
	else if (*a == 'o' && *(a+ (sizeof(char) * 3)) == 'o' && *(a+ (sizeof(char) * 6)) == 'o')
		return true;

	else if (*(a + (sizeof(char))) == 'o' && *(a+ (sizeof(char) * 4)) == 'o' && *(a+ (sizeof(char) * 7)) == 'o')
		return true;

	else if (*(a+ (sizeof(char) * 2)) == 'o' && *(a + (sizeof(char) * 5)) == 'o' && *(a+ (sizeof(char) * 8)) == 'o')
		return true;

	//diagonal wins
	else if (*a == 'o' && *(a+ (sizeof(char) * 4)) == 'o' && *(a+ (sizeof(char) * 8)) == 'o')
		return true;

	else if (*(a+ (sizeof(char) * 2)) == 'o' && *(a+ (sizeof(char) * 4)) == 'o' && *(a+ (sizeof(char) * 6)) == 'o')
		return true;
	else return false;
}

#pragma endregion

#pragma region print function
//canabalized from E3, just changed to char from int.

void print(char* a, int ROWS) {
	cout << endl;
	int temp = 0;
	for (int row=0 ; row < ROWS ; row++) {
		for (int col=0 ; col < 3 ; col++)
		{
			cout << *(a + (sizeof(char) * (temp)));
			temp++;
		}
		cout << endl;
	}
}
//straight up canabalized from E3
void print2(int a[][3], int ROWS) {
	cout << endl;
	for (int row=0 ; row < ROWS ; row++) {
		for (int col=0 ; col < 3 ; col++)
			cout << a[row][col];
		cout << endl;
	}
}
/*
void print() {
	cout << 

}*/
#pragma endregion

#pragma endregion


