#include "Quaternion.h"
#include <iostream>

using namespace std;

Quaternion::Quaternion()
{
	a = 0.0;
	b = 0.0;
	c = 0.0;
	d = 0.0;
}


Quaternion::Quaternion(double i, double j, double k, double dVal):a(i),b(j),c(k),d(dVal)
{
}

//Conversion constructor
Quaternion::Quaternion(int i, int j, int k, int dVal)
{
	a = static_cast<double>(i);
	b = static_cast<double>(j);
	c = static_cast<double>(k);
	d = static_cast<double>(dVal);
}

//Copy constructor
Quaternion::Quaternion(Quaternion const& q)
{
	a = q.getA();
	b = q.getB();
	c = q.getC();
	d = q.getD();
}

//Conversion constructor
Quaternion::Quaternion(double dVal):d(dVal)
{
	a = 1.0;
	b = 1.0;
	c = 1.0;
}

//Conversion constructor
Quaternion::Quaternion(int dVal)
{
	a = 1.0;
	b = 1.0;
	c = 1.0;
	d = static_cast<double>(dVal);
}


Quaternion::~Quaternion(void)
{
}


//Operator overloads:

Quaternion& Quaternion::operator=(Quaternion const& q)
{
	if(this != &q)
	{
		a = q.getA();
		b = q.getB();
		c = q.getC();
		d = q.getD();
	}
	return *this;
}


//print
ostream& operator<<(ostream& out, Quaternion & q)
{
	q.print(out);
	return out;

}

void Quaternion::print(ostream& out)
{
	if(a != 0)
	{
		if(a != 1)
			out << "(" << a << "i)";
		else
			out << "(i)";
	}

	if(b != 0)
	{
		if(b != 1)
			out << "(" << b << "j)";
		else
			out << "(j)";
	}

	if(c != 0)
	{
		if(c != 1)
			out << "(" << c << "k)";
		else
			out << "(k)";
	}

	out << "(" << d << ")" << endl;

}

//Multiplication
Quaternion& Quaternion::operator*(Quaternion const& q)
{

	double newA = (a*q.getD()) + (d*q.getA()) + (b*q.getC()) - (c*q.getB());
	double newB = (b*q.getD()) + (d*q.getB()) + (c*q.getA()) - (a*q.getC());
	double newC = (c*q.getD()) + (c*q.getB()) + (b*q.getA()) - (a*q.getC());
	double newD = (d*q.getD()) - (a*q.getA()) - (b*q.getB()) - (c*q.getC());

	Quaternion * n = new Quaternion(newA,newB,newC,newD);

	return *n;
}

//addition
Quaternion& Quaternion::operator+(Quaternion const& q)
{
	Quaternion * n = new Quaternion();
	n->a = a + q.getA();
	n->b = b + q.getB();
	n->c = c + q.getC();
	n->d = d + q.getD();

	return *n;
}

//subtraction
Quaternion& Quaternion::operator-(Quaternion const& q)
{
	Quaternion * n = new Quaternion();
	n->a = a - q.getA();
	n->b = b - q.getB();
	n->c = c - q.getC();
	n->d = d - q.getD();

	return *n;
}


//dot product
double Quaternion::operator^(Quaternion const& q)
{
	return (a*q.getA() + b*q.getB() + c*q.getC());
}



//Conjugate
Quaternion& Quaternion::operator++()
{
	a *= -1;
	b *= -1;
	c *= -1;
	return *this;
}

//Negation
Quaternion& Quaternion::operator--()
{
	a *= -1;
	b *= -1;
	c *= -1;
	d *= -1;
	return *this;
}


Quaternion::operator double()
{
	return d;
}
/*
Quaternion::operator string()
{
	//ostream * out = new ostream();
	cout << this;
}*/


Quaternion* Quaternion::rotate(double x, double y, double angle, Quaternion& q)
{
	Quaternion * n = new Quaternion();
	n->a = x;
	n ->b = y;
	n ->c = 0;
	n ->d = 1;

	Quaternion * returnq = new Quaternion();
	*returnq = (q * (*n) * q++);
	return returnq;
}


//Getters:

double Quaternion::getA() const
{
	return a;
}

double Quaternion::getB() const
{
	return b;
}

double Quaternion::getC() const
{
	return c;
}

double Quaternion::getD() const
{
	return d;
}

void main()
{
	//Constructor Testing
	Quaternion q1(1.0);
	Quaternion q2(1,2,1,2);
	Quaternion q3(1,2,3,4);
	Quaternion q4(2.0,3.0,4.0,5.0);
	Quaternion q5(q4);
	Quaternion q6 = q1;

	//Fucnction Testing
	q5++;
	q6--;
	Quaternion q7 = q1+q3;
	Quaternion q8 = q1-q3;
	Quaternion q9 = q1*q3;
	Quaternion q10 = q1^q3;

	//input values
	double x, y, angle;

	//Output Statements
	cout << q1 << endl;
	//cout << q2 << endl;
	cout << q3<< endl;
	cout << q4 << endl;
	cout << q5 << endl;
	cout << q6 << endl;
	cout << q7 << endl;
	cout << q8 << endl;
	cout << q9 << endl;
	cout << q10 << endl;

	//rotate testing

	cout << "Input x" << endl;
	cin >> x;
	cout << endl << "Input y" << endl;
	cin >> y;
	cout << endl << "Input angle" << endl;
	cin >> angle;
	Quaternion * q11 = q2.rotate(x,y,angle,q1);
	cout << *q11 << endl;

	system("pause");
}