#pragma once
#include <iostream>

using namespace std;

class Quaternion
{
public:
	//Constructors
	Quaternion();
	Quaternion(double i, double j, double k, double dVal);
	Quaternion(int i, int j, int k, int dVal);
	Quaternion(Quaternion const& q);
	Quaternion(double dVal);
	Quaternion(int dVal);
	~Quaternion(void);

	//Operator overloads
	//copy assignment
	Quaternion& operator=(Quaternion const& q);
	//print
	friend ostream& operator<<(ostream& out,Quaternion const& q);
	//multiplication
	Quaternion& operator*(Quaternion const& q);
	//addition
	Quaternion& operator+(Quaternion const& q);
	//subtraction
	Quaternion& operator-(Quaternion const& q);
	//dot product
	double operator^(Quaternion const& q);
	//conjugate
	Quaternion& operator++();
	//negate
	Quaternion& operator--();

	void print(ostream&);

	//conversion functions
	operator double();
	operator string();

	//rotate function
	Quaternion* rotate(double x, double y, double angle, Quaternion& q);


	//getters
	double getA() const;
	double getB() const;
	double getC() const;
	double getD() const;

private:
	double a;
	double b;
	double c;
	double d;

};

