#include "Node.h"
#include <iostream>;
#include <string>;
using namespace std;

Node::Node(void)
{
	data = 0;
	left = NULL;
	right = NULL;
}

Node::Node(int d) : data(d)
{
	data = d;
	left = NULL;
	right = NULL;
}

Node::~Node(void)
{
	left = NULL;
	right = NULL;
	delete right;
	delete left;
}


int Node::getData()
{
	return data;
}

Node* Node::getLeft()
{
	return left;
}

Node* Node::getRight()
{
	return right;
}

void Node::setLeft(Node* l)
{
	left = l;
}

void Node::setRight(Node* r)
{
	right = r;
}

