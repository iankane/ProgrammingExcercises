#include <iostream>;
#include <string>;
#include "Node.h";

using namespace std;

class Tree
{
public:
	Tree(void);
	Tree(int rootData);
	Tree(Tree const& t);
	//Should these arguments be pointer to Trees??
	Tree(Tree const& t1, Tree const& t2);

	~Tree(void);

	Tree& operator=(Tree const& t);

	//creates a tree using a tree
	void copyTree(Tree t, Node root);

	void freeNode(Node *n);

	//Traversal stuff:
	void printPreOrder(Node* n);
	void printPostOrder(Node* n);
	void printInOrder(Node* n);

	void preOrder();
	void postOrder();
	void inOrder();
	//


	void Add(int d);
	bool deleteNode(int d);
	bool search(int d)const;

	Node* findMin()const;
	Node* findMax()const;



private:
	Node* root;
};

