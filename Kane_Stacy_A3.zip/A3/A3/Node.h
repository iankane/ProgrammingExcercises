#include <iostream>;
#include <string>;

using namespace std;

class Node
{
public:

	Node(void);
	
	Node(int d);
	
	~Node(void);
	
	int getData();
	Node* getLeft();
	Node* getRight();

	void setLeft(Node* l);
	void setRight(Node* r);

private:
	int data;
	Node* left;
	Node* right;
};

