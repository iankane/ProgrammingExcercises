#include "Tree.h"
#include <iostream>;
#include <string>;

using namespace std;

Tree::Tree(void)
{
	root = NULL;
}

Tree::Tree(int r)
{
	root = new Node(r);
}

Tree::Tree(Tree const& t)
{
	//Add(t.root->getData());
	root = t.root;
	int maxVal = 0;
	int minVal = 0;
	t.findMax();
	maxVal = t.findMax()->getData();

	minVal = t.findMin()->getData();


	for(int i = minVal; i < maxVal; i++)
	{
		if(t.search(i))
		{
			Add(i);
		}
	}
}


Tree::Tree(Tree const& t1, Tree const& t2)
{
	root = new Node(t1.root->getData());

	int maxVal = 0;
	int minVal = 0;

	maxVal = t1.findMax()->getData();

	if(t2.findMax()->getData() > maxVal)
		maxVal = t2.findMax()->getData();

	minVal = t1.findMin()->getData();

	if(t2.findMin()->getData() < minVal)
		minVal = t2.findMin()->getData();

	for(int i = minVal; i <= maxVal; i++)
	{
		if(t1.search(i))
		{
			Add(i);
		}
		else if(t2.search(i))
		{
			Add(i);
		}
	}
}

Tree::~Tree(void)
{
	root = NULL;
	delete root;
}

Tree& Tree::operator=(Tree const& t)
{
	Tree n;
	n.Add(t.root->getData());
	
	int maxVal = 0;
	int minVal = 0;

	maxVal = t.findMax()->getData();

	minVal = t.findMin()->getData();


	for(int i = minVal; i < maxVal; i++)
	{
		if(t.search(i))
		{
			n.Add(i);
		}
	}
	return n;
}
/*
void Tree::freeNode(Node *n)
{
	if(n != NULL || n->getLeft() != NULL || n->getRight() != NULL)
	{
		freeNode(n->getLeft());
		freeNode(n->getRight());
		delete n;
	}
}*/

//Traversals:

void Tree::preOrder()
{
	return printPreOrder(root);
}
void Tree::postOrder()
{
	return printPostOrder(root);
}
void Tree::inOrder()
{
	return printInOrder(root);
}

void Tree::printPreOrder(Node* n)
{
	if(n != NULL)
	{
		cout << n->getData() << endl;
		printPreOrder(n->getLeft());
		printPreOrder(n->getRight());
	}		
}
void Tree::printPostOrder(Node* n)
{
	if(n != NULL)
	{
		printPostOrder(n->getLeft());
		printPostOrder(n->getRight());
		cout << n->getData() << endl;
	}		
}
void Tree::printInOrder(Node* n)
{
	if(n != NULL)
	{
		printInOrder(n->getLeft());
		cout << n->getData() << endl;
		printInOrder(n->getRight());
	}		
}


//


void Tree::Add(int d)
{
	Node * n = new Node(d);
	int result;

	Node* current = root ;
	Node* parent = current;

	while(current != NULL)
	{
		if(d == current -> getData())
		{
			return;
		}
		else if(d < current -> getData())
		{
			parent = current;
			current = current ->getLeft();
		}
		else if(d > current ->getData())
		{
			parent = current;
			current = current ->getRight();
		}

	}

	if(parent == NULL)
	{
		root = n;
	}
	else
	{
		if(d < parent->getData())
		{
			parent ->setLeft(n);
		}
		if(d > parent->getData())
		{
			parent ->setRight(n);
		}
	}
}


bool Tree::deleteNode(int d)
{
	if(root== NULL)
	{
		return false;
	}

	Node* current = root;
	Node* parent = NULL;
	//FIX THIS
	while(d != current ->getData() )
	{
		if(d < current ->getData())
		{
			parent = current;
			current = current ->getLeft();
		}
		else if(d > current ->getData())
		{
			parent = current;
			current = current ->getRight();
		}
		if(current == NULL)
		{
			return false;
		}
	}

	//CASE 1
	if(current ->getRight() == NULL)
	{
		if(parent == NULL)
		{
			root = current->getLeft();
		}
		else
		{
			if(parent->getData() > current ->getData())
			{
				parent->setLeft(current ->getLeft());
			}
			else if(parent->getData() < current ->getData())
			{
				parent->setRight(current ->getRight());
			}
		}
	}

	//CASE 2
	else if(current ->getRight() ->getLeft() == NULL)
	{
		current ->getRight() ->setLeft(current ->getLeft());

		if(parent == NULL)
		{
			root = current ->getRight();
		}
		else
		{
			if(parent->getData() > current ->getData())
			{
				parent->setLeft(current ->getRight());
			}
			else if(parent->getData() < current ->getData())
			{
				parent->setRight(current ->getRight());
			}
		}
	}

	//CASE 3
	else
	{
		Node* leftMost = current->getRight() ->getLeft();
		Node* leftMostParent = current->getRight();
		bool looping = true;
		if(leftMost->getLeft() == NULL)
		{
			while(looping)
			{
				if(leftMost ->getLeft()->getData() != 0)
				{
					leftMostParent = leftMost;
					leftMost = leftMost ->getLeft();
				}
				else
				{
					looping = false;
				}
			}
		}

		leftMostParent ->setLeft(leftMost ->getRight());

		leftMost ->setLeft(current ->getLeft());
		leftMost ->setRight(current ->getRight());

		if(parent == NULL)
		{
			root = leftMost;
		}
		else
		{
			if(parent ->getData() > current ->getData())
			{
				parent ->setLeft(leftMost);
			}
			else if(parent ->getData() < current ->getData())
			{
				parent ->setRight(leftMost);
			}
		}

	}

	
	//delete(current);
	current = NULL;
	return true;
}


bool Tree::search(int d)const
{
	Node* current = root;

	//loop and check values
	while(current != NULL && current->getData() != d)
	{
		//didn't find it
		if(current == NULL)
		{
			return false;
		}
		//is the data less?
		else if(current->getData() > d)
		{
			current = current->getLeft();
		}
		//greater?
		else if (current->getData() < d)
		{
			current = current->getRight();
		}
	}
	if(current != NULL)
	{
		return true;
	}
	return false;
}


Node* Tree::findMax()const
{
	Node* greatest = root;

	while(greatest->getRight() != NULL)
	{
		greatest = greatest->getRight();
	}
	return greatest;
}

Node* Tree::findMin()const
{
	Node* min = root;

	while(min->getLeft() != NULL)
	{
		min = min->getLeft();
	}
	return min;
}

void main()
{
	//first tree
	Tree t(9);
	t.Add(8);
	t.Add(7);
	t.Add(10);
	t.Add(5);
	t.Add(3);
	t.Add(12);
	//second tree
	Tree t1(10);
	t1.Add(15);
	t1.Add(2);
	t1.Add(20);
	t1.Add(5);
	t1.Add(3);
	t1.Add(13);
	//deletes
	//not in the tree
	t.deleteNode(1);
	t.deleteNode(30);
	//left
	t1.deleteNode(3);
	//right
	t.deleteNode(10);
	//combine trees
	Tree t2(t,t1);

	//copy constructor
	Tree t3(t1);
	//assignment constructor
	Tree t4 = t;

	cout << "Tree 1" << endl;
	cout << "Post Order" << endl;
	t.postOrder();
	cout << "Pre Order" << endl;
	t.preOrder();
	cout << "In Order" << endl;
	t.inOrder();

	cout << "Tree 2" << endl;
	cout << "Post Order" << endl;
	t1.postOrder();
	cout << "Pre Order" << endl;
	t1.preOrder();
	cout << "In Order" << endl;
	t1.inOrder();

	cout << "Combo Tree" << endl;
	cout << "Post Order" << endl;
	t2.postOrder();
	cout << "Pre Order" << endl;
	t2.preOrder();
	cout << "In Order" << endl;
	t2.inOrder();
	

	cout << "copy constructor Tree" << endl;
	cout << "Post Order" << endl;
	t3.postOrder();
	cout << "Pre Order" << endl;
	t3.preOrder();
	cout << "In Order" << endl;
	t3.inOrder();

	cout << "Assignment opperator Tree" << endl;
	cout << "Post Order" << endl;
	t4.postOrder();
	cout << "Pre Order" << endl;
	t4.preOrder();
	cout << "In Order" << endl;
	t4.inOrder();

	system("pause");
}