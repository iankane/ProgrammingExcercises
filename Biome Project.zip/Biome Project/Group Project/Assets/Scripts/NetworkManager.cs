using UnityEngine;
using System.Collections;

public class NetworkManager : MonoBehaviour {

    //network info
    private string connectionIP = "127.0.0.1";
    private int connectionPort = 25005;

    //player info
    private string playerName = "Player Name";
    public string PlayerName
    {
        get { return playerName; }
        set { playerName = value; }
    }
    private GameObject ss;
    private GameObject playerLabel;
    private string[] playerNameList;

    //connect window setup
    private Rect connectWindowRect;
    private int connectWindowWidth = 320;
    private int connectWindowHeight = 150;
    private int buttonHeight = 45;
    private int leftIndent;
    private int topIndent;
    private string titleMessage = "Connection Setup";

    //
    private bool iWantToBeClient = false;

    //----------------end variables -----------------

    void Start()
    {
        playerName = PlayerPrefs.GetString("playerName");
        if (playerName == "" || playerName == null)
        {
            playerName = "Player" + Random.Range(0, 1000);
        }
        ss = GameObject.Find("SpawnManagerGO");
        DontDestroyOnLoad(transform.gameObject);
    }


    void startServer()
    {
        Network.InitializeServer(32, connectionPort, Network.HavePublicAddress());
        Debug.Log("Started the server, I hope!");
    }

    //----------- handle incoming messages FROM THE SERVER ------------

    //-----these messages are sent to the server

    //we are informed that we were successful in initializing the server
    void OnServerInitialized()
    {
        Debug.Log("server is initialized and ready to receive!!!!");
        Application.LoadLevel((Application.loadedLevel + 1));
        //GameObject.Find("NetworkManagerGO").GetComponent<NetworkIDList>() . sendData();
        //ss.GetComponent<SpawnScript>().spawnPlayer();
    }

    // we are informed that a player has just connected to us (the server)
    void OnPlayerConnected(NetworkPlayer player)
    {
        Debug.Log("Player " + player.guid + " connected from " + player.ipAddress + ":" + player.port);
    }

    ///-----these messages are sent to the CLIENT

    void OnConnectedToServer()
    {
        Debug.Log("I'm a client, connected to server");
        Application.LoadLevel((Application.loadedLevel + 1));
        
        //GameObject.Find("NetworkManagerGO").GetComponent<NetworkIDList>() . sendData();
        //ss.GetComponent<SpawnScript>().spawnPlayer();
    }

    //called on both client AND server
    void OnDisconnectedFromServer(NetworkDisconnection info)
    {
        //reload the application so we can start over
        Application.LoadLevel(Application.loadedLevel-1);
    }


    //some player has disconnected. 
    //We'd better clean up their stuff
    void OnPlayerDisconnected(NetworkPlayer player)
    {
        Debug.Log("Clean up after player " + player);
        Network.RemoveRPCs(player);
        Network.DestroyPlayerObjects(player);
    }
    //----------- end incoming messages from SERVER ------------



    void ConnectWindow(int windowID)
    {
        //Leave a gap after the header.
        GUILayout.Space(15);

        if (GUILayout.Button("Start Server", GUILayout.Height(buttonHeight)))
        {
            startServer();
        }

        GUILayout.Space(5);
        if (GUILayout.Button("Join the Game", GUILayout.Height(buttonHeight)))
        {
            Debug.Log("I wanna join as client");
            iWantToBeClient = true;
        }
    }

    void ClientLoginWindow(int windowID)
    {
        if (iWantToBeClient == true)
        {
            Debug.Log("drawing login window");
            //Entry text field for player name
            GUILayout.Label("Enter your player name:");
            playerName = GUILayout.TextField(playerName, 25);

            GUILayout.Space(5);
            //The player enters IP
            GUILayout.Label("Enter Server IP:");
            connectionIP = GUILayout.TextField(connectionIP);

            GUILayout.Space(5);

            //... and the port #
            GUILayout.Label("Enter Server Port:");
            connectionPort = int.Parse(GUILayout.TextField(connectionPort.ToString()));

            GUILayout.Space(20);

            if (GUILayout.Button("Login!", GUILayout.Height(25)))
            {
                if (playerName == "")
                {
                    playerName = "DefaultPlayer";
                }
                if (playerName != "")
                {
                    //Do the connection
                    Network.Connect(connectionIP, connectionPort);

                    //Store the player name locally
                    PlayerPrefs.SetString("playerName", playerName);
                }
            }

            GUILayout.Space(5);

            if (GUILayout.Button("Go Back", GUILayout.Height(25)))
            {
                iWantToBeClient = false;
            }

        }

    }

    void OnGUI()
    {
        if (Network.peerType == NetworkPeerType.Disconnected && !iWantToBeClient)
        {
            //set up first connection window in center of screen 	
            leftIndent = Screen.width / 2 - connectWindowWidth / 2;
            topIndent = Screen.height / 3 - connectWindowHeight / 2;
            connectWindowRect = new Rect(leftIndent, topIndent, connectWindowWidth,
                    connectWindowHeight);
            //create the window
            connectWindowRect = GUILayout.Window(0, connectWindowRect, ConnectWindow, titleMessage);
        }

        //If I wanna be client, show login dialog
        if (Network.peerType == NetworkPeerType.Disconnected && iWantToBeClient)
        {
            leftIndent = Screen.width / 2 - connectWindowWidth / 2;
            topIndent = Screen.height / 3 - connectWindowHeight / 2;
            connectWindowRect = new Rect(leftIndent, topIndent, connectWindowWidth,
                    connectWindowHeight);
            //create the window
            connectWindowRect = GUILayout.Window(1, connectWindowRect, ClientLoginWindow, "Login");
        }
    }
}
