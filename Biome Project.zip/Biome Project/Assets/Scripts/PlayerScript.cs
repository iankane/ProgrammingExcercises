using UnityEngine;
using System.Collections;

public class PlayerScript : MonoBehaviour {

    private string playerName;
    private Material playerMaterial;

    // Use this for initialization
    void Awake()
    {
        UpdateNameLocally();
        //updateColorLocally();
    }

    void UpdateNameLocally()
    {
        if (networkView.isMine)
        {
            playerName = PlayerPrefs.GetString("playerName");
            //chatManager needs the player name
            //GameObject.Find("GameManagerGO").GetComponent<ChatManager>().playerName = playerName;


            //IDList gets the player name
            GameObject go = GameObject.Find("NetworkManagerGO");
            go.GetComponent<IDList>().MyOwnName = playerName;
            //sets the Need to Set Name to true
            go.GetComponent<IDList>().NeedToSetName = true;


            //updates the name everywhere
            networkView.RPC("UpdateMyNameEverywhere", RPCMode.AllBuffered, playerName);
            networkView.RPC("UpdateMyColorEverywhere", RPCMode.AllBuffered, go.GetComponent<IDList>().myOwnColor);
        }
    }

    void updateColorLocally()
    {
        GameObject go = GameObject.Find("NetworkManagerGO");
        Debug.Log("Material: " + go.GetComponent<IDList>().materials[go.GetComponent<IDList>().myOwnColor] + " : Color ID: " + go.GetComponent<IDList>().myOwnColor);
        networkView.RPC("UpdateMyColorEverywhere", RPCMode.AllBuffered, go.GetComponent<IDList>().myOwnColor);
    }


    [RPC]
    void UpdateMyNameEverywhere(string playerName)
    {
        gameObject.name = playerName;
        //gameObject.GetComponent<PlayerLabel>().PlayerName = playerName;
    }

    [RPC]
    void UpdateMyColorEverywhere(int myColor)
    {
        GameObject go = GameObject.Find("NetworkManagerGO");
        GameObject.Find(gameObject.name + "/Body").renderer.material = go.GetComponent<IDList>().materials[go.GetComponent<IDList>().myOwnColor];
    }

    // Update is called once per frame
    void Update()
    {

    }

}
