using UnityEngine;
using System.Collections;
/// <summary>
/// Network load level.
/// Based on javascript code provided by Unity3D
/// http://docs.unity3d.com/Documentation/Components/net-NetworkLevelLoad.html 
/// 
/// Below is a simple example of a way to load a level in a multiplayer game. 
/// It makes sure no network messages are being processed while the level is being loaded. 
/// It also makes sure no messages are sent, until everything is ready. 
/// Lastly, when the level is loaded it sends a message to all scripts so that 
/// they know the level is loaded and can react to that. 
/// 
/// The SetLevelPrefix function helps with keeping unwanted networks updates out of a new loaded level. 
/// Unwanted updates might be updates from the previous level for example. 
/// The example also uses groups to separate game data and level load communication into groups. 
/// Group 0 is used for game data traffic and group 1 for level loading. 
/// Group 0 is blocked while the level is being loaded but group 1 kept open, 
/// it could also ferry chat communication so that can stay open during level loading.
/// </summary>
[RequireComponent(typeof(NetworkView))]
public class NetworkLoadLevel : MonoBehaviour
{
    // Keep track of the last level prefix (increment each time a new level loads)
    private int lastLevelPrefix = 0;
    private int lastAllowedLevelPrefix = 1;
    private int lobbyLevel = 0;
    private NetworkManager nm;


    void Awake()
    {
        // Network level loading is done in a seperate channel.

        networkView.group = 1;
        nm = GameObject.Find("NetworkManagerGO").GetComponent<NetworkManager>();
    }


    void Update()
    {
        if (Network.isServer && Network.peerType != NetworkPeerType.Disconnected)
        {
            // bools for being ready to load a level
            bool goGame = nm.CurrentMenuState == NetworkManager.MenuState.lobby && nm.ReadyForGame;
            bool goLobby = nm.CurrentMenuState == NetworkManager.MenuState.ingame && nm.IWantToReturnToLobby;

            if (goGame || goLobby)
            {
                Debug.Log("getting ready to load level on server");
                // Make sure no old RPC calls are buffered and then send load level command
                Network.RemoveRPCsInGroup(0);
                Network.RemoveRPCsInGroup(1);
                // Load level with incremented level prefix (for view IDs)
                // NOTE: The RPCMode.AllBuffered sends the request to all clients, including the client sending the
                //       request.  Also, the Buffered command tells the game server to hold onto the RPC command and also
                //       send it to any new clients that connect.  This is important for level loading or player instantiation 
                //       so we make sure all objects are correctly created on all clients, but would not be used for example 
                //       to indicate a death as the new client would never have seen the player in the first place and 
                //       therefore doesn't need to see the death.

                // HOWEVER, you may not want a newly arrived client to automatically connect to the game level, in which
                //		case you may not want to buffer this RPC. You would need to write more logic to keep everyone in sync

                if (goGame)
                {
                    networkView.RPC("LoadLevel", RPCMode.AllBuffered, "GameScene", lastLevelPrefix + 1);
                    nm.IWantToReturnToLobby = false;
                    nm.ReadyForGame = false;

                }
                else
                {
                    networkView.RPC("LoadLevel", RPCMode.AllBuffered, "Lobby", lobbyLevel);
                    nm.IWantToReturnToLobby = false;
                    nm.ReadyForGame = false;
                }
            }

        }

    }


    [RPC]
    IEnumerator LoadLevel(string level, int levelPrefix)
    {
        Debug.Log("RPC called to load level " + level + " with prefix " + levelPrefix);

        if (level == "Lobby") nm.CurrentMenuState = NetworkManager.MenuState.lobby;
        if (level == "GameScene") nm.CurrentMenuState = NetworkManager.MenuState.ingame;


        lastLevelPrefix = levelPrefix;
        // There is no reason to send any more data over the network on the default channel,
        // because we are about to load the level, because all those objects will get deleted anyway
        Network.SetSendingEnabled(0, false);
        // We need to stop receiving because first the level must be loaded.
        // Once the level is loaded, RPC's and other state update attached to objects in the level are allowed to fire
        Network.isMessageQueueRunning = false;

        // All network views loaded from a level will get a prefix into their NetworkViewID.
        // This will prevent old updates from clients leaking into a newly created scene.
        Network.SetLevelPrefix(levelPrefix);
        Application.LoadLevel(level);
        yield return 0; //new WaitForSeconds (1);
        yield return 0; //new WaitForSeconds (1);

        // Allow receiving data again
        Network.isMessageQueueRunning = true;
        // Now the level has been loaded and we can start sending out data
        Network.SetSendingEnabled(0, true);


        // Once the level is loaded we then need to instantiate our local player. -- if it's the game level

        if (nm.CurrentMenuState == NetworkManager.MenuState.ingame)
        {
           // SpawnScript ss = GameObject.Find("SpawnManagerGO").GetComponent<SpawnScript>();
           // ss.SpawnPlayer();
        }
    }






    void OnDisconnectedFromServer()
    {
        // If we lose the connection to the server then return to the Master Game Server Lobby
        nm.CurrentMenuState = NetworkManager.MenuState.lobby;
        nm.IWantToReturnToLobby = false;
        nm.ReadyForGame = false;
        Application.LoadLevel("Lobby");
    }

}
