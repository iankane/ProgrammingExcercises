using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour
{
	[SerializeField]
	private int cameraBaseSpeed = 100;
	[SerializeField]
	private GameManager gm;
	
    // Use this for initialization
    void Start()
    {
        transform.position = new Vector3(gm.terrainWidth/2, 40, gm.terrainHeight/2);
    }

    // Update is called once per frame
    void Update()
    {
		if (Input.GetMouseButton(2))
        {
            transform.Rotate(Input.GetAxis("Mouse Y") * -1,0,0);
            float turnMuch = Input.GetAxis("Mouse X");
            transform.Rotate(0,turnMuch,0,Space.World);
        }
        else
        { 
			Vector3 temp = transform.position;
            Vector3 temp2 = transform.position;
            if (Input.GetKey(KeyCode.W))
            {

                temp = transform.forward;
                temp.y = 0;
                temp2 += temp * Time.deltaTime * cameraBaseSpeed;

                if (temp2.x > 0 && temp2.x < gm.terrainWidth && temp2.z > 0 && temp2.z < gm.terrainHeight)
                {
                    transform.position += temp * Time.deltaTime * cameraBaseSpeed;
                }
                
            }
            if (Input.GetKey(KeyCode.S))
            {


                temp = transform.forward;
                temp.y = 0;
                temp2 -= temp * Time.deltaTime * cameraBaseSpeed;

                if (temp2.x > 0 && temp2.x < gm.terrainWidth && temp2.z > 0 && temp2.z < gm.terrainHeight)
                {
                    transform.position -= temp * Time.deltaTime * cameraBaseSpeed;
                }


            }
            if (Input.GetKey(KeyCode.D))
            {

                temp2 += transform.right * Time.deltaTime * cameraBaseSpeed;

                if (temp2.x > 0 && temp2.x < gm.terrainWidth && temp2.z > 0 && temp2.z < gm.terrainHeight)
                {
                    transform.position += transform.right * Time.deltaTime * cameraBaseSpeed;
                }

            }
            if (Input.GetKey(KeyCode.A))
            {
                temp2 -= transform.right * Time.deltaTime * cameraBaseSpeed;

                if (temp2.x > 0 && temp2.x < gm.terrainWidth && temp2.z > 0 && temp2.z < gm.terrainHeight)
                {
                    transform.position -= transform.right * Time.deltaTime * cameraBaseSpeed;
                }
            }
            if (Input.GetKey(KeyCode.E))
            {
                temp = transform.position;
                if (temp.y < 150)
                {
                    temp.y += Time.deltaTime * 100;
                    transform.position = temp;
                }
            }
            if (Input.GetKey(KeyCode.C))
            {
                temp = transform.position;
				if(temp.y > 10)
				{
                	temp.y -= Time.deltaTime * 100;
                    transform.position = temp;
				}
			}
			
        }
    }
}