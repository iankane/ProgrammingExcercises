using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour {
	
	[SerializeField]
	private Terrain terrain;
	
	[SerializeField]
	private GameObject sheep;
	[SerializeField]
	private GameObject grass;
	[SerializeField]
	private GameObject wolf;
	
	[SerializeField]
	private GameObject[,] tiles;
	
	[SerializeField]
	private GameObject[,] UnitList;

    private IDList ids;

	public int terrainHeight;
	public int terrainWidth;
	
	public int alphaHeight;
	public int alphaWidth;
	
	int unitNumber = 0;
	
	public int squareSize = 5;

    public bool isTerrainNull()
    {
        return (terrain == null);
    }

	// Use this for initialization
	void Start () {
		terrainHeight = (int)terrain.terrainData.heightmapWidth;
		terrainWidth = (int)terrain.terrainData.heightmapHeight;
		alphaHeight = (int)terrain.terrainData.alphamapHeight;
		alphaWidth = (int)terrain.terrainData.alphamapWidth;
		Vector3 newPosition = new Vector3(0,-25,0);
		terrain.transform.position = newPosition;
		tiles = new GameObject[terrainHeight/5,terrainWidth/5];
		UnitList = new GameObject[terrainHeight/5, terrainWidth/5];

        ids = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();

		//terrHeights = new int[terrainHeight/5,terrainWidth/5];
		
		float[,] heights = terrain.terrainData.GetHeights(0,0,terrainWidth,terrainHeight);
				
		for(int i = 0; i < terrainWidth; i++)
		{
			for(int j = 0; j < terrainHeight; j++)
			{
				heights[i,j] = 0.5f;
				//terrHeights[i,j] = 0.5f;
			}
		}
		terrain.terrainData.SetHeights(0,0,heights);
		
	}
	
	void OnDestroy()
	{
		float[,] heights = terrain.terrainData.GetHeights(0,0,terrainWidth,terrainHeight);
		float[,,] map = terrain.terrainData.GetAlphamaps(0,0,terrainWidth-1, terrainHeight-1);
				
		for(int i = 0; i < terrainWidth; i++)
		{
			for(int j = 0; j < terrainHeight; j++)
			{
				heights[i,j] = 0f;
				if(i < terrainWidth-1 && j < terrainHeight -1)
				{
					map[i,j,0] = 1;
					map[i,j,1] = 0;
					map[i,j,2] = 0;
					map[i,j,3] = 0;
					map[i,j,4] = 0;
					
				}
			}
		}
		terrain.terrainData.SetHeights(0,0,heights);
		terrain.terrainData.SetAlphamaps(0,0,map);
	}
	
	// Update is called once per frame
	void Update () {
	}
	
	public void AddTerrain(Vector3 position, bool raise)
	{
		if(Network.peerType != NetworkPeerType.Disconnected)
		{
			if(Network.isServer)
			{
				ServerModifyTerrain(position, raise);
			}
			else
			{
				networkView.RPC("ServerModifyTerrain", RPCMode.Server, position, raise);
			}
		}
		else
		{
			ModifyTerrain(position, raise);
		}
	}
	
	
	public void AddTile(Vector3 position, int type, int owner)
	{
		if(Network.peerType != NetworkPeerType.Disconnected)
		{
			int x = (int)Mathf.Round(position.x/5);
			int y = (int)Mathf.Round(position.y);
			int z = (int)Mathf.Round(position.z/5);
			if(Network.isServer)
			{
				ServerSpawnTile(x,y,z,type, owner);
			}
			else
			{
				networkView.RPC("ServerSpawnTile", RPCMode.Server, x, y, z, type, owner);
			}
		}
		else
		{
			int x = (int)Mathf.Round(position.x/5);
			int y = (int)Mathf.Round(position.y);
			int z = (int)Mathf.Round(position.z/5);
			SpawnTile(x,y,z,type, owner);
		}
	}
	
	[RPC]
	public void ServerSpawnTile(int x, int y, int z, int type, int owner)
	{
		networkView.RPC("SpawnTile", RPCMode.AllBuffered, x, y, z, type, owner);
	}
	
    [RPC]
    public void SpawnTile(int x, int y, int z, int type, int owner)
    {
		//Debug.Log(y);
		if(x < tiles.GetLength(0) && x >= 0 && z < tiles.GetLength(1) && z >= 0)
		{
		
	        if (tiles[x, z] != null)
	        {
				if(!isAUnitThere(x,z))
				{
		            if(type == 0)
						return;
					switch(type)
					{
						case 1: 
							ids.MySheep++;
	                        ids.addSheep = true;
	                        GameObject newSheep = (GameObject)Instantiate(sheep, new Vector3(x*5, y, z*5), new Quaternion());
							newSheep.GetComponent<Sheep>().SetOwner(owner);
	                        newSheep.GetComponent<Sheep>().SetColor();
							newSheep.GetComponent<Sheep>().ListNumber = unitNumber;
							UnitList[x,z] = newSheep;
							unitNumber++;
				            break;
				        case 2: 
							ids.MyWolves++;
	                        ids.addWolves = true;
	                        GameObject newWolf = (GameObject)Instantiate(wolf, new Vector3(x*5, y, z*5), new Quaternion());
							newWolf.GetComponent<Wolf>().SetOwner(owner);
	                        newWolf.GetComponent<Wolf>().SetColor();
							newWolf.GetComponent<Wolf>().ListNumber = unitNumber;
							UnitList[x,z] = newWolf;
							unitNumber++;
				            break;
					}
				}
	        }
			else
			{
			    switch (type)
			    {
			        case 0: 
	                    Vector3 position = new Vector3(x*5,y,z*5);
						Vector3 tempCoord = (position - terrain.gameObject.transform.position);
			
			
						Vector3 coord;				
						coord.x = (tempCoord.x/terrain.terrainData.size.x);
						coord.y = (tempCoord.y/terrain.terrainData.size.y);
						coord.z = (tempCoord.z/terrain.terrainData.size.z);
				
						int posXInTerrain = (int) (coord.x * terrainWidth);
						int posZInTerrain = (int) (coord.z * terrainHeight);
						
						if(posXInTerrain+squareSize <= terrainWidth && posZInTerrain+squareSize <= terrainHeight)
						{
							ids.MyGrass++;
	                   		ids.addGrass = true;
							float[,] heights = terrain.terrainData.GetHeights(posXInTerrain,posZInTerrain,squareSize,squareSize);
							
							float areaHeight = (heights[0,0]*50)-25;
						
							GameObject tile = (GameObject)Instantiate(grass, new Vector3(x*5, areaHeight, z*5), new Quaternion());
							ModifyTexture(tile.transform.position,owner);
							tile.GetComponent<Grass>().SetOwner(owner);
		                    tile.GetComponent<Grass>().SetColor();
							tiles[x, z] = tile;
						}
			            break;
			    }
			}
		}
    }
	
	[RPC]
	public void ServerModifyTerrain(Vector3 position, bool raise)
	{
		//ModifyTerrain(position, raise);
		networkView.RPC("ModifyTerrain", RPCMode.AllBuffered, position, raise);
	}
	
	[RPC]
	public void ModifyTerrain(Vector3 position, bool raise)
	{
		Vector3 tempCoord = (position - terrain.gameObject.transform.position);
		
		
		Vector3 coord;
		float x = (int)Mathf.Round(tempCoord.x/5);
		float y = (int)Mathf.Round(tempCoord.y);
		float z = (int)Mathf.Round(tempCoord.z/5);
		
		x*=5;
		x-=2.5f;
		z*=5;
		z-=2.5f;
		
		//Debug.Log("{"+x+", "+y+", "+z+"}");
			
		coord.x = (x/terrain.terrainData.size.x);
		coord.y = (y/terrain.terrainData.size.y);
		coord.z = (z/terrain.terrainData.size.z);

		int posXInTerrain = (int) (coord.x*terrainWidth );
		int posZInTerrain = (int) (coord.z*terrainHeight );
				
		float[,] heights = terrain.terrainData.GetHeights(posXInTerrain,posZInTerrain,squareSize,squareSize);
				
		float areaHeight;
		areaHeight = (raise) ? (heights[2,2] + .01f) : (heights[2,2] - .01f);
				
		for(int i = 0; i < squareSize; i++)
		{
			for(int j = 0; j < squareSize; j++)
			{
				heights[i,j] = areaHeight;
			}
		}
		if(GetGrass((int)Mathf.Round(position.x/5),(int)Mathf.Round(position.z/5)) != null)
		{
			GameObject grass = GetGrass((int)Mathf.Round(position.x/5),(int)Mathf.Round(position.z/5));
			Vector3 newPosition = grass.transform.position;
			newPosition.y = (areaHeight*50)-25;
			grass.transform.position = newPosition;
		}
		terrain.terrainData.SetHeights(posXInTerrain,posZInTerrain,heights);
		Debug.Log(areaHeight);
	}
		
	public void Proliferate(Vector3 _position, int owner)
	{
		Vector3 up = new Vector3(_position.x,_position.y,_position.z+5);
		Vector3 left = new Vector3(_position.x-5,_position.y,_position.z);
		Vector3 down = new Vector3(_position.x,_position.y,_position.z-5);
		Vector3 right = new Vector3(_position.x+5,_position.y,_position.z);
		
		AddTile(up,0, owner);
		AddTile(down, 0, owner);
		AddTile(left, 0, owner);
		AddTile(right,0, owner);
	}
	
	public GameObject GetGrass(int x, int z)
	{
		if(x > 0 && z > 0 && x < tiles.GetLength(0) && z < tiles.GetLength(1))
		{
			if(tiles[x,z] != null)
			{
				return tiles[x,z];
			}
		}
		return null;
	}
	
	public GameObject GetUnit(int x, int z)
	{
		if(x > 0 && z > 0 && x < UnitList.GetLength(0) && z < UnitList.GetLength(1))
		{
			if(UnitList[x,z] != null)
			{
				return UnitList[x,z];
			}
		}
		return null;
	}
	
	public void DestroyTile(int x, int z)
	{
		if(Network.peerType != NetworkPeerType.Disconnected)
		{
			if(Network.isServer)
			{
				ServerDestroyTile(x,z);
			}
			else
			{
				networkView.RPC("ServerDestroyTile", RPCMode.Server, x,z);
			}
		}
		else
		{	
			LocalDestroyTile(x,z);
		}
	}
	
	[RPC]
	public void ServerDestroyTile(int x,int z)
	{
		networkView.RPC("LocalDestroyTile", RPCMode.AllBuffered, x,z);
	}
	
	[RPC]
	public void LocalDestroyTile(int x,int z)
	{
		GameObject tile = (GameObject) tiles[x,z];
		tiles[x,z] = null;
		Destroy(tile);
	}
	
	public int GetGrassWeight(int x, int z)
	{
		int weight = 0;
		if(x > 0)
		{
			if(tiles[x-1,z] != null)
			{
				weight++;
			}
		}
		if(x < tiles.GetLength(0)-1)
		{
			if(tiles[x+1,z] != null)
			{
				weight++;
			}
		}
		if(z > 0)
		{
			if(tiles[x,z-1] != null)
			{
				weight++;
			}
		}
		if(z < tiles.GetLength(1))
		{
			if(tiles[x,z+1] != null)
			{
				weight++;
			}
		}
		return weight;
	}
	
	public void ServerMoveUnit(int fromX, int fromZ, int toX, int toZ, int currentHealth)
	{
		networkView.RPC("MoveUnit", RPCMode.AllBuffered, fromX, fromZ, toX, toZ, currentHealth);
	}
	
	[RPC]
	public void MoveUnit(int fromX, int fromZ, int toX, int toZ, int currentHealth)
	{
		if(UnitList[fromX, fromZ] != null)
		{
			
			GameObject _unit = UnitList[fromX, fromZ];
			UnitList[fromX, fromZ] = null;
			_unit.transform.position = new Vector3(toX*5,0,toZ*5);
			_unit.GetComponent<Unit>().SetHealth(currentHealth);
			UnitList[toX, toZ] = _unit;
		}
	}
	
	public bool isAUnitThere(int x, int z)
	{
		return (UnitList[x,z] != null);
	}
	
	
	public void ModifyTexture(Vector3 position, int owner)
	{
		//Debug.Log("Make the grass grow!");
		Vector3 tempCoord = (position - terrain.gameObject.transform.position);
	
	
		Vector3 coord;
		float x = (int)Mathf.Round(tempCoord.x/5);
		float y = (int)Mathf.Round(tempCoord.y);
		float z = (int)Mathf.Round(tempCoord.z/5);
		
		x*=5;
		x-=2.5f;
		z*=5;
		z-=2.5f;
		
		//Debug.Log("{"+x+", "+y+", "+z+"}");
			
		coord.x = (x/terrain.terrainData.size.x);
		coord.y = (y/terrain.terrainData.size.y);
		coord.z = (z/terrain.terrainData.size.x);
	
		//Debug.Log(" <"+coord.x+", "+coord.z+"> ");
		
		int posXInTerrain = (int) (coord.x * alphaWidth);
		int posZInTerrain = (int) (coord.z * alphaHeight);
		
		//Debug.Log("--"+posXInTerrain+", "+posZInTerrain+"--");
		
		float[,,] maps = terrain.terrainData.GetAlphamaps((int)posXInTerrain,(int)posZInTerrain,squareSize,squareSize);
		for(int i = 0; i < squareSize; i++)
		{
			for(int j = 0; j < squareSize; j++)
			{
				maps[i,j,0] = 0;
				maps[i,j,1] = 0;
				maps[i,j,2] = 0;
				maps[i,j,3] = 0;
				maps[i,j,4] = 0;
				maps[i,j,owner+1] = 1;
			}
		}
		terrain.terrainData.SetAlphamaps((int)posXInTerrain,(int)posZInTerrain,maps);
	}
	
	public float GetTerrainHeight(Vector3 position)
	{
		Vector3 tempCoord = (position - terrain.gameObject.transform.position);
	
	
		Vector3 coord;
		float x = (int)Mathf.Round(tempCoord.x/5);
		float y = (int)Mathf.Round(tempCoord.y);
		float z = (int)Mathf.Round(tempCoord.z/5);
		
		x*=5;
		x-=2.5f;
		z*=5;
		z-=2.5f;
		
		//Debug.Log("{"+x+", "+y+", "+z+"}");
			
		coord.x = (x/terrain.terrainData.size.x);
		coord.y = (y/terrain.terrainData.size.y);
		coord.z = (z/terrain.terrainData.size.x);
	
		//Debug.Log(" <"+coord.x+", "+coord.z+"> ");
		
		int posXInTerrain = (int) (coord.x * terrainWidth);
		int posZInTerrain = (int) (coord.z * terrainHeight);
		
		float[,] height = terrain.terrainData.GetHeights(posXInTerrain,posZInTerrain,squareSize,squareSize);
		return height[0,0];
	}
}
