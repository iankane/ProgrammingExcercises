using UnityEngine;
using System.Collections;

public class NetworkManager : MonoBehaviour {

    //network info
    private string connectionIP = "127.0.0.1";
    private int connectionPort = 25005;

    //player info
    private string playerName = "Player Name";
    public string PlayerName
    {
        get { return playerName; }
        set { playerName = value; }
    }

    private GameObject playerLabel;
    private string[] playerNameList;
    enum levels { Lobby, gameplay }

    //connect window setup
    private Rect connectWindowRect;
    private int connectWindowWidth = 320;
    private int connectWindowHeight = 150;
    private int buttonHeight = 45;
    private int leftIndent;
    private int topIndent;
    private string titleMessage = "Connection Setup";


    //players window setup
    private Rect playersWindowRect;
    private int playersWindowWidth = 220;
    private int playersWindowHeight = 200;

    //server window setup
    private Rect serverWindowRect;
    private int serverWindowWidth = 180;
    private int serverWindowHeight = 60;

    //Economy Window
    private Rect economyWindowRect;
    private int economyWindowWidth = 450;
    private int economyWindowHeight = 160;

    public GUIStyle format = new GUIStyle();

    public bool ReadyForGame = false;
    public bool IWantToReturnToLobby;

    public static int TimesInLobby = 0;
	
	private Rect colorWindowRect;
	private int colorWindowWidth = 220;
    private int colorWindowHeight = 200;
	
	public bool redSelected = false;
	public bool redAvailable = true;
	public bool blueSelected = false;
	public bool blueAvailable = true;
	public bool greenSelected = false;
	public bool greenAvailable = true;
	public bool yellowSelected = false;
	public bool yellowAvailable = true;

    public static GameObject instance;
	

    // Keep track of various menu and ingame states
    public enum MenuState
    {
        lobby,    	        // Master Game Server Lobby
        ingame,             // In a game as either the GS or Client
    }
    public MenuState CurrentMenuState = MenuState.lobby;
	
    //
    private bool iWantToBeClient = false;

    //----------------end variables -----------------

    void Start()
    {
        playerName = PlayerPrefs.GetString("playerName");
        if (playerName == "" || playerName == null)
        {
            playerName = "Player" + Random.Range(0, 1000);
        }
        if (instance == null)
        {
            instance = gameObject;
        }
        else
        {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(transform.gameObject);
    }


    void startServer()
    {
        Network.InitializeServer(32, connectionPort, Network.HavePublicAddress());
        Debug.Log("Started the server, I hope!");
    }

    //----------- handle incoming messages FROM THE SERVER ------------

    //-----these messages are sent to the server

    //we are informed that we were successful in initializing the server
    void OnServerInitialized()
    {
        
        UpdateNameLocally("Server");
        Debug.Log("server is initialized and ready to receive!!!!");
        //Application.LoadLevel("lobby");
        //GameObject.Find("NetworkManagerGO").GetComponent<NetworkIDList>() . sendData();
        //ss.GetComponent<SpawnScript>().spawnPlayer();
    }

    // we are informed that a player has just connected to us (the server)
    void OnPlayerConnected(NetworkPlayer player)
    {
        Debug.Log("Player " + player.guid + " connected from " + player.ipAddress + ":" + player.port + "        " + playerName);
        
    }

    ///-----these messages are sent to the CLIENT

    void OnConnectedToServer()
    {
        Debug.Log("I'm a client, connected to server");
        UpdateNameLocally(playerName);
        
        //GameObject.Find("NetworkManagerGO").GetComponent<NetworkIDList>() . sendData();
        //ss.GetComponent<SpawnScript>().spawnPlayer();
    }

    //called on both client AND server
    void OnDisconnectedFromServer(NetworkDisconnection info)
    {
        //reload the application so we can start over
        //Application.LoadLevel("start");
        iWantToBeClient = false;
    }


    //some player has disconnected. 
    //We'd better clean up their stuff
    void OnPlayerDisconnected(NetworkPlayer player)
    {
        Debug.Log("Clean up after player " + player);
        Network.RemoveRPCs(player);
        Network.DestroyPlayerObjects(player);
    }
    //----------- end incoming messages from SERVER ------------

    void UpdateNameLocally(string pName)
    {
        //Tell the PlayerListManager script to append this
        //player's name to the list.
        Debug.Log("TEST 2     NetworkManager:UpdateNameLocally " + pName);
        GameObject networkManager = GameObject.Find("NetworkManagerGO");
        IDList idl = networkManager.GetComponent<IDList>();

        idl.NeedToSetName = true;
        idl.MyOwnName = pName;

    }


    void ConnectWindow(int windowID)
    {
        //Leave a gap after the header.
        GUILayout.Space(15);

        if (GUILayout.Button("Start Server", GUILayout.Height(buttonHeight)))
        {
            ClearIDList();
            startServer();
        }

        GUILayout.Space(5);
        if (GUILayout.Button("Join the Game", GUILayout.Height(buttonHeight)))
        {
            Debug.Log("I wanna join as client");
            iWantToBeClient = true;
        }
    }

    void ClientConnectWindow(int windowID)
    {
        if (iWantToBeClient == true)
        {
            //Entry text field for player name
            GUILayout.Label("Enter your player name:");
            playerName = GUILayout.TextField(playerName);

            

            GUILayout.Space(5);

            //The player enters IP
            GUILayout.Label("Enter Server IP:");
            connectionIP = GUILayout.TextField(connectionIP);

            GUILayout.Space(5);

            //... and the port #
            GUILayout.Label("Enter Server Port:");
            connectionPort = int.Parse(GUILayout.TextField(connectionPort.ToString()));

            GUILayout.Space(20);

            if (GUILayout.Button("Connect!", GUILayout.Height(25)))
            {
                if (playerName == "")
                {
                    playerName = "Player";
                }
                if (playerName != "")
                {
                    //Do the connection
                    Network.Connect(connectionIP, connectionPort);

                    //Store the player name locally
                    PlayerPrefs.SetString("playerName", playerName);
                }
            }

            GUILayout.Space(5);

            if (GUILayout.Button("Go Back", GUILayout.Height(25)))
            {
                iWantToBeClient = false;
            }

        }
    }

    

    void ServerInfoWindow(int windowID)
    {

        //Show the number of players connected.
        GUILayout.Label("Players: " + (Network.connections.Length + 1)); // add in ourselves

        //If there is at least one connection then show the average ping.
        if (Network.connections.Length >= 1)
        {
            GUILayout.Label("Ping: " + Network.GetAveragePing(Network.connections[0]));
        }

        //If server, we can bump everyone back to lobby. 
        if (GUILayout.Button("Back to Lobby"))
        {
            // No longer ready for game
            ReadyForGame = false;
            // Destroy the player
            Network.Destroy(GameObject.Find(playerName));
            // this variable is watched in NetworkLoadLevel, and if true, takes everyone back to lobby.
            IWantToReturnToLobby = true;
        }
    }

    void PlayerListWindow(int windowID)
    {

        int count = 1;

        // Button
        if (GUILayout.Button("Disconnect"))
        {

            

            ClearIDList();

            if (Network.isServer)
            {
                networkView.RPC("AllClear", RPCMode.AllBuffered);
            }

            //maybe you wanna get out of here
            Network.Disconnect();

            // Go back to lobby
            //CurrentMenuState = MenuState.lobby;
            
            // No longer ready for a game
            //ReadyForGame = false;

            // Go back to lobby
            //Application.LoadLevel("Lobby");
        }

        GUILayout.Space(25);

        // show list of players and names

        // Get the playerlist
        ArrayList players = GameObject.Find("NetworkManagerGO").GetComponent<IDList>().PlayerList;

        // For every player
        for (int i = 0; i < players.Count; i++)
        {
            // Display player info
            GUILayout.Label(count + " " + (players[i] as PlayerData).PlayerName);
            count++;



            //GUILayout.Label("Player ID #" + (players[i] as PlayerData).NetworkPlayerID.ToString() + ": " + (players[i] as PlayerData).PlayerName);
            GUILayout.Space(5);
        }


    }
	
	void PlayerColorSelect(int windowID)
	{
        // Get the selected statuses
		bool redController = redSelected;
		bool blueController = blueSelected;
		bool greenController = greenSelected;
		bool yellowController = yellowSelected;
		if(redAvailable || redSelected)
		{
			redSelected = GUI.Toggle (new Rect(10,50,70,30),redSelected, "Red");
			if(redSelected)
			{
				PlayerPrefs.SetInt("Color",0);
				blueSelected = false;
				greenSelected = false;
				yellowSelected = false;
			}
		}
		else if(!redSelected && !redAvailable)
		{
			GUI.Label(new Rect(10,50,70,30), "X Red");
		}
		if(blueAvailable || blueSelected)
		{
			blueSelected = GUI.Toggle (new Rect(90,50,70,30),blueSelected, "Blue");
			if(blueSelected)
			{
				PlayerPrefs.SetInt("Color",1);
				redSelected = false;
				greenSelected = false;
				yellowSelected = false;
			}
		}
		else if(!blueSelected && !blueAvailable)
		{
			GUI.Label(new Rect(90,50,70,30), "X Blue");
		}
		if(greenAvailable || greenSelected)
		{
			greenSelected = GUI.Toggle (new Rect(10,90,70,30),greenSelected, "Green");
			if(greenSelected)
			{
				PlayerPrefs.SetInt("Color",3);
				blueSelected = false;
				redSelected = false;
				yellowSelected = false;
			}
		}
		else if(!greenSelected && !greenAvailable)
		{
			GUI.Label(new Rect(10,90,70,30), "X Green");
		}
		if(yellowAvailable || yellowSelected)
		{
			yellowSelected = GUI.Toggle (new Rect(90,90,70,30),yellowSelected, "Yellow");
			if(yellowSelected)
			{
				PlayerPrefs.SetInt("Color",2);
				blueSelected = false;
				greenSelected = false;
				redSelected = false;
			}
		}
		else if(!yellowSelected && !yellowAvailable)
		{
			GUI.Label(new Rect(90,90,70,30), "X Yellow");
		}
		
		
		if(redSelected != redController)
		{
			networkView.RPC("SetRed", RPCMode.AllBuffered, !redAvailable);
		}
		if(blueSelected != blueController)
		{
			networkView.RPC("SetBlue", RPCMode.AllBuffered, !blueAvailable);
		}
		if(yellowSelected != yellowController)
		{
			networkView.RPC("SetYellow", RPCMode.AllBuffered, !yellowAvailable);
		}
		if(greenSelected != greenController)
		{
			networkView.RPC("SetGreen", RPCMode.AllBuffered, !greenAvailable);
		}
		GUILayout.Space(5);
            //The player enters IP
	}

    void EconomyWindow(int windowID)
    {
        // show list of players and names
        GUILayout.Space(15);
        IDList id = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();

        GUILayout.Label("Current Grass: " + id.MyGrass + "\t\t\t\t\t Placeable Grass: " + (int)Mathf.Floor(id.CurrentGrassSeeds) + "/ " + id.MaxGrassSeeds);
        GUILayout.Space(5);
        GUILayout.Label("Current Sheep: " + id.MySheep + "\t\t\t\t\t Placeable Sheep: " + (int)Mathf.Floor(id.CurrentSheepSeeds) + "/ " + id.MaxSheepSeeds);
        GUILayout.Space(5);
        GUILayout.Label("Current Wolves: " + id.MyWolves + "\t\t\t\t\t Placeable Wolves: " + (int)Mathf.Floor(id.CurrentWolfSeeds) + "/ " + id.MaxWolfSeeds);
        GUILayout.Space(5);
		GUILayout.Label("Current Dirt: " + id.DirtBucket);
		GUILayout.Space(5);

    }
	
	[RPC]
	public void SetRed(bool available)
	{
		redAvailable = available;
	}
	[RPC]
	public void SetBlue(bool available)
	{
		blueAvailable = available;
	}
	[RPC]
	public void SetGreen(bool available)
	{
		greenAvailable = available;
	}
	[RPC]
	public void SetYellow(bool available)
	{
		yellowAvailable = available;
	}

    void OnGUI()
    {   

        if (CurrentMenuState == MenuState.lobby)
        {
            if (Network.peerType == NetworkPeerType.Disconnected)
            {
                if (iWantToBeClient)
                {
                    leftIndent = Screen.width / 2 - connectWindowWidth / 2;
                    topIndent = Screen.height / 3 - connectWindowHeight / 2;
                    connectWindowRect = new Rect(leftIndent, topIndent, connectWindowWidth, connectWindowHeight);
                    //create the window
                    connectWindowRect = GUILayout.Window(1, connectWindowRect, ClientConnectWindow, "Client Connection");
                }
                else
                {
                    //very first screen
                    //set up connection window in center of screen 	
                    leftIndent = Screen.width / 2 - connectWindowWidth / 2;
                    topIndent = Screen.height / 3 - connectWindowHeight / 2;
                    connectWindowRect = new Rect(leftIndent, topIndent, connectWindowWidth, connectWindowHeight);
                    //create the window
                    connectWindowRect = GUILayout.Window(0, connectWindowRect, ConnectWindow, titleMessage);
                }


            } // end disconnected
            else
            {
                //connected already, show player list
                
                format.fontSize = 20;
                format.alignment = TextAnchor.UpperCenter;
                format.normal.textColor = Color.black;
                GUI.Label(new Rect((Screen.width / 2) - 200, 50, 400, 50), "Biome\nLOBBY", format);

                //show the list of players
                playersWindowRect = new Rect(Screen.width - playersWindowWidth - 20, 20, playersWindowWidth, playersWindowHeight);
                playersWindowRect = GUILayout.Window(2, playersWindowRect, PlayerListWindow, "Connected Players");
				
				colorWindowRect = new Rect(25,25,colorWindowHeight,colorWindowHeight);
				colorWindowRect = GUILayout.Window(3,colorWindowRect,PlayerColorSelect, "Color Selection");

                //play button
                if (Network.peerType == NetworkPeerType.Server)
                {
                    if (GUI.Button(new Rect(Screen.width / 2 - 100, 200, 200, 50), "Start the Game!"))
                    {
                        //NetworkLoadLevel looks for a change in this boolean: 
                        ReadyForGame = true;
                    }
                }
                if (Network.peerType == NetworkPeerType.Client)
                {
                    format.fontSize = 12;
                    GUI.Label(new Rect(Screen.width / 2 - 100, 200, 200, 50), "waiting for game to start...", format);
                }


            }

        }// end lobby

        else if (CurrentMenuState == MenuState.ingame)
        {
            economyWindowRect = new Rect(20, Screen.height - economyWindowHeight - 20, economyWindowWidth, economyWindowHeight);
            economyWindowRect = GUILayout.Window(3, economyWindowRect, EconomyWindow, "Economy");

            if (Network.peerType == NetworkPeerType.Server)
            {
                serverWindowRect = new Rect(Screen.width - serverWindowWidth - 20, Screen.height - serverWindowHeight - 60, serverWindowWidth, serverWindowHeight);
                serverWindowRect = GUILayout.Window(4, serverWindowRect, ServerInfoWindow, "Server");

            }

            if (Network.peerType == NetworkPeerType.Client)
            {
                // a little disconnect button, could be nicer
                if (GUI.Button(new Rect(20, 20, 120, 20), "Disconnect"))
                {
                    Network.Disconnect();
                    CurrentMenuState = MenuState.lobby;
                    ReadyForGame = false;
					
					if(redSelected)
					{
						networkView.RPC("SetRed", RPCMode.AllBuffered, true);
					}
					if(blueSelected)
					{
						networkView.RPC("SetBlue", RPCMode.AllBuffered, true);
					}
					if(greenSelected)
					{
						networkView.RPC("SetGreen", RPCMode.AllBuffered, true);
					}
					if(yellowSelected)
					{
						networkView.RPC("SetYellow", RPCMode.AllBuffered, true);
					}
                    Application.LoadLevel("Lobby");
                }

            }
        }
    }


    
    public void ClearIDList()
    {
        GameObject.Find("NetworkManagerGO").GetComponent<IDList>().PlayerList.Clear();

        if (redSelected)
        {
            networkView.RPC("SetRed", RPCMode.AllBuffered, true);
        }
        if (blueSelected)
        {
            networkView.RPC("SetBlue", RPCMode.AllBuffered, true);
        }
        if (greenSelected)
        {
            networkView.RPC("SetGreen", RPCMode.AllBuffered, true);
        }
        if (yellowSelected)
        {
            networkView.RPC("SetYellow", RPCMode.AllBuffered, true);
        }

        // Set color picking back to default
        redSelected = false;
        redAvailable = true;
        blueSelected = false;
        blueAvailable = true;
        greenSelected = false;
        greenAvailable = true;
        yellowSelected = false;
        yellowAvailable = true;



        
    }

    [RPC]
    public void AllClear()
    {
        GameObject.Find("NetworkManagerGO").GetComponent<IDList>().PlayerList.Clear();

        // Set color picking back to default
        redSelected = false;
        redAvailable = true;
        blueSelected = false;
        blueAvailable = true;
        greenSelected = false;
        greenAvailable = true;
        yellowSelected = false;
        yellowAvailable = true;

        
    }
}

