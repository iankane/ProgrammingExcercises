using UnityEngine;
using System.Collections;

public class IDList : MonoBehaviour {

    [SerializeField]
    private float startTimer = 0;

    [SerializeField]
    private float currentTime = 0;

    [SerializeField]
    private float ReloadRate = 1;

    //score window setup
    private Rect windowRect2;/*
    private int windowLeft = 10;
    private int windowTop;
    private int windowWidth = 300;
    private int windowHeight = 140;
    private int padding = 20;*/

    private ArrayList playerList;
    public bool NeedToSetName = false;
    public bool addGrass = false;
    public bool addSheep = false;
    public bool addWolves = false;
    public bool terrainChange = false;

    private string myOwnName;
    public int myOwnColor;
    public int myOwnScore;

    //Economy Stuff
    private int myGrass;
    private int mySheep;
    private int myWolves;
    //max ammo limits
    private int maxGrassSeeds;
    private int maxSheepSeeds;
    private int maxWolfSeeds;
    //current ammo ammount
    private float currentGrassSeeds;
    private float currentSheepSeeds;
    private float currentWolfSeeds;
	
	private int usableGrassSeeds;
	private int usableSheepSeeds;
	private int usableWolfSeeds;
    //Bucket of Terrain
    private int dirtBucket;

    private int scoreValue;
    private NetworkPlayer thisPlayer;


    [SerializeField]
    public Material[] materials;

    public ArrayList PlayerList
    {
        get { return playerList; }
        set { playerList = value; }
    }

    public string MyOwnName
    {
        get { return myOwnName; }
        set { myOwnName = value; }
    }

    public int ScoreValue
    {
        get { return scoreValue; }
        set { scoreValue = value; }
    }

    public int MyGrass
    {
        get { return myGrass; }
        set { myGrass = value; }
    }

    public int MySheep
    {
        get { return mySheep; }
        set { mySheep = value; }
    }

    public int MyWolves
    {
        get { return myWolves; }
        set { myWolves = value; }
    }

    public int MaxGrassSeeds
    {
        get { return maxGrassSeeds; }
        set { maxGrassSeeds = value; }
    }

    public int MaxSheepSeeds
    {
        get { return maxSheepSeeds; }
        set { maxSheepSeeds = value; }
    }

    public int MaxWolfSeeds
    {
        get { return maxWolfSeeds; }
        set { maxWolfSeeds = value; }
    }

    public float CurrentGrassSeeds
    {
        get { return currentGrassSeeds; }
        set { currentGrassSeeds = value; }
    }

    public float CurrentSheepSeeds
    {
        get { return currentSheepSeeds; }
        set { currentSheepSeeds = value; }
    }

    public float CurrentWolfSeeds
    {
        get { return currentWolfSeeds; }
        set { currentWolfSeeds = value; }
    }

    public int DirtBucket
    {
        get { return dirtBucket; }
        set { dirtBucket = value; }
    }

    // Use this for initialization
    void Start()
    {
        DontDestroyOnLoad(gameObject);

        if (NetworkManager.TimesInLobby > 1)
        {
            Destroy(gameObject);
        }

        playerList = new ArrayList();
        int colorIndex = 0;
        myOwnScore = 0;
        myOwnScore = 0;
        myGrass = 0;
        mySheep = 0;
        myWolves = 0;
        maxWolfSeeds = 1;
        maxSheepSeeds = 3;
        maxGrassSeeds = 5;
        currentGrassSeeds = maxGrassSeeds;
        currentSheepSeeds = 0;
        currentWolfSeeds = 0;

        dirtBucket = 0;
        myOwnColor = colorIndex;

    }

    void Update()
    {
        currentTime += Time.deltaTime;

        if (NeedToSetName)
        {
            networkView.RPC("EditNameInList", RPCMode.AllBuffered, Network.player, myOwnName);
            networkView.RPC("EditColorInList", RPCMode.AllBuffered, thisPlayer, myOwnColor);
            NeedToSetName = false;
        }
        /*if (addGrass)
        {
            networkView.RPC("EditGrassInList", RPCMode.AllBuffered, thisPlayer, myGrass);
            //Debug.Log("Grass = " + myGrass);
            addGrass = false;
        }
        if (addSheep)
        {
            networkView.RPC("EditSheepInList", RPCMode.AllBuffered, thisPlayer, mySheep);
            //Debug.Log("Sheeples = " + mySheep);
            addSheep = false;
        }
        if (addWolves)
        {
            networkView.RPC("EditWolvesInList", RPCMode.AllBuffered, thisPlayer, myWolves);
            // Debug.Log("Wolves = " + myWolves);
            addWolves = false;
        }*/
        //ECONOMY:  Update the max ammo for wolves
        if (myGrass / 10 > maxWolfSeeds)
        {
            //maxWolfSeeds = myGrass / 10;
        }
        //ECONOMY:  Update the max ammo for sheep
        if (myGrass / 5 > maxSheepSeeds)
        {
            //maxSheepSeeds = myGrass / 5;
        }
        //update the current seed count every REFRESH seconds
        if (currentTime >= startTimer + ReloadRate)
        {
            if (currentGrassSeeds < maxGrassSeeds)
            {
                currentGrassSeeds++;
				usableSheepSeeds = (int) Mathf.Floor(currentGrassSeeds);
            }
            if (currentSheepSeeds < maxSheepSeeds)
            {
                currentSheepSeeds +=  .2f;
				usableSheepSeeds = (int) Mathf.Floor(currentSheepSeeds);
                if (currentSheepSeeds > maxSheepSeeds)
                {
                    currentSheepSeeds = maxSheepSeeds;
                }
            }
            if (currentWolfSeeds < maxWolfSeeds)
            {
                currentWolfSeeds += .1f;
				usableWolfSeeds = (int) Mathf.Floor(currentWolfSeeds);
                if (currentWolfSeeds > maxWolfSeeds)
                {
                    currentWolfSeeds = maxWolfSeeds;
                }
            }
            startTimer = Time.time;
        }
        /*
        if (addScore)
        {
            myOwnScore += scoreValue;
            networkView.RPC("EditScoreInList", RPCMode.AllBuffered, thisPlayer, myOwnScore);
            Debug.Log("Name: " + this + " Score: " + myOwnScore);
            addScore = false;
        }*/
    }

    public void OnServerInitialized()
    {
        
        networkView.RPC("AddServerToList", RPCMode.AllBuffered);
        //Debug.Log("ID List added server to list.");
    }

    public void OnPlayerConnected(NetworkPlayer player)
    {
        networkView.RPC("AddPlayerToList", RPCMode.AllBuffered, player);
        print("The NetworkPlayer ID is111     " + thisPlayer.ToString() +  "         AND    " + player.ToString());
        //Debug.Log("Player: " + player + " Added!");
        
    }

    void OnConnectedToServer()
    {
        //Debug.Log("I'm a client, connected to server");
    }

    public void OnPlayerDisconnected(NetworkPlayer player)
    {
        networkView.RPC("RemovePlayerFromList", RPCMode.AllBuffered, player);
    }


    [RPC]
    void AddServerToList()
    {
        PlayerData d = new PlayerData();
        d.NetworkPlayerID = 0;
        playerList.Add(d);
        //Debug.Log("Server added.");
    }

    [RPC]
    void AddPlayerToList(NetworkPlayer player)
    {
        PlayerData d = new PlayerData();
        d.NetworkPlayerID = int.Parse(player.ToString());
        playerList.Add(d);
        //Debug.Log("Player " + player.ToString() + " added.");
    }

    [RPC]
    void RemovePlayerFromList(NetworkPlayer player)
    {
        for (int i = 0; i < playerList.Count; i++)
        {
            int temp = (playerList[i] as PlayerData).NetworkPlayerID;
            if (temp == int.Parse(player.ToString()))
            {
                //Debug.Log("Player " + (playerList[i] as PlayerData).PlayerName + " removed.");
                playerList.RemoveAt(i);
            }
        }
    }


    [RPC]
    void EditNameInList(NetworkPlayer player, string pName)
    {
        print("The NetworkPlayer ID is     " + thisPlayer.ToString() + "         AND    " + player.ToString());
        foreach (PlayerData pd in playerList)
        {
            print(pd.NetworkPlayerID);

            if (pd.NetworkPlayerID == int.Parse(player.ToString()))
            {


                pd.PlayerName = pName;
                print(pd.PlayerName);
            }
        }
    }

    [RPC]
    void EditColorInList(NetworkPlayer player, int color)
    {
        foreach (PlayerData pd in playerList)
        {

            if (pd.NetworkPlayerID == int.Parse(player.ToString()))
            {
                pd.ColorIndex = color;
            }
        }
    }

    [RPC]
    void EditGrassInList(NetworkPlayer player, int grass)
    {
        foreach (PlayerData pd in playerList)
        {

            if (pd.NetworkPlayerID == int.Parse(player.ToString()))
            {
                pd.GrassCount = grass;
            }
        }
    }

    [RPC]
    void EditSheepInList(NetworkPlayer player, int sheep)
    {
        foreach (PlayerData pd in playerList)
        {

            if (pd.NetworkPlayerID == int.Parse(player.ToString()))
            {
                pd.SheepCount = sheep;
            }
        }
    }

    [RPC]
    void EditWolvesInList(NetworkPlayer player, int wolves)
    {
        foreach (PlayerData pd in playerList)
        {

            if (pd.NetworkPlayerID == int.Parse(player.ToString()))
            {
                pd.WolfCount = wolves;
            }
        }
    }

}
