using UnityEngine;
using System.Collections;

public class Grass : Unit {
	
	[SerializeField]
	private int ownerNumber = -1;
	//Red = 0
	//Blue = 1
	//Yellow = 2
	//Green = 3
	
	[SerializeField]
	private float startTimer = 0;
	
	[SerializeField]
	private float currentTime = 0;
	
	[SerializeField]
	private float growthRate = 10;

    private IDList id;

    private GameObject childObject;
	
	
	// Use this for initialization
	public void Start () {
		currentHealth = startingHealth;
		startTimer = Time.time;
		currentTime = startTimer;
        id = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();
	}
	
	// Update is called once per frame
	public void Update () {
		if(GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetTerrainHeight(transform.position) > .8 || GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetTerrainHeight(transform.position) < .41)
		{
			currentHealth = 0;
		}
		
		if(Network.peerType != NetworkPeerType.Disconnected)
		{
			
			if(Network.isServer)
			{
				if(currentHealth <= 0)
				{
                    id.MyGrass--;
                    id.addGrass = true;
					int x = (int)Mathf.Round(transform.position.x/5);
					int z = (int)Mathf.Round(transform.position.z/5);
					GameObject.Find("GameManagerGO").GetComponent<GameManager>().DestroyTile(x,z);
				}
				currentTime += Time.deltaTime;
				if(currentTime >= startTimer+growthRate)
				{
					int GrassWeight = 0;
					int x = (int)Mathf.Round(transform.position.x/5);
					int z = (int)Mathf.Round(transform.position.z/5);
					GrassWeight = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrassWeight(x,z);
					if(GrassWeight < 4)
					{
						GameObject.Find("GameManagerGO").GetComponent<GameManager>().Proliferate(transform.position, ownerNumber);
					}
					startTimer = Time.time;
				}
			}
		}
		else
		{
			if(currentHealth <= 0)
			{
                id.MyGrass--;
                id.addGrass = true;
				int x = (int)Mathf.Round(transform.position.x/5);
				int z = (int)Mathf.Round(transform.position.z/5);
				GameObject.Find("GameManagerGO").GetComponent<GameManager>().DestroyTile(x,z);
			}
			currentTime += Time.deltaTime;
			if(currentTime >= startTimer+growthRate)
			{
				GameObject.Find("GameManagerGO").GetComponent<GameManager>().Proliferate(transform.position, ownerNumber);
				startTimer = Time.time;
			}
		}
	}
	
	public int Owner{
		get{return ownerNumber;}
	}

    public void SetOwner(int owner)
    {
        ownerNumber = owner;
    }

    public void SetColor()
    {
        foreach (Transform child in gameObject.transform)
        {
            //Debug.Log(child.name + " BlockChild");
            foreach (Transform child2 in child)
            {
                //Debug.Log(child2.name + "Children of Child");
                if (child2.gameObject.name == "polySurface8")
                {
                    //Debug.Log("Grabbing material Object");
                    childObject = (GameObject)child2.gameObject;
                }
            }
            switch (ownerNumber)
            {
                case 0:
                    childObject.renderer.material.color = Color.red;
                    break;
                case 1:
                    childObject.renderer.material.color = Color.blue;
                    break;
                case 2:
                    childObject.renderer.material.color = Color.yellow;
                    break;
                case 3:
                    childObject.renderer.material.color = Color.green;
                    break;
            }
        }
    }
	
	public void setHealth(int editValue)
	{
		currentHealth -= editValue;
	}
	
	void OnDestroy()
	{
        if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isTerrainNull())
    	    GameObject.Find("GameManagerGO").GetComponent<GameManager>().ModifyTexture(transform.position,-1);
	}
}
