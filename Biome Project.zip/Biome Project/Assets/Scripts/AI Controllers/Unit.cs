using UnityEngine;
using System.Collections;

public class Unit : MonoBehaviour {
	
	public int ListNumber = -1;
	[SerializeField]
	protected int currentHealth = 0;
	[SerializeField]
	protected int startingHealth = 10;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void SetHealth(int hp)
	{
		currentHealth = hp;
	}
}
