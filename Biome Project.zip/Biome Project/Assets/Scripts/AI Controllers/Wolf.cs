using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Wolf : Unit {
	
	[SerializeField]
	private int ownerNumber = -1;
	
	[SerializeField]
	private float startTimer = 0;
	
	[SerializeField]
	private float currentTime = 0;
	
	[SerializeField]
	private float eatRate = 1;
	
	private IDList id;
	
	private bool starving = false;
	
	private GameObject childObject;
	
	// Use this for initialization
	void Start () {
		startTimer = Time.time;
		currentTime = startTimer;
		currentHealth = startingHealth;
		id = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();
	}
	
	// Update is called once per frame
	void Update () {
		if(Network.isServer)
		{
			if(currentHealth <= 0)
			{
				id.MyWolves--;
				id.addWolves = true;
				Destroy(gameObject);
				int X = (int)Mathf.Round(transform.position.x/5);
				int Z = (int)Mathf.Round(transform.position.z/5);
				GameObject.Find("GameManagerGO").GetComponent<GameManager>().ServerMoveUnit(X, Z, X, Z, currentHealth);
			}
			currentTime += Time.deltaTime;
			if(currentTime >= startTimer+eatRate)
			{
				starving = true;
				int x = (int)Mathf.Round(transform.position.x/5);
				int z = (int)Mathf.Round(transform.position.z/5);
				
				
				for(int i = -1; i <= 1; i++)
				{
					for(int j = -1; j <= 1; j++)
					{
						Debug.Log("i = "+i+", j = "+j);
						if(!(i == 0 && j == 0))
						{
							if(checkFood(i,j))
							{
								Debug.Log("Om nom nom Mr. Sheep");
								currentHealth += 10;
								GameObject sheep = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetUnit(x+i,z+j);
								sheep.GetComponent<Sheep>().SetHealth(0);
								starving = false;
							}
						}
					}
				}
				
				if(starving)
				{
					Debug.Log("No sheep");
					currentHealth--;
					Vector3 headTo = seekFood();
					int toX = (int)Mathf.Round(headTo.x/5);
					int toZ = (int)Mathf.Round(headTo.z/5);
					int fromX = (int)Mathf.Round(transform.position.x/5);
					int fromZ = (int)Mathf.Round(transform.position.z/5);
					if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(toX,toZ))
					{
						GameObject.Find("GameManagerGO").GetComponent<GameManager>().ServerMoveUnit(fromX, fromZ, toX, toZ, currentHealth);
					}
				}
				startTimer = Time.time;
			}
		}
	}
	
	public int Owner{
		get{return ownerNumber;}
	}
	
	private bool checkFood(int xOffset, int zOffset)
	{
		int x = (int)Mathf.Round(transform.position.x/5);
		int z = (int)Mathf.Round(transform.position.z/5);
		
		Debug.Log(xOffset+", "+zOffset);
		
		if(GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x+xOffset,z+zOffset))
		{
			GameObject sheep = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetUnit(x+xOffset,z+zOffset);
			if(sheep != null)
			{
				if(sheep.GetComponent<Sheep>() != null)
				{
					if(sheep.GetComponent<Sheep>().Owner != ownerNumber)
					{
						return true;
					}
					else
					{
						Debug.Log("That's a friendly sheep.");
					}
				}
				else
				{
					Debug.Log("That's not a sheep.");
				}
			}
			else
			{
				Debug.Log("I don't see a sheep");
			}
		}
		else
		{
			Debug.Log("null");
		}
		return false;
	}
	
	private Vector3 seekFood()
	{
		int x = (int)Mathf.Round(transform.position.x/5);
		int z = (int)Mathf.Round(transform.position.z/5);
		
		List<Vector3> directions = new List<Vector3>();
		bool thereIsAChoice = false;
		
		for(int i = -2; i <= 2; i++)
		{
			for(int j = -2; j <= 2; j++)
			{
				if(GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x+i,z+j))
				{
					GameObject target = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetUnit(x+i,z+j);
					if(target != null)
					{
						if(target.GetComponent<Sheep>() != null)
						{
							int xOffSet = 1;
							int zOffSet = 1;
							
							if(i < 0)
							{
								xOffSet *= -1;
							}
							else if(i == 0)
							{
								xOffSet = 0;
							}
							if(j < 0)
							{
								zOffSet *= -1;
							}
							else if(j == 0)
							{
								zOffSet = 0;
							}
							
							directions.Add(new Vector3((x+xOffSet)*5,0,(z+zOffSet)*5));
							thereIsAChoice = true;
							
						}
					}
				}
			}
		}
		
		if(thereIsAChoice)
		{
			int random = (int)Mathf.Round(Random.value*directions.Count-1);
			if(random == -1)
				random = 0;
			
			return directions[random];
		}
		return transform.position;
	}

    public void SetOwner(int owner)
    {
        ownerNumber = owner;

    }

    public void SetColor()
    {
        foreach (Transform child in gameObject.transform)
        {
            //Debug.Log(child.name + "Children");
            if (child.gameObject.name == "WolfFBX")
            {
                //Debug.Log("Grabbing Child Object");
                childObject = (GameObject)child.gameObject;
            }
        }
        switch (ownerNumber)
        {
            case 0:
                childObject.renderer.material.color = Color.red;
                break;
            case 1:
                childObject.renderer.material.color = Color.blue;
                break;
            case 2:
                childObject.renderer.material.color = Color.yellow;
                break;
            case 3:
                childObject.renderer.material.color = Color.green;
                break;
        }
    }
}
