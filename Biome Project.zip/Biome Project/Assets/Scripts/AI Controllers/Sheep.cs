using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Sheep : Unit {
	
	[SerializeField]
	private float startTimer = 0;
	
	[SerializeField]
	private float currentTime = 0;
	
	[SerializeField]
	private float eatRate = 1;
	
	[SerializeField]
	private int ownerNumber = -1;

    private IDList id;

	private bool starving = true;
    private GameObject childObject;
	
	
	// Use this for initialization
	void Start () {
        startTimer = Time.time;
        currentTime = startTimer;
        currentHealth = startingHealth;
        childObject = new GameObject();
        id = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();

	}
	
	// Update is called once per frame
	void Update () {
		if(Network.isServer)
		{
			if(currentHealth <= 0)
			{
                id.MySheep--;
                id.addSheep = true;
				Destroy(gameObject);
				int X = (int)Mathf.Round(transform.position.x/5);
				int Z = (int)Mathf.Round(transform.position.z/5);
				GameObject.Find("GameManagerGO").GetComponent<GameManager>().ServerMoveUnit(X, Z, X, Z, currentHealth);
			}
			currentTime += Time.deltaTime;
			if(currentTime >= startTimer+eatRate)
			{
				int x = (int)Mathf.Round(transform.position.x/5);
				int z = (int)Mathf.Round(transform.position.z/5);
				
				starving = true;
				
				GameObject grass = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrass(x,z);
				if(grass != null)
				{
					if(grass.GetComponent<Grass>().Owner != ownerNumber)
					{
						grass.GetComponent<Grass>().setHealth(1);
						starving = false;
					}
				}
				if(starving)
				{
					currentHealth--;
					Vector3 headTo = seekFood();
					int toX = (int)Mathf.Round(headTo.x/5);
					int toZ = (int)Mathf.Round(headTo.z/5);
					int fromX = (int)Mathf.Round(transform.position.x/5);
					int fromZ = (int)Mathf.Round(transform.position.z/5);
					GameObject.Find("GameManagerGO").GetComponent<GameManager>().ServerMoveUnit(fromX, fromZ, toX, toZ, currentHealth);
				}
				startTimer = Time.time;
			}
		}
		else
		{
			if(currentHealth <= 0)
			{
                id.MySheep--;
                id.addSheep = true;
				Destroy(gameObject);
			}
		}
	}
	
	public int Owner{
		get{return ownerNumber;}
	}

    public void SetOwner(int owner)
    {

        ownerNumber = owner;

    }

    public void SetColor()
    {

        foreach (Transform child in gameObject.transform)
        {
            //Debug.Log(child.name + "Children");
            if (child.gameObject.name == "polySurface3")
            {
                //Debug.Log("Grabbing Child Object");
                childObject = (GameObject)child.gameObject;
            }
        }
        // Debug.Log(childObject + "ChildObject");
        switch (ownerNumber)
        {
            case 0:
                childObject.renderer.material.color = Color.red;
                break;
            case 1:
                childObject.renderer.material.color = Color.blue;
                break;
            case 2:
                childObject.renderer.material.color = Color.yellow;
                break;
            case 3:
                childObject.renderer.material.color = Color.green;
                break;
        }
    }
	
	private Vector3 seekFood()
	{
		int x = (int)Mathf.Round(transform.position.x/5);
		int z = (int)Mathf.Round(transform.position.z/5);
		
		List<Vector3> directions = new List<Vector3>();
		bool thereIsAChoice = false;
		
		
		GameObject up = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrass(x+1,z);
		GameObject down = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrass(x-1,z);
		GameObject right = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrass(x,z+1);
		GameObject left = GameObject.Find("GameManagerGO").GetComponent<GameManager>().GetGrass(x,z-1);
		
		if(up != null)
		{
			if(up.GetComponent<Grass>() != null)
			{
				if(up.GetComponent<Grass>().Owner != ownerNumber)
				{
					if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x+1,z))
					{
						directions.Add(up.transform.position);
						thereIsAChoice = true;
					}
				}
			}
		}
		if(down != null)
		{
			if(down.GetComponent<Grass>() != null)
			{
				if(down.GetComponent<Grass>().Owner != ownerNumber)
				{
					if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x-1,z))
					{
						directions.Add(down.transform.position);
						thereIsAChoice = true;
					}
				}
			}
		}
		if(right != null)
		{
			if(right.GetComponent<Grass>() != null)
			{
				if(right.GetComponent<Grass>().Owner != ownerNumber)
				{
					if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x,z+1))
					{
						directions.Add(right.transform.position);
						thereIsAChoice = true;
					}
				}
			}
		}
		if(left != null)
		{
			if(left.GetComponent<Grass>() != null)
			{
				if(left.GetComponent<Grass>().Owner != ownerNumber)
				{
					if(!GameObject.Find("GameManagerGO").GetComponent<GameManager>().isAUnitThere(x,z-1))
					{
						directions.Add(left.transform.position);
						thereIsAChoice = true;
					}
				}
			}
		}
		if(thereIsAChoice)
		{
			int random = (int)Mathf.Round(Random.value*directions.Count-1);
			if(random == -1)
				random = 0;
			
			return directions[random];
		}
		return transform.position;
	}
}
