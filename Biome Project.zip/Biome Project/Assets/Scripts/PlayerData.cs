using UnityEngine;
using System.Collections;

public class PlayerData {

    private int ownerNumber;
	private int networkPlayerID;
	private string playerName;
	private int colorIndex;
    //Economy
    private int grassCount;
    private int sheepCount;
    private int wolfCount;

	private int score;

    public int OwnerNumber
    {
        get { return ownerNumber; }
        set { ownerNumber = value; }
    }	
	public int NetworkPlayerID { 
		get {return networkPlayerID;}
		set { networkPlayerID = value; }}
	
	public string PlayerName { 
		get {return playerName;}
		set { playerName = value; }}
	
	public int ColorIndex { 
		get {return colorIndex;}
		set { colorIndex = value; }}

    public int GrassCount
    {
        get { return grassCount; }
        set { grassCount = value; }
    }
    public int SheepCount
    {
        get { return sheepCount; }
        set { sheepCount = value; }
    }
    public int WolfCount
    {
        get { return wolfCount; }
        set { wolfCount = value; }
    }
    public int Score
    {
        get { return score; }
        set { score = value; }
    }
	
}
