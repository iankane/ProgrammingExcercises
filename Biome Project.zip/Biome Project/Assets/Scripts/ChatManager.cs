using UnityEngine;
using System.Collections;

/// <summary>
/// Chat window. 
/// This script is attached to the Game Manager.
/// It manages a community chat. 
/// Text entry box appears when user presses "t"
/// </summary>

public class ChatManager : MonoBehaviour {
	
	//----------------- variables ------------------
	
	private string playerName;  
	public string PlayerName { 
		get { return playerName;}
		set {playerName = value; }}
	
	//These are used in sending a message.
	private string messageToSend;
	private string communication;
	private bool sendMessage = false;
	
	//communication window setup
	private Rect windowRect;
	private int windowLeft = 10;
	private int windowTop;
	private int windowWidth = 300;
	private int windowHeight = 140;
	private int padding = 20;
	private int textFieldHeight = 30;
	private Vector2 scrollPosition;
	private GUIStyle myStyle = new GUIStyle();
	

	
	//--------------- end variables ----------------
	
	void Awake ()
	{		

		messageToSend = "";
		
		myStyle.normal.textColor = Color.white;
		myStyle.wordWrap = true;
	}
	
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void ChatWindow (int windowID)
	{
		//Begin a scroll view so that as the label increases with
		//length the scroll bar will appear and allow the player
		//to view past messages.
		
		scrollPosition = GUILayout.BeginScrollView(scrollPosition, 
		                                           GUILayout.Width(windowWidth - padding),
		                                           GUILayout.Height(windowHeight - padding - 5));
		
		GUILayout.Label(communication, myStyle);
		GUILayout.EndScrollView();
	}
	
	
	void OnGUI ()
	{
		 
		if(Network.peerType != NetworkPeerType.Disconnected)
		{
			windowTop = Screen.height - windowHeight - textFieldHeight;
			windowRect = new Rect(windowLeft, windowTop, windowWidth, windowHeight);
			
			windowRect = GUI.Window(5, windowRect, ChatWindow, "Chat Log");
			
			GUILayout.BeginArea(new Rect(windowLeft, windowTop + windowHeight, windowWidth,
			                             windowHeight));
			
			//If the player presses the Return key and the textfield is visible then
			//set sendMessage to true (works for Unity 3.5.6 and Unity 4.0.1)
			
			if(Event.current.type == EventType.keyUp && Event.current.keyCode == KeyCode.Return) 
			{
				sendMessage = true;	
			}

			GUILayout.BeginHorizontal();
				
				messageToSend = GUILayout.TextField(messageToSend, GUILayout.Width(windowWidth-55));
				
				//create a button because the return key may not work properly in browser
				if (GUILayout.Button("Send", GUILayout.Width(50)))
				{
					sendMessage = true;	
				}
			GUILayout.EndHorizontal();
			
			if(sendMessage == true)
			{ 
				//Only send a message if the textfield isn't empty.
				//If the textfield is empty and the user presses return
				//then that means that they don't want to send a message
				//and the textfield should no longer display.
				
				if(messageToSend != "" && messageToSend != null)
				{
				
					{
						networkView.RPC("SendMessageToEveryone", RPCMode.All, messageToSend, PlayerName);
					}
					
					
				}
				
				//Set sendMessage to false so that the message doesn't continue
				//to send after having pressed Return.
				
				sendMessage = false;
				
				//Reset messageToSend so that the user doesn't
				//have to manually delete the text when they
				//bring up the textfield again.
				
				messageToSend = "";
					
			}
			
			
			GUILayout.EndArea();
		}
			
	 
		
	}
	
	
	[RPC]
	void SendMessageToEveryone (string message, string pName)
	{
		Debug.Log("ChatManager::SendMessageToEveryone, playerName "+pName);
		//This string is displayed as a label in the ChatWindow.
		communication = pName + " : " + message + "\n" + "\n" + communication;
	}
	
	
	
	
	
}
