using UnityEngine;
using System.Collections;

public class ClickAndSpawn : MonoBehaviour {
	
	[SerializeField]
	private GameManager GM;
	
	public int selectedTool = 0;
	public string[] toolbarStrings = new string[] {"Grass", "Sheep", "Wolf", "Raise Land", "Lower Land"};
    [SerializeField]
    private IDList id;

	// Use this for initialization
	void Start () {
        id = GameObject.Find("NetworkManagerGO").GetComponent<IDList>();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetMouseButtonDown(0))
		{
				bool result = false;
				Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
				RaycastHit hit;
                if (Physics.Raycast(ray, out hit, Mathf.Infinity))
                {
                    if (selectedTool < 3)
                    {

                        if (selectedTool == 0)
                        {
                            if (id.CurrentGrassSeeds > 0)
                            {
								result = (GM.GetGrass((int)Mathf.Round(hit.point.x/5),(int)Mathf.Round(hit.point.z/5)) == null);
                                GM.AddTile(hit.point, selectedTool, PlayerPrefs.GetInt("Color"));
								if(result)
	                                id.CurrentGrassSeeds--;
                            }
                        }
                        else if (selectedTool == 1)
                        {
                            if (id.CurrentSheepSeeds >= 1)
                            {
								result = (GM.GetGrass((int)Mathf.Round(hit.point.x/5),(int)Mathf.Round(hit.point.z/5)) != null);
                                GM.AddTile(hit.point, selectedTool, PlayerPrefs.GetInt("Color"));
								if(result)
                                	id.CurrentSheepSeeds--;
                            }
                        }
                        else
                        {
                            if (id.CurrentWolfSeeds >= 1)
                            {
								result = (GM.GetGrass((int)Mathf.Round(hit.point.x/5),(int)Mathf.Round(hit.point.z/5)) != null);
                                GM.AddTile(hit.point, selectedTool, PlayerPrefs.GetInt("Color"));
								if(result)
	                                id.CurrentWolfSeeds--;
                            }
                        }

                    }
                    else if (selectedTool == 3 || selectedTool == 4)
                    {
						if(selectedTool == 3)
						{
							if(id.DirtBucket < 1)
							{
								return;
							}
						}
                        GM.AddTerrain(hit.point, (selectedTool == 3) ? true : false);
						id.DirtBucket += ((selectedTool == 3) ? -1: 1);
                    }
                }
		}
		if(Input.GetAxis("Mouse ScrollWheel") != 0)
		{
			if(Input.GetAxis("Mouse ScrollWheel") > 0)
			{
				selectedTool++;
				if(selectedTool > toolbarStrings.Length-1)
				{
					selectedTool = 0;
				}
			}
			if(Input.GetAxis("Mouse ScrollWheel") < 0)
			{
				selectedTool--;
				if(selectedTool < 0)
				{
					selectedTool = toolbarStrings.Length-1;
				}
			}
		}
	}
	
	void OnGUI()
	{
		selectedTool = GUI.Toolbar(new Rect(0,0,450,30), selectedTool, toolbarStrings);
	}
}
