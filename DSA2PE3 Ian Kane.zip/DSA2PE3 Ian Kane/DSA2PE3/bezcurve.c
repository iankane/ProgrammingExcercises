/*
 * Copyright (c) 1993-1997, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED 
 * Permission to use, copy, modify, and distribute this software for 
 * any purpose and without fee is hereby granted, provided that the above
 * copyright notice appear in all copies and that both the copyright notice
 * and this permission notice appear in supporting documentation, and that 
 * the name of Silicon Graphics, Inc. not be used in advertising
 * or publicity pertaining to distribution of the software without specific,
 * written prior permission. 
 *
 * THE MATERIAL EMBODIED ON THIS SOFTWARE IS PROVIDED TO YOU "AS-IS"
 * AND WITHOUT WARRANTY OF ANY KIND, EXPRESS, IMPLIED OR OTHERWISE,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY OR
 * FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL SILICON
 * GRAPHICS, INC.  BE LIABLE TO YOU OR ANYONE ELSE FOR ANY DIRECT,
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER, INCLUDING WITHOUT LIMITATION,
 * LOSS OF PROFIT, LOSS OF USE, SAVINGS OR REVENUE, OR THE CLAIMS OF
 * THIRD PARTIES, WHETHER OR NOT SILICON GRAPHICS, INC.  HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH LOSS, HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE
 * POSSESSION, USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * US Government Users Restricted Rights 
 * Use, duplication, or disclosure by the Government is subject to
 * restrictions set forth in FAR 52.227.19(c)(2) or subparagraph
 * (c)(1)(ii) of the Rights in Technical Data and Computer Software
 * clause at DFARS 252.227-7013 and/or in similar or successor
 * clauses in the FAR or the DOD or NASA FAR Supplement.
 * Unpublished-- rights reserved under the copyright laws of the
 * United States.  Contractor/manufacturer is Silicon Graphics,
 * Inc., 2011 N.  Shoreline Blvd., Mountain View, CA 94039-7311.
 *
 * OpenGL(R) is a registered trademark of Silicon Graphics, Inc.
 */

/*  bezcurve.c			
 *  This program uses evaluators to draw a Bezier curve.
 */
#include <stdlib.h>
#include <glut.h>
#include <Math.h>

float t = 0;
float ptsX = 0;
float ptsY = 0;
float ptsZ = 0;
int alpha = 0;
int beta = 0;
int gamma = 0;
int activeRow = 1;

GLfloat p[3];

static GLfloat m[16];

GLfloat ctrlpoints[4][3] = {
	{ -1.0, -1.0, -1.0}, { 0.0, 0.0, 0.0}, 
	{0.0, 0.0, 0.0}, {1.0, 1.0, 1.0}};

void init(void)
{
   glClearColor(0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_FLAT);
   glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
   glEnable(GL_MAP1_VERTEX_3);
}

void display(void)
{
   int i;

   ctrlpoints[activeRow][0] = ptsX;
   ctrlpoints[activeRow][1] = ptsY;
   ctrlpoints[activeRow][2] = ptsZ;
	
   p[0] = pow((1-t),3) * ctrlpoints[0][0] + 3 * t * pow((1-t),2) * ctrlpoints[1][0] + 3 * (t-1) *pow((t),3) * ctrlpoints[2][0] + pow(t,3) * ctrlpoints[3][0];
   p[1] = pow((1-t),3) * ctrlpoints[0][1] + 3 * t * pow((1-t),2) * ctrlpoints[1][1] + 3 * (t-1) *pow((t),3) * ctrlpoints[2][1] + pow(t,3) * ctrlpoints[3][1];
   p[2] = pow((1-t),3) * ctrlpoints[0][2] + 3 * t * pow((1-t),2) * ctrlpoints[1][2] + 3 * (t-1) *pow((t),3) * ctrlpoints[2][2] + pow(t,3) * ctrlpoints[3][2];

	   //following code displays the line.
   glClear(GL_COLOR_BUFFER_BIT);
   glColor3f(1.0, 1.0, 1.0);
   glBegin(GL_LINE_STRIP);
      for (i = 0; i <= 30; i++) 
         glEvalCoord1f((GLfloat) i/30.0);
   glEnd();

   /* The following code displays the control points as dots. */
   glPointSize(5.0);
   glColor3f(1.0, 1.0, 0.0);
   glBegin(GL_POINTS);
      for (i = 0; i < 4; i++) 
         glVertex3fv(&ctrlpoints[i][0]);
   glVertex3fv(&p[0]);
   glEnd();

   //following code displays the wire cube.
   
	//glClear(GL_COLOR_BUFFER_BIT); 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef (alpha, 0.0, 1.0, 0.0);  //yaw
	glRotatef (beta, 1.0, 0.0, 0.0);  //pitch
	glRotatef (gamma, 0.0, 0.0, 1.0);  //roll
	glColor3f (1.0f, 1.0f, 1.0f);
    glutWireCube (2.0f);
   
	glutSwapBuffers();
	glGetFloatv(GL_MODELVIEW_MATRIX, m);
	glFlush();
}

void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   if (w <= h)
      glOrtho(-5.0, 5.0, -5.0*(GLfloat)h/(GLfloat)w, 
               5.0*(GLfloat)h/(GLfloat)w, -5.0, 5.0);
   else
      glOrtho(-5.0*(GLfloat)w/(GLfloat)h, 
               5.0*(GLfloat)w/(GLfloat)h, -5.0, 5.0, -5.0, 5.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void keyboard(unsigned char key, int x, int y)
{


	switch (key) {
		case '2':
			printf("case 2\n");
			activeRow = 1;
			ptsX = ctrlpoints[activeRow][0];
			ptsY = ctrlpoints[activeRow][1];
			ptsZ = ctrlpoints[activeRow][2];
			break;
		case '3':
			activeRow = 2;
			ptsX = ctrlpoints[activeRow][0];
			ptsY = ctrlpoints[activeRow][1];
			ptsZ = ctrlpoints[activeRow][2];
			printf("case 3");
			break;
		case 'x':
			if(ptsX < 1)
			{
				ptsX += .1;
				printf("case x++\n");
			}
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'X':
			if(ptsX > -1)
				ptsX -= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'y':
			if(ptsY < 1)
				ptsY+= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'Y':
			if(ptsY > -1)
				ptsY-= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'z':
			if(ptsZ < 1)
				ptsZ+= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'Z':
			if(ptsZ > -1)
				ptsZ-= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 't':
			if(t < 1)
				t+= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'T':
			if(t > 0.1)
				t -= .1;
			glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
			glutPostRedisplay();
			break;
		case 'a':
			alpha ++;
			glutPostRedisplay();
			break;
		case 'A':
			alpha --;
			glutPostRedisplay();
			break;
		case 'b':
			beta ++;
			glutPostRedisplay();
			break;
		case 'B':
			beta --;
			glutPostRedisplay();
			break;
		case 'g':
			gamma ++;
			glutPostRedisplay();
			break;
		case 'G':
			gamma --;
			glutPostRedisplay();
			break;
		case 27:
			exit(0);
			break;
   }
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (500, 500);
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutKeyboardFunc (keyboard);
   glutMainLoop();
   return 0;
}
