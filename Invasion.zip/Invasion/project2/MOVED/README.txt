Guys:
The game class is now inside the screens folder. If you recreate another one outside of the screens folder, the game won't run.
That being said, since I fixed it to do that, someone made another game class outside of the screens folder. That class is now located here.
I don't know what was edited in this class, so I stuck it here to make the game run.
-Paul