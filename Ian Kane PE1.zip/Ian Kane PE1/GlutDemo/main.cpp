#include <cstdio>
#include "Glut/include/glut.h"
#include <math.h>

using namespace std;


static float distance = -5. , gamma = 0, beta =0 , alpha = 0;
static GLfloat m[16];
static GLfloat mm[16];
//static GLfloat m[4][4];
bool R = false;
float alphatemp;
float betatemp;
float gammatemp;

#define SCREEN_WIDTH  1200.0f
#define SCREEN_HEIGHT 768.0f

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	glTranslatef(0., 0., distance);



	/* Adjust local coordinate system of cube position using modeling transformations */
	if(R)
	{
		glLoadMatrixf (mm);
	}
	else
	{
		glRotatef (alpha, 0.0, 1.0, 0.0);  //yaw
		glRotatef (beta, 1.0, 0.0, 0.0);  //pitch
		glRotatef (gamma, 0.0, 0.0, 1.0);  //roll
	}

	glColor3f (1.0f, 0.0f, 0.0f);
	glutWireCube (1.0);

	glColor3f (1.0f, 1.0f, 1.0f);
	glutWireTeapot (0.3f);

	glutSwapBuffers();
	
	glGetFloatv(GL_MODELVIEW_MATRIX, m);

	/*
	m[0]   m[4]   m[8]    m[12] 
	m[1]   m[5]   m[9]    m[13] 
	m[2]   m[6]   m[10]  m[14] 
	m[3]   m[7]   m[11]  m[15]
	*/

	printf("\n m[0] = %f  m[4] = %f m[8] = %f  m[12] %f \n m[1] = %f  m[5] = %f m[9] = %f  m[13] %f \n m[2] = %f  m[6] = %f m[10] = %f  m[14] %f \n m[3] = %f  m[7] = %f m[11] = %f  m[15] %f \n", m[0], m[4], m[8], m[12], m[1], m[5], m[9], m[13], m[2], m[6], m[10], m[14], m[3], m[7], m[11], m[15]);

	//    printf("\n m[0][0] = %f  m[1][0] = %f  m[2][0] = %f  m[3][0] %f \n m[0][1] = %f  m[1][1] = %f  m[2][1] = %f  m[3][1] %f \n m[0][2] = %f  m[1][2] = %f  m[2][2] = %f  m[3][2] %f \n m[0][3] = %f  m[1][3] = %f  m[2][3] = %f  m[3][3] %f \n", 
	//m[0][0], m[1][0], m[2][0], m[3][0], 
	//m[0][1], m[1][1], m[2][1], m[3][1], 
	//m[0][2], m[1][3], m[2][2], m[3][2], 
	//m[0][3], m[1][4], m[2][3], m[3][3]);


}

void resizeHandler (GLint width, GLint height) {
	float aspectRatio = (float)width / (float)height;

	/* Setup the view of the cube. */
	glMatrixMode(GL_PROJECTION);

	// Setup the camera's viewing frustum
	gluPerspective( /* field of view in degree */ 40.0,
		/* aspect ratio */ aspectRatio,
		/* Z near */ 1.0, /* Z far */ 1000.0);

	// Setup the camera's position and orientation
	gluLookAt (0.0f, 0.0f, 2.0f,		// The position of the eye/camera
		0.0f, 0.0f, 0.0f,		// The point we are looking at
		0.0f, 1.0f, 0.0f);		// The up vector, usually the y-axis
}

void init(void)
{
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();

	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();

	glClearColor (0.25f, 0.25f, 0.85f, 1.0f);

	glEnable (GL_DEPTH_TEST);
}

void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
	case 'd':
		distance = distance + 1;
		glutPostRedisplay();
		break;
	case 'D':
		distance = distance - 1;
		glutPostRedisplay();
		break;
	case 'g':
		gamma = gamma + 1;
		glutPostRedisplay();
		break;
	case 'G':
		gamma = gamma - 1;
		glutPostRedisplay();
		break; 
	case 'b':
		beta = beta + 1;
		glutPostRedisplay();
		break;
	case 'B':
		beta = beta - 1;
		glutPostRedisplay();
		break;
	case 'a':
		alpha = alpha + 1;
		glutPostRedisplay();
		break;
	case 'A':
		alpha = alpha - 1;
		glutPostRedisplay();
		break;
	case 'r':
		glGetFloatv(GL_MODELVIEW_MATRIX, mm);
		alpha = 0;
		beta = 0;
		gamma = 0;
		glutPostRedisplay();
		break;
	case 'R':
		if(!R)
			R = true;
		else
			R = false;
		break;
	case 'e':
		alphatemp = m[0] + m[5] + m[10]+1;
		alphatemp = sqrt(alphatemp/2);
		betatemp = m[4] / 2 * alphatemp;
		gammatemp = m[8]/ 2 * alphatemp;
		glRotatef (alphatemp, 0.0, 1.0, 0.0);  //yaw
		glRotatef (betatemp, 1.0, 0.0, 0.0);  //pitch
		glRotatef (gammatemp, 0.0, 0.0, 1.0);  //roll
		break;
	case 27:
		// ESCAPE Key
		exit (0);

	default:
		break;
	}
}	

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize (SCREEN_WIDTH, SCREEN_HEIGHT);
	glutCreateWindow("the unit cube as a wireframe");

	// Register Callbacks:
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(resizeHandler);

	init();

	// Start the main rendering loop:
	glutMainLoop();

	return 0;             /* ANSI C requires main to return int. */
}
