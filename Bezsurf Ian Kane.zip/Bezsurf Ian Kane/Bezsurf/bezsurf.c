/*  bezsurf.c
 *  This program renders a wireframe Bezier surface,
 *  using two-dimensional evaluators.
 */
#include <stdlib.h>
#include <glut.h>
#include <math.h>

#define PI  3.14159
#define SCREEN_WIDTH  1200.0f
#define SCREEN_HEIGHT 768.0f

static float distance = 10 , gamma = 0, beta =0 , alpha = 0 , x = 0, y = 0, z = 0,phi = 0, theta = 0;
static int row = 0 , col = 0;
GLdouble xG, yG, zG;

GLfloat ctrlpoints[4][4][3] = {
	
	
	 {{-1.5, -1.5, 4.0}, {-0.5, -1.5, 2.0},  {0.5, -1.5, -1.0}, {1.5, -1.5, 2.0}},  
	 {{-1.5, -0.5, 1.0}, {-0.5, -0.5, 3.0},  {0.5, -0.5, 0.0}, {1.5, -0.5, -1.0}}, 
     {{-1.5, 0.5, 4.0},  {-0.5, 0.5, 0.0},   {0.5, 0.5, 3.0},   {1.5, 0.5, 4.0}}, 
     {{-1.5, 1.5, -2.0}, {-0.5, 1.5, -2.0},  {0.5, 1.5, 0.0}, {1.5, 1.5, -1.0}}
	 /*
     {{-1.5, -1.5, 0.0}, {-0.5, -1.5, 0.0}, {0.5, -1.5, 0.0}, {1.5, -1.5, 0.0}}, 
     {{-1.5, -0.5, 0.0}, {-0.5, -0.5, 0.0},  {0.5, -0.5, 0.0}, {1.5, -0.5, 0.0}}, 
     {{-1.5, 0.5, 0.0}, {-0.5, 0.5, 0.0},  {0.5, 0.5, 0.0}, {1.5, 0.5, 0.0}}, 
     {{-1.5, 1.5, 0.0}, {-0.5, 1.5, 0.0},  {0.5, 1.5, 0.0}, {1.5, 1.5, 0.0}}
     */
};

void display(void)
{
   int i, j;
   
   /* these statements moved to rehape() 
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   */
   
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   //gluPerspective(40, SCREEN_WIDTH/SCREEN_HEIGHT, -16, 16.0);

    xG = distance * cos(phi/(180 * PI)) * sin(theta/180*PI);
    yG = distance * sin(phi/180 * PI);
    zG = distance * cos(phi/180 * PI) * cos(theta/180*PI);
	gluLookAt(xG,yG,zG,0,0,0,0,1,0);
	glEnd();
	
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
  
    // Evaluate the grid using lines
    
   for (j = 0; j <= 8; j++) {
   	
   	  glColor3f(1.0, 0.0, 0.0);  
      glBegin(GL_LINE_STRIP);
        for (i = 0; i <= 30; i++)
           glEvalCoord2f((GLfloat)i/30.0, (GLfloat)j/8.0);
      glEnd();
      
      glColor3f(0.0, 1.0, 1.0);
      glBegin(GL_LINE_STRIP);
        for (i = 0; i <= 30; i++)
          glEvalCoord2f((GLfloat)j/8.0, (GLfloat)i/30.0);
      glEnd();
      
   }
   glPointSize(3.0);
    glColor3f(1.0, 1.0, 0.0);
   
    glBegin(GL_POINTS);
	for (i = 0; i < 4; i++) 
	{
		for(j = 0; j < 4; j++)
		{
			glVertex3fv(&ctrlpoints[j][i][0]);
		}
	}
	glEnd();
   
   glColor3f(1.0, 1.0, 1.0);
   glutWireCube(8.0);
   // Evaluate using mesh
   
   
  // glEvalMesh2(GL_LINE,0,16,0,16);
   
  
   glFlush();
}

void init(void)
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
   
   glEnable(GL_MAP2_VERTEX_3);
   
   //un-comment the next line to use mesh
   glMapGrid2f(16, 0.0, 1.0, 16, 0.0, 1.0);
   
   glEnable(GL_DEPTH_TEST);
   glShadeModel(GL_FLAT);
  
}

void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(40, SCREEN_WIDTH/SCREEN_HEIGHT, -10, 10);
   /*
      if (w <= h)
		 glOrtho(-8.0*(GLfloat)w/(GLfloat)h, 
              8.0*(GLfloat)w/(GLfloat)h, -8.0, 8.0, -16.0, 16.0);
   else
	  glOrtho(-8.0*(GLfloat)w/(GLfloat)h, 
              8.0*(GLfloat)w/(GLfloat)h, -8.0, 8.0, -16.0, 16.0);*/
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void keyboard (unsigned char key, int x, int y)
{
	switch (key) {
		case 'd':
			distance = distance + 1;
			glutPostRedisplay();
			break;
		case 'D':
			distance = distance - 1;
			glutPostRedisplay();
			break;
			/*
		case 'g':
			gamma = gamma + 1;
	        glRotatef (1., 0.0, 0.0, 1.0);  //roll
			glutPostRedisplay();
			break;
		case 'G':
			gamma = gamma - 1;
			glRotatef (-1., 0.0, 0.0, 1.0);  //roll
			glutPostRedisplay();
			break; 
		case 'b':
			beta = beta + 1;
			glRotatef (1., 1.0, 0.0, 0.0);  //pitch
			glutPostRedisplay();
			break;
		case 'B':
			beta = beta - 1;
			glRotatef (-1., 1.0, 0.0, 0.0);  //pitch
			glutPostRedisplay();
			break;
		case 'a':
			alpha = alpha + 1;
			glRotatef (1., 0.0, 1.0, 0.0);  //yaw
			glutPostRedisplay();
			break;
		case 'A':
			alpha = alpha - 1;
			glRotatef (-1., 0.0, 1.0, 0.0);  //yaw
			glutPostRedisplay();
			break;*/
		case 'r':
			alpha = 0;
			beta = 0;
			gamma = 0;
			glLoadIdentity();
			glutPostRedisplay();
			break;
		case 'x':
			if(ctrlpoints[row][col][0] < 4)
			{
				ctrlpoints[row][col][0]++;
			}
			//ctrlpoints[row][col][0] = x;
			glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
			    0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'X':
			if(ctrlpoints[row][col][0] > -4)
			{
				ctrlpoints[row][col][0]--;
			}
			//ctrlpoints[row][col][0] = x;
			 glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'y':
			if(ctrlpoints[row][col][1] < 4)
				ctrlpoints[row][col][1]++;
			 glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'Y':
			if(ctrlpoints[row][col][1] > -4)
				ctrlpoints[row][col][1]--;
			 glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'z':
			if(ctrlpoints[row][col][2] < 4)
				ctrlpoints[row][col][2]++;
			 glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'Z':
			if(ctrlpoints[row][col][2] > -4)
				ctrlpoints[row][col][2]--;
			 glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
           0, 1, 12, 4, &ctrlpoints[0][0][0]);
			glutPostRedisplay();
			break;
		case 'j':
			if(col < 4)
				col++;
			break;
		case 'J':
			if(col > 0)
				col--;
			break;
		case 'i':
			if(row < 4)
				row++;
			break;
		case 'I':
			if(row > 0)
				row--;
			break;
		case 't':
			theta++;
			glutPostRedisplay();
			break;
		case 'T':
			theta--;
			glutPostRedisplay();
			break;
		case 'p':
			if(phi < 90)
				phi++;
			glutPostRedisplay();
			break;
		case 'P':
			if(phi > -90)
				phi++;
			glutPostRedisplay();
			break;

		default:
			break;
	}
}	


int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (500, 500);
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0;
}

