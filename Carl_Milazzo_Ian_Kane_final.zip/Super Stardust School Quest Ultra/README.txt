﻿
  ___                         ___  _                  _            _    
 / __| _  _  _ __  ___  _ _  / __|| |_  __ _  _ _  __| | _  _  ___| |_ 
 \__ \| || || '_ \/ -_)| '_| \__ \|  _|/ _` || '_|/ _` || || |(_-<|  _|
 |___/ \_,_|| .__/\___||_|   |___/ \__|\__,_||_|  \__,_| \_,_|/__/ \__| 
            |_|                                                          
  ___      _               _    ___                  _     _   _  _  _  
 / __| __ | |_   ___  ___ | |  / _ \  _  _  ___  ___| |_  | | | || || |_  _ _  __ _  
 \__ \/ _|| ' \ / _ \/ _ \| | | (_) || || |/ -_)(_-<|  _| | |_| || ||  _|| '_|/ _` |
 |___/\__||_||_|\___/\___/|_|  \__\_\ \_,_|\___|/__/ \__|  \___/ |_| \__||_|  \__,_|
 
 
Introduction:

This is the Super Stardust School Quest Ultra Game of awesomeness! If you're playing this, you must
understand this is supposed to be played on a new, fancy windows machine! This super awesome game uses the
console built into every Windows PC. This super awesome game takes place in a boring school. A boring school
taken over by an evil wizard ruler! Ruler as in the measuring stick, not like some man with a crown. This 
evil ruler has the power to make other inanimate objects follow his evil rule! Only you can save the wor- er school!

How to Play:

After beating the first level (The title screen), you're sent into the world map! You use the 

   ___			      ____
   |W|	  	==	      |Up|
   ---	  	==	      ----
_________ 	==	_________________
|A||S||D| 	==	|Left|Down|Right|
--------- 	==	-----------------

Keys in order to move

Move into objects to interact with them.

@ is the player! This is the thing you move!
τ is a Key.
║,╬,╩,╣,╠,╚,╔,╝,╗,╦,═ are all walls.
E is is an enemy!

interacting with an item adds it to your inventory
interacting with an enemy makes you fight it!

Combat:

You will be given different options.
Choose one of the options to defeat the monster.
Be warned! if you choose the wrong one then you will lose some of your intelegence.
If your intelegence gets too low, that is bad. Don't do that.
If you win in a smart way, you will get intelegence.
Having a lot of intelegence is good, because the higher it is the more options you have of beating the game.

How to win:

Beat the Ruler, simple as that. 

BONUS:
We Read in the XML File containing the map, the player info, and other information.
The XML Loads in the Map, Enemies, and the player stats, which is different for each.
The map we lead in line by line, and we parse the different characters and make them in our Map object.
The enemies load in a wealth of things, including:
Battle Options: These are the selectable options for when you get into a fight, and every one of them defeat the monster.
Rew: the reward for beating the monster. Depending on your selection, you get rewarded or penalized a certain amount of intelegence.
rec: The intelegence requirement in order to take said action. This means if your intelegence is too low, you can't select it.
The player loads in the current position of the player, along with the inventory he has.

We also included serializing, which changes our characters from our XML into display characters, so that we have a pretty display for you.

When you run into the wall the game will beep, because it's adding insult to injury.

BONUS YOU DIDN'T THINK OF:
We used GetAsyncKeyState in order to take in player input, which lets us inturpret the input the player gives us in real time, without having to press enter every time.
We tried to save the game, however we ran into some errors check "mapSave.xml".

Links that we used:
http://cboard.cprogramming.com/windows-programming/85762-macros-functions.html
