//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "Definitions.h"
#include "Character.h"
#include "Enemy.h"

class BattleObject
{
public:
	//Big 4
	BattleObject(void);
	BattleObject(const BattleObject&);
	~BattleObject(void);
	void operator=(const BattleObject&);

	//getters
	Character* getChar();
	Enemy* getEnemy();

	//setters
	void setChar(Character* c);
	void setEnemy(Enemy* e);

	//functions
	void display();
	bool input();

private:
	Character* player;
	Enemy* fighter;

};

