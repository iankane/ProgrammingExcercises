//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "Definitions.h"
#include "GameObject.h"

struct BattleInfo
{
	char pic;
	char serial;
	string name;
	string battleText;
	string* battleOptions;
	int* intelectRequirements;
	int* intelectRewards;
};

enum type { E1,E2,E3,E4,E5 };

class Enemy : public GameObject
{
public:
	Enemy(void);
	Enemy(const Enemy&);
	Enemy(int x, int y, string bT, int* iR, string* bO, int* iRew);
	~Enemy(void);
	void operator= (const Enemy&);
	
	void setMe(type t);
	type getMe() const;
	
	void setBattle(BattleInfo b);
	void setBattle(string bT, int* iR, string* bO, int* iRew);

	BattleInfo getBattle();

private:
	BattleInfo battle;
	type me;
};

static BattleInfo a;
static BattleInfo b;
static BattleInfo c;
static BattleInfo d;
static BattleInfo e;

