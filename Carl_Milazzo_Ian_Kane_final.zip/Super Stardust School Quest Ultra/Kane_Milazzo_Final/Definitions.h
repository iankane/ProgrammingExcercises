//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include <iostream>
#include <string>
#include <algorithm>

#define DEBUGER
#define mapfile "map.xml"

using namespace std;