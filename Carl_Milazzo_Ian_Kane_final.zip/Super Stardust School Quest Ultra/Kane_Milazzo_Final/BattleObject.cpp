//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#include "BattleObject.h"


BattleObject::BattleObject(void)
{
	player = new Character();
	fighter = new Enemy();
}

BattleObject::BattleObject(const BattleObject& bo)
{
	*this = bo;
}


BattleObject::~BattleObject(void)
{
	delete fighter;
	delete player;
}

void BattleObject::operator=(const BattleObject& bo)
{
	*this = bo;
}

Character* BattleObject::getChar()
{
	return player;
}


Enemy* BattleObject::getEnemy()
{
	return fighter;
}

void BattleObject::setChar(Character* c)
{
	player = c;
}

void BattleObject::setEnemy(Enemy* e)
{
	fighter = e;
}

void BattleObject::display()
{
	/*cout << getEnemy()->getBattle().battleText << endl;
	for(int i = 1; i <= getEnemy()->getBattle().battleText.length(); i++)
	{
		cout << i << ": "<<getEnemy()->getBattle().battleOptions[i];
		cout << "     Player needs "<< getEnemy()->getBattle().intelectRequirements << "Intelegence." << endl;
	}*/
	BattleInfo battle;
	switch(getEnemy()->getMe())
	{
		case 1:
			battle = a;
		case 2:
			battle = b;
		case 3:
			battle = c;
		case 4:
			battle = d;
		case 5:
			battle = e;
	}
	
	for(int i = 1; i <= battle.battleText.length(); i++)
	{
		cout << i << ": "<<battle.battleOptions[i];
		cout << "     Player needs "<< battle.intelectRequirements << "Intelegence." << endl;
	}
	cout << endl << endl;
}

bool BattleObject::input()
{
	int input; 
	cout << "Enter the option you want here: ";
	cin >> input;
	cout << endl;
	if(input > 0 || input <getEnemy()->getBattle().battleText.length())
	{
		getChar()->setInt(getChar()->getInt() + getEnemy()->getBattle().intelectRewards[input]);
		cout << "You now have " << getChar()->getInt() << " intelegence!";
		return true;
	}
	else
	{
		cout << "Incorrect input, try again" << endl;
		return false;
	}
}