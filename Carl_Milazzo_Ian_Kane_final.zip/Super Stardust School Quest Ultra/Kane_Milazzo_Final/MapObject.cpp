//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "MapObject.h"


MapObject::MapObject(void)
{
	//use xml to load map height and width
	height = 90;
	width = 90;
	cameraX = 0;
	cameraY = 0;

	//use xml to load in map
	TiXmlDocument doc(mapfile);
	TiXmlHandle hDoc(&doc);
	TiXmlElement* pElem;
	TiXmlHandle hRoot(0);
	
	if (doc.LoadFile())
	{
		#ifdef DEBUGER
		for(int z = 0;z<getCamHeight()+5;z++)
			printf("\n");
		printf("\n%s:\n", mapfile);
		#endif DEBUGER

		pElem = hDoc.FirstChildElement().Element();
		//should always have a valid root
		if(pElem)
		{
			//hRoot = TiXmlHandle(pElem);
			if(startParsing(pElem))
			{
				#ifdef DEBUGER
				cout << "map loaded properly!" <<endl;
				#endif DEBUGER
			}
			else
				system("pause");
		}
		else
		{
			cout<<"no root element found.  Check that file name is ''"<< mapfile <<"'' and has a root elemnt"<<endl;
			system("pause");
			return;
		}
	}
	else
	{
		printf("Failed to load file \"%s\"\n", "map.xml");
		system("pause");
	}

	initLib();
	findMakeEnemies();
	this->saveGame();
}

MapObject::MapObject(const MapObject& obj)
{
	//height = obj.getHeight();
	//width = obj.getWidth();
	//cameraX = obj.getCameraX();
	//cameraY = obj.getCameraY();
	//shallow copy
	*this = obj;
}

// deconstructor
MapObject::~MapObject(void)
{
	//destroy map
	for(int i = 0; i < getWidth(); i++)
		delete [] rawMap[i];
	delete rawMap;
	delete player;
	#ifdef DEBUGER
	cout << "map deleted"<<endl;
	#endif DEBUGER
}

void MapObject::operator= (const MapObject& obj)
{
	height = obj.getHeight();
	width = obj.getWidth();
	cameraX = obj.getCameraX();
	cameraY = obj.getCameraY();
	newMap();
}

void MapObject::setCameraX(int x)
{
	if(x<0)
		cameraX = 0;
	else if(x>getWidth()-getCamWidth())
		cameraX = getWidth()-getCamWidth();
	else
		cameraX = x;
}
void MapObject::setCameraY(int y)
{
	if(y<0)
		cameraY = 0;
	else if(y>getHeight()-getCamHeight())
		cameraY = getHeight()-getCamHeight();
	else
		cameraY = y;
}


//overloads
char* MapObject::operator[](int index)
{
	return rawMap[index];
}

//functions
void MapObject::newMap()
{
	rawMap = new char*[height];
	for(int i = 0; i < height; i++)
	{
		rawMap[i] = new char[width];
	}

	for(int i = 0; i < height; i++)
	{
		//using algorithm fill
		fill(rawMap[i],rawMap[i]+width,0);
	}
}

void MapObject::update()
{
	//allow player to move/ handle colisions
	movePlayer();

	//move the camera to the player
	moveCamera();

	//display map
	cout<<*this;
}

void MapObject::moveCamera()
{
	setCameraX(player->getPos()[0]-(getCamWidth()/2));
	setCameraY(player->getPos()[1]-(getCamHeight()/2));
	#ifdef DEBUGER
	cout<<"           Camera - X: "<<getCameraX();
	cout<<"Y: "<<getCameraY()<<endl;
	#endif DEBUGER
}

bool MapObject::startParsing(TiXmlElement* pRoot)
{
	TiXmlElement* pElem = pRoot;
	//TiXmlAttribute* pAttrib=pElem->FirstChild();
	pElem = pElem->FirstChildElement();
	
	//load in map stats (height & width)
	TiXmlAttribute* pAttrib = pElem->FirstAttribute();
	if(!pAttrib->QueryIntValue(&height)==TIXML_SUCCESS)
		return false;
	pAttrib = pElem->LastAttribute();
	if(!pAttrib->QueryIntValue(&width)==TIXML_SUCCESS)
		return false;

#ifdef DEBUGER
	printf("%s: width=%s height=%s",pElem->Value(),pElem->Attribute("width"),pElem->Attribute("height"));
	printf( "\n" );
#endif DEBUGER
	pElem=pElem->NextSiblingElement();
	
	//create new map
	newMap();

	//parse map
	if (!parseMap(pElem))
	{
		return false;
	}

	//read in character info
	if(!parsePlayer(pRoot))
	{
		return false;
	}

	//read in different enemies
	if(!parseEnemies(pRoot))
	{
		return false;
	}

	return true;
}

bool MapObject::parseMap(TiXmlElement* pElem)
{
	for(int y = 0; y<height; y++)
	{
		#ifdef DEBUGER
		printf( "%s: value=[%s]", pElem->Value(), pElem->Attribute("line"));
		printf( "\n" );
		#endif DEBUGER
		
		for(int x = 0; x<width; x++)
		{
			try
			{
				rawMap[y][x] = pElem->Attribute("line")[x];
				if(rawMap[y][x] == 0 || !rawMap[y][x])
				{
					throw 0;
				}
			}
			catch(int)
			{
				cout<<"Error reading file check line: "<<y+1<<" col: "<<x+1<<endl;
				return false;
			}
		}
		try
		{
			pElem=pElem->NextSiblingElement();
			if(!pElem && y+1<height)
			{
				throw 0;
			}
		}
		catch(int)
		{
			cout<<"Error reading file check line: "<<y+2<<endl;
			return false;
		}
	}

	return true;
}

bool MapObject::parsePlayer(TiXmlElement* pElem)
{
	pElem = pElem->FirstChildElement("character");	
	
	// intelect
	#ifdef DEBUGER
		printf( "%s: intel=[%s]", pElem->Value(), pElem->Attribute("intel"));
		printf( "\n" );
	#endif DEBUGER

	int intel;
	TiXmlAttribute* pAttrib = pElem->FirstAttribute();
	if(!pAttrib->QueryIntValue(&intel)==TIXML_SUCCESS)
		return false;

	// position
	pElem = pElem->FirstChildElement("pos");

	#ifdef DEBUGER
		printf( "\t%s: x=[%s] y=[%s]", pElem->Value(), pElem->Attribute("x"), pElem->Attribute("y"));
		printf( "\n" );
	#endif DEBUGER

	int x;
	int y;
	pAttrib = pElem->FirstAttribute();
	if(!pAttrib->QueryIntValue(&x)==TIXML_SUCCESS)
		return false;
	pAttrib = pElem->LastAttribute();
	if(!pAttrib->QueryIntValue(&y)==TIXML_SUCCESS)
		return false;

	player = new Character(x,y,intel);

	return true;
}

bool MapObject::parseEnemies(TiXmlElement* pElem)
{
	pElem = pElem->FirstChildElement("enemies");
	pElem = pElem->FirstChildElement();
	for(int i = 0; i<5;i++)
	{
		#ifdef DEBUGER
			printf( "\n%s: name=[%s] saved=[%s] printed=[%s]", pElem->Value(), pElem->Attribute("name"),pElem->Attribute("char"),pElem->Attribute("char2"));
			printf( "\nIntro :%s:\n\t options= '%s'\n\t\t'%s'\n\t\t'%s''\n\t\t'%s'",pElem->Attribute("intro"),pElem->Attribute("option1"),pElem->Attribute("option2"),pElem->Attribute("option3"),pElem->Attribute("option4"));
			printf( "\nreq intelligence: %s, %s, %s, %s",pElem->Attribute("req1"),pElem->Attribute("req2"),pElem->Attribute("req3"),pElem->Attribute("req4"));
			printf( "\nreward intelligence: %s, %s, %s, %s",pElem->Attribute("rew1"),pElem->Attribute("rew2"),pElem->Attribute("rew3"),pElem->Attribute("rew4"));
			printf( "\n" );
		#endif DEBUGER
		
		BattleInfo battle;

		battle.pic = (char)getInt(pElem->Attribute("char2"));
		battle.serial = (char)pElem->Attribute("char");
		battle.name = pElem->Attribute("name");

		battle.battleText = pElem->Attribute("intro");
		battle.battleOptions = new string[4];
		battle.battleOptions[0] = pElem->Attribute("option1");
		battle.battleOptions[1] = pElem->Attribute("option2");
		battle.battleOptions[2] = pElem->Attribute("option3");
		battle.battleOptions[3] = pElem->Attribute("option4");

		battle.intelectRequirements = new int[4];
		battle.intelectRequirements[0] = getInt(pElem->Attribute("req1"));
		battle.intelectRequirements[1] = getInt(pElem->Attribute("req2"));
		battle.intelectRequirements[2] = getInt(pElem->Attribute("req3"));
		battle.intelectRequirements[3] = getInt(pElem->Attribute("req4"));

		battle.intelectRewards = new int[4];
		battle.intelectRewards[0] = getInt(pElem->Attribute("rew1"));
		battle.intelectRewards[1] = getInt(pElem->Attribute("rew2"));
		battle.intelectRewards[2] = getInt(pElem->Attribute("rew3"));
		battle.intelectRewards[3] = getInt(pElem->Attribute("rew4"));

		// set the static battles
		if(i == 0)
			a = battle;
		else if(i == 1)
			b = battle;
		else if(i == 2)
			c = battle;
		else if(i == 3)
			d = battle;
		else
			e = battle;

		pElem = pElem->NextSiblingElement();
	}

	return true;
}

void MapObject::movePlayer()
{
	char input = player->keyInput();
	int x = 0;
	int y = 0;
	switch (input)
	{
	case 'W':
		x = player->getPos()[0];
		y = player->getPos()[1]-1;
		checkAndMove(rawMap[y][x],x,y);
		break;
	case 'A':
		x = player->getPos()[0]-1;
		y = player->getPos()[1];
		checkAndMove(rawMap[y][x],x,y);
		break;
	case 'S':
		x = player->getPos()[0];
		y = player->getPos()[1]+1;
		checkAndMove(rawMap[y][x],x,y);
		break;
	case 'D':
		x = player->getPos()[0]+1;
		y = player->getPos()[1];
		checkAndMove(rawMap[y][x],x,y);
		break;
	default:
		#ifdef DEBUGER
			cout<<"no move";
		#endif DEBUGER
		break;
	}

}

void MapObject::checkAndMove(char c, int x, int y)
{
	switch(c)
	{
		case 'w':
		case 'W':
		case '{':
		case '}':
		case '7':
		case 'J':
		case 'L':
		case 'F':
		case '8':
		case 'T':
		case 'I':
			Beep(750,50);
			return;
		case 'D':
			//check for key
			if(!false)
			{
				return;
			}
		// else allow move
	}
	//move
	rawMap[y][x] = '@';
	rawMap[player->getPos()[1]][player->getPos()[0]] = '-';
	player->setPos(x,y);

	return;
}

void MapObject::initLib(void)
{
	//player
	library.insert(pair<char,char>('-',' '));
	library.insert(pair<char,char>('W',char(186)));
	library.insert(pair<char,char>('w',char(205)));
	library.insert(pair<char,char>('#','+'));
	library.insert(pair<char,char>('T',char(203)));
	library.insert(pair<char,char>('7',char(187)));
	library.insert(pair<char,char>('J',char(188)));
	library.insert(pair<char,char>('F',char(201)));
	library.insert(pair<char,char>('L',char(200)));
	library.insert(pair<char,char>('}',char(204)));
	library.insert(pair<char,char>('{',char(185)));
	library.insert(pair<char,char>('8',char(206)));
	library.insert(pair<char,char>('D','_'));
	library.insert(pair<char,char>('K',char(231)));
	library.insert(pair<char,char>('E','E'));
	library.insert(pair<char,char>('@',char(1)));
	library.insert(pair<char,char>('I',char(202)));
	
}

void MapObject::findMakeEnemies()
{
	int count = 0;
	for(int y = 0; y < getHeight(); y++)
	{
		for(int x=0; x < getWidth(); x++)
		{
			if(rawMap[y][x]=='E')
			{
				count++;
			}
		}
	}
	enemies = new Enemy*[count];
	count = 0;
	srand(time(NULL));
	for(int y = 0; y < getHeight(); y++)
	{
		for(int x=0; x < getWidth(); x++)
		{
			if(rawMap[y][x]=='E')
			{
				enemies[count] = new Enemy();
				int i = rand()%5;
				type t;
				switch (i)
				{
					case 0:
						t = E1;
						break;
					case 1:
						t = E2;
						break;
					case 2:
						t = E3;
						break;
					case 3:
						t = E4;
						break;
					case 4:
						t = E5;
						break;
				}
				enemies[count]->setMe(t);
				count++;
			}
		}
	}
}

ostream& operator<<(ostream& ss,const MapObject& maps)
{
	return maps.printer(ss,maps);
}

ostream& MapObject::printer(ostream& ss, const MapObject& maps) const
{
	MapObject::gotoxy(0,0);
	char print = '*';
	//for_each(maps,maps+maps.getCamHeight(),printer1);
		//for_each(maps[],maps[].getCamWidth(),printer2);
	ss<<"#";
	for(int k = 0; k-4 < maps.getCamWidth();k++)
		ss<<"=";
	ss<<"#"<<endl;
	ss<<"||";
	for(int k = 0; k-2 < maps.getCamWidth();k++)
		ss<<" ";
	ss<<"||"<<endl;
	for(int i = 0; i < maps.getCamHeight(); i++)
	{
		ss<<"|| ";
		for(int j=0; j < maps.getCamWidth(); j++)
		{
			//use the char to correspond to a map specific char or item
			print = getMapChar(maps.rawMap[i+maps.getCameraY()][j+maps.getCameraX()]);
			ss << print;
		}
		ss<<" ||"<<endl;
	}
	ss<<"||";
	for(int k = 0; k-2 < maps.getCamWidth();k++)
		ss<<" ";
	ss<<"||";
	ss<<endl<<"#";
	for(int k = 0; k-4 < maps.getCamWidth();k++)
		ss<<"=";
	ss<<"#"<<endl;
	return ss;
}


char MapObject::getMapChar(char c) const
{
	return library.find(c)->second;
}

void MapObject::saveGame()
{
	//to save an xml file
	// Make xml: <?xml ..><Hello>World</Hello>
	TiXmlDocument doc;
	TiXmlDeclaration * decl = new TiXmlDeclaration( "1.0", "", "" );
	TiXmlElement * mapSave = new TiXmlElement( "map" );
	TiXmlElement * size = new TiXmlElement("size");
	TiXmlAttribute * height = new TiXmlAttribute("height","30");
	
	size->SetAttribute("height",this->getHeight());
	size->SetAttribute("width",this->getWidth());
	mapSave->LinkEndChild( size );

	for(int i=0;i <= getHeight()-1;i++)
	{
		string s = "";
		for(int j=0;j <= getWidth()-1;j++)
		{
			s.append(&rawMap[i][j]);
		}
		TiXmlElement * line = new TiXmlElement("line"+i);
		line->SetAttribute("line",s.c_str());
		mapSave->LinkEndChild(line);
	}
	
	doc.LinkEndChild( decl );
	doc.LinkEndChild( mapSave );
	doc.SaveFile( "mapSave.xml" );
}

//recieved from http://www.cplusplus.com/forum/general/41709/
//via "Duoas"
#ifdef _WIN32

void MapObject::gotoxy( int x, int y )
{
	COORD p = { x, y };
	SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), p );
}

#else

  #include <unistd.h>
  #include <term.h>

  void MapObject::gotoxy( int x, int y )
    {
    int err;
    if (!cur_term)
      if (setupterm( NULL, STDOUT_FILENO, &err ) == ERR)
        return;
    putp( tparm( tigetstr( "cup" ), y, x, 0, 0, 0, 0, 0, 0, 0 ) );
    }

#endif 

int MapObject::getInt(string s)
{
	istringstream myStream(s);
	int num;
	if (myStream >> num)
	{
		num = atoi(s.c_str());
	}
	return num;
}