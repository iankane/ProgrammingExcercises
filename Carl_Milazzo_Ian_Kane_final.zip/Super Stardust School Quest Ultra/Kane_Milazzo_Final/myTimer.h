//recieved from http://www.cplusplus.com/forum/beginner/317/
// via "alex79roma"
//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include <iostream>
#include <conio.h>
#include <time.h>	// class needs this inclusion

class myTimer {
	public:
		myTimer();
		void           start();
		void           stop();
		void           reset();
		bool           isRunning();
		float		   getTime();
		bool           isOver(unsigned long seconds);
	private:
		bool           resetted;
		bool           running;
		unsigned long  beg;
		unsigned long  end;
};