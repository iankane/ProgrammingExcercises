//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include <cmath>
#include <map>
#include <windows.h>
#include <sstream>
#include "Character.h"
#include "Enemy.h"
#include "tinyxml.h"
#include "Definitions.h"

#define CAMHEIGHT  20;
#define CAMWIDTH  60;


class MapObject
{
private:
	map<char, char> library;
	map<char,char>::iterator it;
	pair<map<char,char>::iterator, bool> ret;
	// top left corner of view
	int cameraX;
	int cameraY;
	// a constant width and height for camera
	//int const camWidth;
	//int const camHeight;
	// height and width values for the map
	int width;
	int height;
	// array of all objects and walls
	char** rawMap;

	Enemy** enemies;
	Character* player;

public:
	MapObject(void);
	MapObject(const MapObject&);
	~MapObject(void);
	void operator= (const MapObject&);

	// attributes
	int getCameraX() const { return cameraX; }
	int getCameraY() const { return cameraY; }
	int getWidth() const { return width; }
	int getHeight() const { return height; }
	int getCamWidth() const { return CAMWIDTH; }
	int getCamHeight() const { return CAMHEIGHT; }
	void setCameraX(int x);
	void setCameraY(int y);

	//used to get the map array
	char* operator[](int index);

	// functions
	// creates a clean map
	void newMap();
	void update(void);
	void moveCamera(void);
	bool startParsing(TiXmlElement* pElem);
	bool parseMap(TiXmlElement* pElem);
	bool parsePlayer(TiXmlElement* pElem);
	bool parseEnemies(TiXmlElement* pElem);
	void movePlayer();
	void checkAndMove(char c, int x, int y);
	void initLib(void);
	void findMakeEnemies();

	//overloads
	// ToString() overload
	friend ostream& operator<<(ostream& ss, const MapObject& maps);
	virtual ostream& printer(ostream& ss, const MapObject& maps) const;

	char getMapChar(char c) const;
	void MapObject::saveGame();
	static void gotoxy( int x, int y );
	int getInt(string s);
};