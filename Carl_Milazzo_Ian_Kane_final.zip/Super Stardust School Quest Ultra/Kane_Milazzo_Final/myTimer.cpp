//recieved from http://www.cplusplus.com/forum/beginner/317/
// via "alex79roma"
//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze


#include "myTimer.h"

myTimer::myTimer() {
	resetted = true;
	running = false;
	beg = 0;
	end = 0;
}

void myTimer::start() {
	if(! running) {
		if(resetted)
			beg = (unsigned long) clock();
		else
			beg -= end - (unsigned long) clock();
		running = true;
		resetted = false;
	}
}


void myTimer::stop() {
	if(running) {
		end = (unsigned long) clock();
		running = false;
	}
}


void myTimer::reset() {
	bool wereRunning = running;
	if(wereRunning)
		stop();
	resetted = true;
	beg = 0;
	end = 0;
	if(wereRunning)
		start();
}


bool myTimer::isRunning() {
	return running;
}


float myTimer::getTime() {
	if(running)
		//moded for decimals (via) float
		return (((float) clock() - beg) / CLOCKS_PER_SEC);
	else
		return end - beg;
}


bool myTimer::isOver(unsigned long seconds) {
	return seconds >= getTime();
}
