//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#include "Enemy.h"


Enemy::Enemy(void)
{
	setPos(2,2);
	setdisplay('E');
}

Enemy::Enemy(const Enemy& e)
{
	me = e.getMe();
}

Enemy::Enemy(int x, int y, string bT, int*iR, string* bO, int*iRew)
{
	setPos(x,y);
	battle.battleOptions = bO;
	battle.battleText = bT;
	battle.intelectRequirements=iR;
	battle.intelectRewards = iRew;
}

Enemy::~Enemy(void)
{
	#ifdef DEBUGER
		cout << "Enemy Destroyed!" << endl;
	#endif DEBUGER
}

void Enemy::operator= (const Enemy& e)
{
	me = e.getMe();
}

void Enemy::setMe(type t) { me = t; }
type Enemy::getMe() const { return me; }

void Enemy::setBattle(BattleInfo b)
{
	battle = b;
}

void Enemy::setBattle(string bT, int* iR, string* bO, int* iRew)
{
	battle.battleOptions = bO;
	battle.battleText = bT;
	battle.intelectRequirements = iR;
	battle.intelectRewards = iRew;
}

BattleInfo Enemy::getBattle()
{
	switch(getMe())
	{
		case E1:
			return a;
			break;
		case E2:
			return b;
			break;
		case E3:
			return c;
			break;
		case E4:
			return d;
			break;
		case E5:
			return e;
			break;
	}
	return battle;
}