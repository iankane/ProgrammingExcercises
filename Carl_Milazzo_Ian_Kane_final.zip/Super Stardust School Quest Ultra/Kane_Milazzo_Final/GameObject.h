//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once

//BUTTON STUFF
#include <Windows.h>
#include <WinUser.h>
#include <time.h>
#include <stdio.h>
#include <conio.h>

//STL STUFF
#include <vector>
#include <queue>

//using namespace stl;
//define's and reused includes
#include "Definitions.h"

#define KEYDOWN(vkCode) ((GetAsyncKeyState(vkCode) & 0x8000) ? 1 : 0)
#define KEYUP(vkCode) ((GetAsyncKeyState(vkCode) & 0x8000) ? 0 : 1)

//This object holds values for all game objects, and has a collision method
class GameObject
{
public:
	GameObject(void);
	GameObject(const GameObject&);
	GameObject(int x, int y, char display);
	~GameObject(void);
	void operator= (const GameObject&);

	//getters
	vector<int> getPos() const;
	char getdisplay() const;

	//setters
	virtual void setPos( int x,int y);
	void setdisplay(char d);
	//move function
	virtual bool move(char mover, char movee);

private:
	
	vector<int> pos;		//position in the array
	queue<string> inventory;
	char display;			//character to display in the array

};

