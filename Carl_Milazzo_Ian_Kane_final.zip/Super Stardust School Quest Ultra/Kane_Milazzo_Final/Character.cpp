//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "Character.h"


Character::Character(void) :  GameObject()
{
	setdisplay((char)1);
	t = new myTimer();
	t->start();
}

Character::Character(const Character& c) : GameObject(c)
{
	/*setPos(c.getPos()[0], c.getPos()[1]);
	setdisplay(c.getdisplay());*/
}

Character::Character(int x, int y, int intel)
{
	setPos(x,y);
	intelect = intel;
	setdisplay((char)1);
	t = new myTimer();
	t->start();
}

Character::~Character(void) 
{
	#ifdef DEBUGER
	cout << "Character Deleted" << endl;
	#endif DEBUGER
}

void Character::operator=(const Character& c)
{
	setPos(c.getPos()[0], c.getPos()[1]);
	setdisplay(c.getdisplay());
}

int Character::getInt()
{
	return intelect;
}

void Character::setInt(int i)
{
	intelect = i;
}

//Ian Kane
char Character::keyInput()
{
	//http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
	//VKey codes
	#ifdef DEBUGER
	printf("Timer: %3.2f ",t->getTime());
	#endif DEBUGER
	if(t->getTime()>.15)
	{
		lastkey = 0;
	}

	//W key pressed
	if(KEYDOWN(0x57))
	{
		if(lastkey!=1)
		{
			//set lastkey press to 1
			lastkey=1;
			//move up
			//the object above the current object.
			//temp = map[this.getPos()[0], this.getPos()[1] - 1].object;
			//
			t->reset();
			#ifdef DEBUGER
			cout << "W PRESSED" << endl;
			#endif DEBUGER
			return 'W';
		}
	}
	//A key pressed
	else if(KEYDOWN(0x41))
	{
		if(lastkey!=2)
		{
			//set lastkey press to 2
			lastkey=2;
			t->reset();
			//move LEFT
			//the object left of the current object.
			//temp = map[this.getPos()[0] - 1, this.getPos()[1]].object;
			#ifdef DEBUGER
			cout << "A PRESSED" << endl;
			#endif DEBUGER
			return 'A';
		}
	}
	//S key pressed
	else if(KEYDOWN(0x53))
	{
		if(lastkey!=3)
		{
			//set lastkey press to 3
			lastkey=3;
			t->reset();
			//move DOWN
			//the object above the current object.
			//temp = map[this.getPos()[0], this.getPos()[1] + 1].object;
			#ifdef DEBUGER
			cout << "S PRESSED" << endl;
			#endif DEBUGER
			return 'S';
		}
	}
	//D key pressed
	else if(KEYDOWN(0x44))
	{
		if(lastkey!=4)
		{
			//set lastkey press to 4
			lastkey=4;
			t->reset();
			//move RIGHT
			//the object above the current object.
			//temp = map[this.getPos()[0] + 1, this.getPos()[1]].object;
			#ifdef DEBUGER
			cout << "D PRESSED" << endl;
			#endif DEBUGER
			return 'D';
		}
	}
	if(KEYDOWN(VK_ESCAPE))
	{
		#ifdef DEBUGER
		cout << "Esc PRESSED" << endl;
		#endif DEBUGER
		system("pause");
	}
	return NULL;
}