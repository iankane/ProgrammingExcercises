//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "MapObject.h"
#include "tinyxml.h"
#include "Character.h"
#include "Definitions.h"

enum gameState {MAP, BATTLE, STATS, PAUSE, TITLE};

int main()
{
	//Starting the game
	MapObject* mapObj = new MapObject();
	//Character * player = new Character();
	bool playing = true;

	mapObj->update();
	//cout << *mapObj;

	//GAME LOOP
	
	while(playing)
	{
		//player->keyInput();
		mapObj->update();
	}
	
	//destruction
	delete mapObj;
	//delete player;

	system("pause");
}