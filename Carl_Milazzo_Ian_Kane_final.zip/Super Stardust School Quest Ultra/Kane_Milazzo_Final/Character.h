//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "GameObject.h"
#include "myTimer.h"
#include <time.h>

using namespace std;

class Character : public GameObject
{
public:
	Character(void);
	Character(const Character&);
	Character(int x, int y, int intel);
	~Character(void);
	void operator= (const Character&);
	int getInt();
	void setInt(int i);
	char keyInput();
	//bool move(char mover, char movee);

private:
	int intelect;
	int lastkey;
	myTimer* t;
};

