//Super Stardust School Quest Ultra
//Creators: Carl Milazzo & Ian Kane
//Instructor: David Schwartz
//Teachers Assistant: Leigh Raze

#pragma once
#include "GameObject.h"


GameObject::GameObject(void)
{
	setPos(0,0);
	setdisplay((char)178);
}

GameObject::GameObject(const GameObject & go)
{
	setPos(go.getPos()[0], go.getPos()[1]);
	setdisplay(go.getdisplay());
}

GameObject::GameObject(int x, int y, char display)
{
	setPos(x,y);
	setdisplay(display);
}

GameObject::~GameObject(void)
{
	#ifdef DEBUGER
	cout << "GameObject Deleted" << endl;
	#endif DEBUGER
}

void GameObject::operator=(const GameObject & go)
{
	setPos(go.getPos()[0], go.getPos()[1]);
	setdisplay(go.getdisplay());
}

//getters
vector<int> GameObject::getPos() const { return pos;}
char GameObject::getdisplay()const {return display;}

//setters
void GameObject::setPos( int x, int y)
{
	
	pos.assign(2,y);
	pos.assign(1,x);
	pos.push_back(y);
}
void GameObject::setdisplay(char d){ display = d;}

/**
Returns if it moved or not

passes in an object that's moving and the object it's moving to

*/
bool GameObject::move(char mover, char movee)
{
	if(movee == 'M')
	{
		
		//set mode to combat
		return true;
	}
	else if(movee == '*')
	{
		//change map to mirror this.
		return true;
	}
	else if(movee == 'W')
	{
		//dosen't do anything
		return false;
	}
	else if(movee == 'I')
	{
		//gets the item in your inventory and calls move again.
		return true;
	}
	

	return false;
}