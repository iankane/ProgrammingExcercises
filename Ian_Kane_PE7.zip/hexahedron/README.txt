lower case a will increase the alpha by 1, whereas uppercase A will decrease the alpha by 1.
alpha changes the Y rotation.
lower case b will increase the beta by 1, whereas uppercase B will decrease the beta by 1.
beta changes the X rotation.
lower case g will increase the gamma by 1, whereas uppercase G will decrease the gamma by 1.
gamma changes the Z rotation.