#pragma once
class testClass
{
public:
	testClass(void);
	~testClass(void);
};

#include <stdlib.h>

#include <glut.h>

static float distance = -5. ;
static float day =0;
static float year =0;
static float gamma =0;
static float beta =0;
static float alpha =0;


void init(void) 
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glShadeModel (GL_FLAT);
}

void display(void)
{
   glClear (GL_COLOR_BUFFER_BIT);
   glColor3f (1.0, 1.0, 1.0);
    glLoadIdentity();
    
     /*the following "viewing transformation"  moves the camera back away from the sun */
     /*this is equivalent to moving the global coordinate system (wth origin at the center of the sun) away from the camera coordinate system */
    glTranslatef(0., 0., distance);
	glRotatef (-gamma, 0.0, 0.0, 1.0);
	glRotatef (-beta, 1.0, 0.0, 0.0);
	glRotatef (-alpha, 0.0, 1.0, 0.0); 
 
   
   /*the sun is drawn at the origin of the global coordinate system*/
   glutWireSphere(1.0, 20, 16);   
   /*rotate the local coordinate system relative to (i.e. about the) global y axis"*/
   glRotatef (year, 0.0, 1.0, 0.0);
   /*translate the local coordinate system along the direction of its positive z axis"*/
   glTranslatef (2.0, 0.0, 0.0);
   /*rotate the local coordinate system about its y axis"*/
   glRotatef ((GLfloat) day, 0.0, 1.0, 0.0);
   /*the earth is drawn in the current local coordinates"*/
   glutWireSphere(0.2, 10, 8);  
   /*rotate the local coordinate system relative to the global Y axis*/
   glRotatef(year, 0.0,1.0,0.0);
   /*translate the local coordinate system along the direction of it's positive z axis*/
   glTranslatef (0.5, 0.0, 0.0);
   /*rotate the local coordinate system about its y axis"*/
   glRotatef ((GLfloat) day, 0.0, 1.0, 0.0);
   /*the moon is drawn in the current local coordinates"*/
   glutWireSphere(0.05, 10, 8);  
   /*does everything backwards to move to the origin.*/
   glRotatef ((GLfloat) day, 0.0, -1.0, 0.0);
   glTranslatef (-0.5, 0.0, 0.0);
   glRotatef(year, 0.0,-1.0,0.0);
   glRotatef ((GLfloat) day, 0.0, -1.0, 0.0);
   glTranslatef (-2.0, 0.0, 0.0);
   glRotatef (year, 0.0, -2.0, 0.0);

   /*start going the opposite way to make opposite planets*/
   
   /*translate the local coordinate system along the direction of its positive z axis"*/
   glTranslatef (-2.0, 0.0, 0.0);
   /*rotate the local coordinate system about its y axis"*/
   glRotatef ((GLfloat) day, 0.0, -1.0, 0.0);
   /*the earth is drawn in the current local coordinates"*/
   glutWireSphere(0.2, 10, 8);  
   /*rotate the local coordinate system relative to the global Y axis*/
   glRotatef(year, 0.0,-1.0,0.0);
   /*translate the local coordinate system along the direction of it's positive z axis*/
   glTranslatef (-0.5, 0.0, 0.0);
   /*rotate the local coordinate system about its y axis"*/
   glRotatef ((GLfloat) day, 0.0, -1.0, 0.0);
   /*the moon is drawn in the current local coordinates"*/
   glutWireSphere(0.05, 10, 8);  
   glutSwapBuffers();
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h); 
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 20.0);
   glMatrixMode(GL_MODELVIEW);
    
}

void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case 'd':
           distance = distance + 1;
         glutPostRedisplay();
         break;
      case 'D':
           distance = distance - 1;
         glutPostRedisplay();
         break;
          case 27:
         exit(0);
         break;

	  case 'a':
		  alpha = alpha + 1;
		  glutPostRedisplay();
		  break;
	 case 'A':
		  alpha = alpha - 1;
		  glutPostRedisplay();
		  break;
	case 'g':
		  gamma = gamma + 1;
		  glutPostRedisplay();
		  break;
	 case 'G':
		  gamma = gamma - 1;
		  glutPostRedisplay();
		  break;
	 case 'b':
		  beta = beta + 1;
		  glutPostRedisplay();
		  break;
	 case 'B':
		  beta = beta - 1;
		  glutPostRedisplay();
		  break;
      default:
         break;
   }
}

void enterFrame()
{

    year = year + .01;
    day = day + .1;
    glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize (500, 500); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutIdleFunc(enterFrame);
   glutMainLoop();
   return 0;

}