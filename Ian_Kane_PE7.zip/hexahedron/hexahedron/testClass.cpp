#include "testClass.h"


testClass::testClass(void)
{
}


testClass::~testClass(void)
{
}
