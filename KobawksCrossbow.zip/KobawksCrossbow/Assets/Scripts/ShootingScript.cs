using UnityEngine;
using System.Collections;

public class ShootingScript : MonoBehaviour {
	public GameObject bulletPrefab;

	public int bulletSpeed;
    public Transform EndofBow;
    public GameObject bullet;
    
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
	
		if(Input.GetMouseButtonDown(0))
    	{
           
    		bullet = (GameObject)GameObject.Instantiate(bulletPrefab);
            bullet.transform.position = EndofBow.transform.position;
            bullet.transform.rotation = this.transform.rotation * Quaternion.AngleAxis(90, Vector3.up);
			bullet.rigidbody.velocity = this.transform.forward * bulletSpeed;

            DestroyObject(bullet, 5);
    	}    
	}
}
