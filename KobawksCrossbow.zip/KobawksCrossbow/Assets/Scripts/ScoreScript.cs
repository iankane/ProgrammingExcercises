using UnityEngine;
using System.Collections;

public class ScoreScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void onGUI()
    {
        GUI.Label( new Rect(10, 10, 200, 100), "Score: " );

    }
}
